/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../partials/alert.txt").then((r) => r.text()),
      fetch("../partials/header.txt").then((r) => r.text()),
      fetch("../partials/footer.txt").then((r) => r.text()),
      fetch("../partials/modal.txt").then((r) => r.text()),
      fetch("../partials/drawer-menu.txt").then((r) => r.text()),

      // 本番環境では下記を使用する
      // fetch("/home/mymu/demo/mymu/partials/alert.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/header.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/footer.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/modal.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ：JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }
  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];
    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);
    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }
  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);
  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }
  sessionStorage.setItem("appDataEdit", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ：JSONの変更検知
 ******************************************/
function isJsonChanged() {
  const entryId = getJsonValue("entryId");
  const originalStr = sessionStorage.getItem("appData");
  const editingStr = sessionStorage.getItem("appDataEdit");
  if (!originalStr || !editingStr) return false;
  const original = JSON.parse(originalStr);
  const editing = JSON.parse(editingStr);
  const originalData = original[entryId];
  const editingData = editing[entryId];
  const isChanged =
    JSON.stringify(originalData) !== JSON.stringify(editingData);
  return isChanged;
}
/******************************************
 * 完了ボタン制御
 ******************************************/
function updateCompleteButton() {
  const btn = document.querySelector(".js-complete-btn");
  if (!btn) return;

  const headerSetKey = document.body.dataset.appHeaderSet;
  const entryId = getJsonValue("entryId");

  // editAutomation かつ new 以外の場合
  if (headerSetKey === "editAutomation" && entryId !== "new") {
    const changed = isJsonChanged();
    if (changed) {
      // 変更があれば enabled に
      btn.disabled = false;
      btn.classList.add("active");
      btn.classList.remove("disabled");
      btn.setAttribute("aria-disabled", "false");
    } else {
      // 変更がなければ disabled に
      btn.disabled = true;
      btn.classList.remove("active");
      btn.classList.add("disabled");
      btn.setAttribute("aria-disabled", "true");
    }
    return;
  }

const currentTriggerEvent = getJsonValue("currentTriggerEvent");
// 値の存在と空でないことを両方チェック
const actions = getJsonValue(`${entryId}.actions`);
const hasActions = actions != null && actions.length > 0;
const locationEvent = getJsonValue(`${entryId}.triggers.location.event`);
const hasLocation = locationEvent != null && locationEvent.length > 0;
const deviceCondition = getJsonValue(`${entryId}.triggers.devices.condition`);
const hasDevices = deviceCondition != null && deviceCondition.length > 0;
  // new の場合（従来の処理）
  if (currentTriggerEvent === "schedule") {
    const changed = isJsonChanged() && hasActions;
    btn.disabled = !changed;
    btn.classList.toggle("active", changed);
    btn.setAttribute("aria-disabled", String(!changed));

  } else if (currentTriggerEvent === "location") {
    const changed = isJsonChanged() && hasActions && hasLocation;
    btn.disabled = !changed;
    btn.classList.toggle("active", changed);
    btn.setAttribute("aria-disabled", String(!changed));

  } else if (currentTriggerEvent === "devices") {
    const changed = isJsonChanged() && hasActions && hasDevices;
    btn.disabled = !changed;
    btn.classList.toggle("active", changed);
    btn.setAttribute("aria-disabled", String(!changed));
  }
  
}
/******************************************
 * ユーティリティ：JSONを上書きする
 ******************************************/
function updateAppData() {
  const appDataEdit = JSON.parse(sessionStorage.getItem("appDataEdit"));
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  const entryId = getJsonValue("entryId");
  if (appDataEdit) {
    if (currentHeaderSetKey === "editAutomation" && entryId === "new") {
      // appDataをappDataEditの内容で上書き
      sessionStorage.setItem("appData", JSON.stringify(appDataEdit));
    }
  }
}

/******************************************
 * ユーティリティ：モーダル表示
 ******************************************/
function showModal(modalId) {
  const modalEl = document.getElementById(modalId);
  if (!modalEl) return;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();
}

/******************************************
 * ユーティリティ：モーダルフォーカス解除
 ******************************************/
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});

/******************************************
 * ユーティリティ：トグルボタングループの排他的処理
 ******************************************/
function updateToggleGroup(groupName, value) {
  const group = document.querySelector(`[data-toggle-group="${groupName}"]`);
  if (!group) return;
  const buttons = group.querySelectorAll("[data-app-value]");
  buttons.forEach((btn) => {
    const isActive = btn.dataset.appValue === value;
    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", isActive);
  });
}

/******************************************
 * ユーティリティ：チェックボックスの処理
 ******************************************/
function utilsCheckboxToJson(selector) {
  // 親要素を取得
  const container = document.querySelector(`.${selector}`);
  if (!container) return { users: [] }; // 要素がない場合の安全策
  // チェックされている要素をすべて取得
  const checkedElements = container.querySelectorAll(
    "[data-app-key]:has(.form-check-input:checked)",
  );
  // データを取り出して配列化し、オブジェクトとして return する
  return {
    users: Array.from(checkedElements).map((el) => el.dataset.appKey),
  };
}

/******************************************
 * ユーティリティ：名称を取得して代入（オートメーション名など）
 ******************************************/
function renderElementName(selector, value, defaultText = "") {
  const el = document.querySelector(selector);
  if (!el) return;
  const text = value?.trim?.() || defaultText;
  el.textContent = text;
}

/******************************************
 * ユーティリティ：entryId, actionId, actions, actionを返す
 ******************************************/
function getAutomationEntryData() {
  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find((a) => a.actionId === actionId);
  // if (!action) return null; // 新規オートメーションの場合以降の処理がされないためコメントアウトした
  return { entryId, actionId, actions, action };
}

/******************************************
 * ユーティリティ：「デモアプリではこのボタンは操作できません。」
 ******************************************/
document.addEventListener("click", (e) => {
  const target = e.target.closest(".demo-toggle-alert");
  if (!target) return;

  // 現在の状態を保持（クリック後の状態）
  const currentChecked = target.checked;
  e.stopPropagation();
  alert("デモアプリではこのボタンは操作できません。");

  // 元の状態に戻す
  target.checked = !currentChecked;

  // 開いているモーダルがあれば閉じる
  document.querySelectorAll(".modal.show").forEach((modalEl) => {
    const modalInstance =
      bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
    modalInstance.hide();
  });
});

/******************************************
 * ユーティリティ：オートメーション編集画面に戻ったとき、セッションストレージをリセットする
 ******************************************/
function resetAutomationExceptNew() {
  const current = JSON.parse(sessionStorage.getItem("appData")) ?? {};
  const original = JSON.parse(sessionStorage.getItem("cloneData")) ?? {};
  const currentNew = current.new ?? null;
  // cloneDataをベースに戻す
  const resetData = JSON.parse(JSON.stringify(original));
  // newだけ保持
  if (currentNew) {
    resetData.new = currentNew;
  }

  sessionStorage.setItem("appData", JSON.stringify(resetData));
}

/******************************************
 * ID作成（カードボタン用）
 ******************************************/
function createId() {
  return crypto.randomUUID().replace(/-/g, "").slice(0, 10);
}

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

function initUI() {
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  bindScheduleTimeModal();
}

function bindScheduleTimeModal() {
  const modalEl = document.getElementById("scheduleTimeModal");
  if (!modalEl) return;
  if (modalEl.dataset.boundScheduleTimeModal === "1") return;
  modalEl.dataset.boundScheduleTimeModal = "1";

  modalEl.addEventListener("show.bs.modal", () => {
    const entryId = getJsonValue("entryId");
    renderScheduleTimeModal(entryId);
  });
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    case "backToAutomation":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      if (
        document.body.dataset.appHeaderSet === "editAutomation" &&
        getJsonValue("entryId") !== "new"
      ) {
        setJsonValue("navigationMode", "back");
        window.location.href = "../automation/";
        return;
      }
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      sessionStorage.setItem("appDataReturnMode", "cancel");
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
    case "backToAutomation":
      setJsonValue("navigationMode", "back");
      window.location.href = "../automation/";
      break;
  }
}

// ==============================
// 右ボタン描画　headerTitle
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");
  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";
  if (headerSetJsonRight.action === "mymu") {
    headerDomRight.disabled = false;
    headerDomRight.classList.remove("disabled");
    headerDomRight.classList.remove("js-complete-btn");
    headerDomRight.setAttribute("aria-disabled", "false");
  }
  // bodyのdata属性チェック
  const headerSetKey = document.body.dataset.appHeaderSet;

  if (
    headerSetKey === "setupScene" ||
    headerSetKey === "selectRoomTemperatureStatusOver" ||
    headerSetKey === "selectRoomTemperatureStatusUnder" ||
    headerSetKey === "deviceSettingsRac" ||
    headerSetKey === "deviceSettingsEq" ||
    headerSetKey === "selectNotice"
  ) {
    headerDomRight.disabled = false;
    headerDomRight.classList.add("active");
  }

  // 登録済みオートメーションは「編集」、新規オートメーションは「新規」
  const headerTitle = document.getElementById("headerTitle");
  if (headerSetKey === "editAutomation") {
    const entryId = getJsonValue("entryId");
    if (entryId === "new") {
      headerTitle.textContent = "新規オートメーション";
      headerDomRight.disabled = false;
      headerDomRight.classList.remove("disabled");
      headerDomRight.setAttribute("aria-disabled", "false");
    } else {
      headerDomRight.disabled = false;
      headerDomRight.classList.remove("active");
      headerDomRight.classList.add("disabled");
      headerDomRight.setAttribute("aria-disabled", "true");
    }
  }
  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  const entryId = getJsonValue("entryId");
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      // if (entryId === "new") {
      //   setJsonValue("new.status", true);
      // }
      sessionStorage.setItem("appDataReturnMode", "keep");
      window.history.back();
      break;

    // オートメーション画面へ遷移
    case "editAutomation":
      const entryId = getJsonValue("entryId");
      if (entryId !== "new") {
        alert("デモアプリでは設定変更は反映されません");
        setJsonValue("navigationMode", "back");
        return;
      }
      if (entryId === "new") {
        setJsonValue("new.status", true);
        setJsonValue("navigationMode", "complete");
      }
      // setJsonValue("navigationMode", "complete");
      // window.location.href = "../automation/";
      break;

    // オートメーション編集画面へ遷移
    case "goToEditAutomation":
      // if (entryId === "new") {
      //   setJsonValue("new.status", true);
      // }
      window.location.href = "../edit-automation/";
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // アラート表示
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = "../schedule/";
      break;

    // MyMUボタン
    case "mymu":
      const headerEl = document.querySelector(".app-header");
      headerEl.addEventListener("click", (e) => {
        const btn = e.target.closest("#headerRightBtn");
        if (!btn) return;
        alert("デモアプリではこのボタンは操作できません。");
      });
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const currentHeaderSetKey = document.body.dataset.appHeaderSet;
      if (
        currentHeaderSetKey === "editAutomation" &&
        btn.dataset.appPage === "automation"
      ) {
        setJsonValue("navigationMode", "back");
      }
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * グローバル変数
 ******************************************/
const appState = {
  deleteActionId: null,
  deletingCard: null,
  deletingType: null,
  deleteContext: null,
  editActionId: null,
  selectedScene: null,
  selectedUsers: [],
  isEdited: false,
  appCard: null, // ホーム画面のカード要素
  appCardId: null, // ホーム画面のカード要素ID（rac-1, rac-2, eq）
};

/******************************************
 * マッピングオブジェクト
 ******************************************/
// 機器名、アイコンマスター
const DEVICE_MASTER = {
  "rac-1": {
    label: "リビングのエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
    settingsScene: "../device-settings-rac-scene/",
    on: "運転開始",
    off: "運転停止",
  },
  "rac-2": {
    label: "寝室のエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
    settingsScene: "../device-settings-rac-scene/",
    on: "運転開始",
    off: "運転停止",
  },
  eq: {
    label: "給湯機1",
    icon: "../assets/img/product_Icon_EQ_40pt.svg",
    settings: "../device-settings-eq/",
    settingsScene: "../device-settings-eq-scene/",
    on: "ふろ自動開始",
    off: "ふろ自動停止",
  },
};

// 製品カテゴリマスター
const CATEGORY_MASTER = {
  "rac-1": "rac",
  "rac-2": "rac",
  eq: "eq",
};

// アクション マスター
const ACTION_MASTER = {
  devices: {
    "rac-1": {
      icon: "../assets/img/icon_AC_40pt.svg",
      url: "../device-settings-rac/",
    },
    "rac-2": {
      icon: "../assets/img/icon_AC_40pt.svg",
      url: "../device-settings-rac/",
    },
    eq: {
      icon: "../assets/img/product_Icon_EQ_40pt.svg",
      url: "../device-settings-eq/",
    },
  },
  notify: {
    icon: "../assets/img/icon_Notifications_40.svg",
    url: "../select-notice/",
  },
};

// シーンマスター
const SCENE_MASTER = {
  allOff: {
    label: "外出一括オフ",
    icon: "../assets/img/scene_off_40_40.svg",
    url: "../setup-scene/",
  },
  sleep: {
    label: "就寝",
    icon: "../assets/img/scene_sleep.svg",
    url: "../setup-scene/",
  },
  returnWinter: {
    label: "冬の帰宅",
    icon: "../assets/img/scene-icon-returning-home-winter.svg",
    url: "../setup-scene/",
  },
};

// 通知マスター
const NOTICE_MASTER = {
  "notify-1": {
    label: DEVICE_MASTER["rac-1"].label,
    message: "室温",
  },
  "notify-2": {
    label: DEVICE_MASTER["rac-2"].label,
    message: "室温",
  },
  "notify-3": {
    message: null,
  },
};

// カスタムシーンカードマスター
const CUSTOM_SCENE_MASTER = {
  "rac-1": {
    label: DEVICE_MASTER["rac-1"].label,
    icon: "../assets/img/icon_AC_40pt.svg",
    on: "運転開始",
    off: "運転停止",
    temp: `${getJsonValue("customScene.devices[0].temp")}℃` ,
  },
  "rac-2": {
    label: DEVICE_MASTER["rac-2"].label,
    icon: "../assets/img/icon_AC_40pt.svg",
    on: "運転開始",
    off: "運転停止",
    temp: `${getJsonValue("customScene.devices[1].temp")}℃` ,
  },
  eq: {
    label: DEVICE_MASTER["eq"].label,
    icon: "../assets/img/product_Icon_EQ_40pt.svg",
    on: "ふろ自動開始",
    off: "ふろ自動停止",
  },
};


// トリガーカード・レンダー・マスター
const TRIGGER_CARD_MASTER = {
  devices: (device) => {
    return {
      name: device.name ?? "（未設定）",
      description: `${device.condition} 温度${device.threshold}℃`,
    };
  },
};

// アクションカード・レンダー・マスター
const ACTION_CARD_MASTER = {
  devices: (action) => {
    const device = ACTION_MASTER.devices[action.id];
    const master = DEVICE_MASTER[action.id];
    if (!device || !master) return null;
    // let desc = master[action.drive] ?? "";
    // if (action.mode) desc += ` ${action.mode}`;
    // if (action.temp) desc += ` ${action.temp}℃`;
    // 👇 追加（ここが本質）
    let desc = action.description?.trim();

    // 👇 なければ従来ロジック
    if (!desc) {
      desc = master[action.drive] ?? "";
      if (action.mode) desc += ` ${action.mode}`;
      if (action.temp) desc += ` ${action.temp}℃`;
    }
    return {
      icon: device.icon,
      name: master.label,
      description: desc,
      url: device.url,
    };
  },
  notify: (action) => {
    const notice = NOTICE_MASTER[action.id] ?? {};
    return {
      icon: ACTION_MASTER.notify.icon,
      name: notice.label ?? "通知",
      description: notice?.message ?? "",
      url: ACTION_MASTER.notify.url,
    };
  },
  scene: (action) => {
    const scene = SCENE_MASTER[action.id];
    if (!scene) return null;
    return {
      icon: scene.icon,
      name: scene.label,
      description: "",
      url: scene.url,
    };
  },
};

// トリガーイベント条件マスター
const TRIGGER_EVENT_DESCRIPTION_MASTER = {
  schedule:
    "設定した時刻に指定されたアクションを実行します。繰り返し設定を行わない場合、１度だけ指定されたアクションを実行します。",
  location:
    "選択された家電シェアユーザーのうちの1名以上が位置条件を満たした場合に、指定されたアクションを実行します。",
  devices:
    "機器の運転状態を元に、指定されたアクションを実行します。トリガーイベントとして指定できる機器の運転状態は1つです。",
};

// トリガーイベントセクション表示／非表示マスター
const TRIGGER_EVENT_SECTION_MASTER = {
  schedule: "schedule-section",
  location: "location-section",
  devices: "devices-section",
};

// アクションセレクトURLマスター
const ACTION_SELECT_URL = {
  scene: "../select-scene/",
  devices: "../select-device/",
  notify: "../select-notice/",
};

// しきい値マスター
const THRESHOLD_MASTER = {
  over: {
    label: "室温がしきい値を超えたとき",
    tempture: "28",
  },
  under: {
    label: "室温がしきい値を下回ったとき",
    tempture: "15",
  },
};

// カードマスター（ホーム画面）
const CARD_MASTER = {
  "rac-1": "A.I.自動", //
  "rac-2": "A.I.自動", //
  eq: "ふろ自動", //
};

// 完了ボタンクリック後の遷移画面マスター
const COMPLETE_BTN_MASTER = {
  editAutomation: "../automation/",
  deviceSettingsRac: "../edit-automation/",
  deviceSettingsEq: "../edit-automation/",
  setupScene: "../edit-automation/",
  selectRoomTemperatureStatusOver: "../edit-automation/",
  selectRoomTemperatureStatusUnder: "../edit-automation/",
  // "homeLocationSettings": "../xxxxxxxxxx/",
  // "selectDevice": "../xxxxxxxxxx/",
  selectNotice: "../edit-automation/",
  // "notificationSettings": "../xxxxxxxxxx/",
  // "sceneSettings": "../xxxxxxxxxx/",
};

// 削除モーダルのメッセージマスター
const DELETE_MODAL_MESSAGE_MASTER = {
  scene: "シーンを削除しますか？",
  devices: "機器の操作を削除しますか？",
  notify: "通知を削除しますか？",
};

// 時間設定モーダルのメッセージマスター
const SCHEDULE_TIME_MODAL_MASTER = {
  "auto-1": "../assets/img/scheduleTimeModal-fuyunokitaku.svg", // 冬の帰宅
  "auto-2": "../assets/img/scheduleTimeModal-natsunokitaku.svg", // 夏の帰宅
  "auto-3": "../assets/img/scheduleTimeModal-new.svg", // 高温お知らせ
  "temp-1": "../assets/img/scheduleTimeModal-new.svg", // 高温お知らせ
  "temp-2": "../assets/img/scheduleTimeModal-new.svg", // 低温お知らせ
  "temp-3": "../assets/img/scheduleTimeModal-new.svg", // おかえりON
  "temp-4": "../assets/img/scheduleTimeModal-new.svg", // おでかけOFF
  "temp-5": "../assets/img/scheduleTimeModal-iri.svg", // エアコン入タイマー
  "temp-6": "../assets/img/scheduleTimeModal-kiri.svg", // エアコン切タイマー
  "new": "../assets/img/scheduleTimeModal-new.svg", // 新規オートメーション
};

/******************************************
 * クリックイベント（アクションカードエリア）
 ******************************************/
const actionCardSection = document.getElementById("actionCardSection");
// オートメーションEntryデータを最初に取得する
document.addEventListener("click", (e) => {
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  const { entryId, actionId, actions, action } = entryData;

  // 「シーンを選択」のクリックイベント（外出一括オフ／就寝／冬の帰宅）
  const selectSceneBtn = e.target.closest(".js-select-scene-btn");
  if (selectSceneBtn) {
    const sceneId = selectSceneBtn.dataset.appKey; // allOff / sleep / returnWinter
  }

  // アクション追加のカードボタンをクリック（シーン／機器／通知）
  const addActionBtn = e.target.closest(".js-add-action-btn");
  if (addActionBtn) {
    // アクションタイプを取得
    const actionType = addActionBtn.dataset.appAction;

    // devices のときだけ入口状態を保存（アクションで機器を選択した場合「devices」としている）
    if (actionType === "devices") {
      setJsonValue(`${entryId}.entryDeviceCard`, "action");
      saveSnapshot(); // entryDeviceCard を含む状態をスナップショットに保存
    }
    // notify の場合は新規作成のため editActionId をクリアしてから遷移する
    if (actionType === "notify") {
      setJsonValue("editActionId", null);
    }
    const url = ACTION_SELECT_URL[actionType];
    if (url) {
      window.location.href = url;
    }
  }

  // トリガー／アクションカードで機器を選択のクリックイベント（リビングのエアコン／寝室のエアコンのどちら）
  const deviceBtn = e.target.closest(".js-select-device-btn");
  if (deviceBtn) {
    const deviceId = deviceBtn.dataset.appDevice;
    // const entryId = getJsonValue("entryId");
    const entryDeviceCard = getJsonValue(`${entryId}.entryDeviceCard`); // trigger / action
    if (!entryId) return;
    /* -----------------------------
      トリガー（機器の状態）
    ----------------------------- */
    if (entryDeviceCard !== "action") {
      // アクション以外
      setJsonValue(`${entryId}.triggers.devices.id`, deviceId);
      setJsonValue(
        `${entryId}.triggers.devices.name`,
        DEVICE_MASTER[deviceId].label,
      );
      // window.location.href = "../select-device-operation/"; // しきい値設定の画面
      return;
    }
  }

  // トリガーカードの削除／画面遷移（ゴミ箱アイコン／ボタン本体）確認用モーダル表示なし
  // ===== カード削除 =====
  const deleteBtn = e.target.closest(
    ".delete-trigger-card-btn, .delete-action-card-btn",
  );
  if (deleteBtn) {
    e.preventDefault();
    e.stopPropagation();
    // トリガーカード削除
    const triggerCard = deleteBtn.closest(".js-device-card");
    if (triggerCard) {
      const entryAutoId = triggerCard.dataset.entryId;
      deleteTriggerCard(entryAutoId);
      return;
    }
    // アクションカード削除
    const actionCard = deleteBtn.closest(".js-action-card");
    if (actionCard) {
      appState.deleteActionId = actionCard.dataset.actionId;
      renderDeleteActionCardModal(actionCard);
      showModal("deleteActionCardButton");
      return;
    }
  }

  // ===== カードクリック =====
  // トリガーカード
  const triggerCard = e.target.closest(".js-device-card");
  if (triggerCard) {
    window.location.href = "../select-device-operation/";
    return;
  }
  // アクションカード
  const actionCard = e.target.closest(".js-action-card");
  if (actionCard) {
    const url = actionCard.dataset.actionUrl;
    const actionId = actionCard.dataset.actionId;
    if (!url) return;
    setJsonValue("editActionId", actionId);
    window.location.href = url;
  }
});

// エアコン／給湯機で利用する関数
function handleDriveClick(btn) {
  const drive = btn.dataset.appDrive;
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  const { entryId, actions, action } = entryData;
  /* JSON保存 */
  action.drive = drive;

  // ★追加：運転停止なら mode / temp を無効化
  if (drive === "off") {
    action.mode = null;
    action.temp = null;
  }
  setJsonValue(`${entryId}.actions`, actions);
  /* UI排他 */
  updateToggleGroup("driveBtnGroup", action.drive);
  /* ★追加：UI状態更新 */
  updateRacControlState(btn);
}

// エアコン／給湯機で利用する関数
function handleModeClick(btn) {
  const mode = btn.dataset.appMode;
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  const { entryId, actions, action } = entryData;
  /* JSON保存 */
  action.mode = mode;
  // ★送風 / 除湿なら temp を無効化
  if (mode === "除湿" || mode === "送風") {
    action.temp = null;
  }

  const entryTrigger = getJsonValue(`${entryId}.entryTrigger`);
  if (entryTrigger === "location") {
    const desc = buildDescription(action, entryTrigger);
    if (desc) {
      action.description = desc;
    } else {
      delete action.description; // 不要なら削除
    }
  }

  setJsonValue(`${entryId}.actions`, actions);
  /* UI排他 */
  updateToggleGroup("modeBtnGroup", action.mode);
  /* ★追加：UI状態更新 */
  renderStartTemperatureSection(action.mode, entryId);
  updateRacControlState(btn);
}

// 位置情報が選択された状態で機器の操作を追加した場合（室温28.0℃以上で冷房28.0℃運転 など）
function buildDescription(action, entryTrigger) {
  if (entryTrigger !== "location") return null;
  const temp = action.temp;
  if (!temp) return null;
  if (action.mode === "冷房") {
    return `室温28.0℃以上で冷房28.0℃運転`;
  }
  if (action.mode === "暖房") {
    return `室温18.0℃以下で暖房18.0℃運転`;
  }
  return null;
}

// エアコン／給湯機で利用する関数（エアコンのボタンを活性化／非活性化）
function updateRacControlState(btn) {
  const modeSection = document.getElementById("modeSection");
  const tempSection = document.getElementById("temperatureSection");
  const exSection = document.querySelector(".startTemperatureSection");
  const exDescription = document.getElementById("startTemperatureDiscription");
  // const startTemperatureSection = document.querySelector(".startTemperatureSection");

  // entryTrigger を取得
  const entryData = getAutomationEntryData();
  const entryTrigger = entryData
    ? getJsonValue(`${entryData.entryId}.entryTrigger`)
    : null;

  const isDriveOn = btn.dataset.appDrive;
  const driveMode = btn.dataset.appMode;
  if (!modeSection || !tempSection || !exSection) return;
  const modeButtons = modeSection.querySelectorAll(".js-mode");
  const tempChangeBtn = tempSection.querySelector("#changeBtn");
  const exBtn = exSection.querySelector(".changeBtn");
  if (isDriveOn === "on") {
    modeSection.classList.remove("section-disabled");
    modeSection.classList.add("bg-body");
    tempSection.classList.remove("section-disabled");
    tempSection.classList.add("bg-body");
    tempChangeBtn.classList.add("fc-active");
    exSection.classList.remove("section-disabled");
    exSection.classList.add("bg-body");
    exDescription.classList.remove("d-none");
    exBtn.classList.add("fc-active");
    initDeviceEditor(); // 運転がONのとき、モードと温度の初期値をセットする
  } else if (isDriveOn === "off") {
    modeSection.classList.add("section-disabled");
    modeSection.classList.remove("bg-body");
    tempSection.classList.add("section-disabled");
    tempSection.classList.remove("bg-body");
    tempChangeBtn.classList.remove("fc-active");
    exSection.classList.add("section-disabled");
    exSection.classList.remove("bg-body");
    exBtn.classList.remove("fc-active");
    exDescription.classList.add("d-none");

    // モードのactiveを全解除
    modeButtons.forEach((btn) => {
      btn.classList.remove("active");
    });
  }
  if (driveMode === "除湿" || driveMode === "送風") {
    tempSection.classList.add("section-disabled");
    tempSection.classList.remove("bg-body");
    tempChangeBtn.classList.remove("fc-active");
    exSection.classList.add("section-disabled");
    exSection.classList.remove("bg-body");
    exSection.classList.add("d-none");
    exBtn.classList.remove("fc-active");
    exDescription.classList.add("d-none");
  } else if ((driveMode === "冷房") | (driveMode === "暖房")) {
    tempSection.classList.remove("section-disabled");
    tempSection.classList.add("bg-body");
    tempChangeBtn.classList.add("fc-active");
    // entryTrigger が location の場合のみ表示
    if (entryTrigger === "location") {
      exSection.classList.remove("section-disabled");
      exSection.classList.add("bg-body");
      exSection.classList.remove("d-none");
      exBtn.classList.add("fc-active");
      exDescription.classList.remove("d-none");
    } else {
      exSection.classList.add("section-disabled");
      exSection.classList.remove("bg-body");
      exSection.classList.add("d-none");
      exBtn.classList.remove("fc-active");
      exDescription.classList.add("d-none");
    }
  }
}

// アクションカード削除用モーダルの削除ボタンをクリックしたとき関数を呼び出す
document.addEventListener("click", (e) => {
  const btn = e.target.closest("#confirmDeleteActionCardButton");
  if (!btn) return;

  const modalEl = document.getElementById("deleteActionCardButton");
  const modal = bootstrap.Modal.getInstance(modalEl);
  // アクションカードを削除する関数
  deleteActionCard();
  if (modal) modal.hide();
});

// アクションカードボタンを削除する（JSON書き換え⇒再読み込み）
function deleteActionCard() {
  const entryId = getJsonValue("entryId");
  const actionId = appState.deleteActionId;
  if (!actionId) return;

  let actions = getJsonValue(`${entryId}.actions`) ?? [];
  actions = actions.filter((action) => action.actionId !== actionId);
  setJsonValue(`${entryId}.actions`, actions);
  appState.deleteActionId = null;
  renderAutomationEditing();
  updateCompleteButtonState();
}

// 提案オートメーション画面
const proposalAutomation = document.querySelector(
  '[data-app-header-set="proposalAutomation"]',
);
if (proposalAutomation) {
  proposalAutomation.addEventListener("click", (e) => {
    // 提案オートメーション（temp-1〜temp-6）
    // const editAutomationBtn = e.target.closest(".js-edit-automation-btn");
    // if (editAutomationBtn) {
    //   const key = editAutomationBtn.dataset.appKey;
    //   const entryTrigger = editAutomationBtn.dataset.appEntryTrigger;
    //   setJsonValue("entryId", key);
    //   setJsonValue("currentTriggerEvent", entryTrigger);
    //   window.location.href = "../edit-automation/";
    //   return;
    // }
    // 提案オートメーション（new）
    const editNewAutomationBtn = e.target.closest(".js-new-automation-btn");
    // if (editNewAutomationBtn) {
    //   const key = editNewAutomationBtn.dataset.appKey;
    //   setJsonValue("entryId", key);
    //   setJsonValue("editActionId", null);
    // window.location.href = "../edit-automation/";
    // }
  });
}

// オートメーションカードのクリックイベント（オートメーション編集画面へ遷移）
document.addEventListener("click", (e) => {
  const automationBtn = e.target.closest(".js-automation-btn");
  if (automationBtn) {
    // 無効カードなら何もしない
    if (automationBtn.classList.contains("auto-card-disabled")) return;
    const entryId = automationBtn.dataset.appKey;
    setJsonValue("entryId", entryId);
    // appDataをappDataSnapshotBaseにコピー（編集前の状態を保存）
    const currentData = JSON.parse(sessionStorage.getItem("appData")) ?? {};
    sessionStorage.setItem("appDataSnapshotBase", JSON.stringify(currentData));

    // オートメーション編集画面へ
    window.location.href = "../edit-automation/";
  }
});

// オートメーションカードのトグルスイッチON／OFF
function automationToggleOnOff() {
  const automationToggles = document.querySelectorAll(".auto-toggle");
  automationToggles.forEach((sw) => {
    sw.addEventListener("click", (e) => {
      // カードクリック防止
      e.stopPropagation();
      const card = sw.closest(".js-automation-btn");
      const entryId = card.dataset.appKey;
      const isOn = sw.checked;
      // セッションストレージ更新
      setJsonValue(`${entryId}.status`, isOn);
      // UI更新
      renderAutomationCardStatus();
    });
  });
}

// オートメーションカードのレンダリング（トグルスイッチの状態を取得）
function renderAutomationCardStatus() {
  const cards = document.querySelectorAll(".js-automation-btn");
  cards.forEach((card) => {
    const entryId = card.dataset.appKey;
    // セッションストレージから状態取得
    const status = getJsonValue(`${entryId}.status`);
    const toggle = card.querySelector(".auto-toggle");
    const isOn = status !== false;
    // カード状態
    card.classList.toggle("auto-card-disabled", !isOn);
    // トグル状態
    if (toggle) {
      toggle.checked = isOn;
    }
  });
}

// 受け取った曜日を配列⇒JSONに保存
function toggleScheduleDay(entryAutoId, day) {
  const path = `${entryAutoId}.triggers.schedule.days`;
  let days = getJsonValue(path) ?? [];

  if (days.includes(day)) {
    days = days.filter((d) => d !== day);
  } else {
    days.push(day);
  }

  setJsonValue(path, days);
  renderSchedule(entryAutoId);
}

// 通知設定を選択 レンダリング
function renderSelectNotice() {
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  let { entryId, actionId, actions, action } = entryData;

  // const actionId = getJsonValue("editActionId");
  action = actions.find((a) => a.actionId === actionId && a.type === "notify");

  /* -------------------------
     通知先（ユーザー）
  ------------------------- */
  if (!action) {
    action = {
      actionId: createId(),
      type: "notify",
      id: null,
      users: ["お父さん"],
    };
  }
  const users = actions.users ?? [];
  const noticeUsers = document.querySelectorAll(".js-notify-user");
  noticeUsers.forEach((el) => {
    const user = el.dataset.appUser;
    const checkbox = el.querySelector("input");
    if (!checkbox) return;
    checkbox.checked = action.users?.includes(user);
  });
  /* -------------------------
     通知内容（機器）
  ------------------------- */
  const noticeTypes = document.querySelectorAll(".js-notify-type");
  noticeTypes.forEach((el) => {
    const notifyId = el.dataset.appNotify;
    const radio = el.querySelector("input[type='radio']");
    if (!radio) return;
    radio.checked = action.id === notifyId;
  });
}

// 通知設定を選択 クリックイベント
function clickSelectNotice() {
  const holder = document.querySelector(".js-notify-holder");
  if (!holder) return;
  if (holder.dataset.notifyBound === "1") return;
  holder.dataset.notifyBound = "1";
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  const { entryId, actionId, actions, action } = entryData;

  holder.addEventListener("click", (e) => {
    const entryData = getAutomationEntryData();
    if (!entryData) return;

    const { actions } = entryData;
    const actionId = getJsonValue("editActionId");
    let action = actions.find(
      (a) => a.actionId === actionId && a.type === "notify",
    );

    /* -------------------------
       action作成（新規時）
    ------------------------- */
    if (!action) {
      action = {
        actionId: createId(),
        type: "notify",
        id: null,
        users: ["お父さん"],
      };
      actions.push(action);
      // ★ここで保存
      setJsonValue("editActionId", action.actionId);
      setJsonValue(`${entryId}.actions`, actions);
    }

    /* -------------------------
       通知先
    ------------------------- */
    const userRow = e.target.closest(".js-notify-user");
    if (userRow) {
      const user = userRow.dataset.appUser;
      const checkbox = userRow.querySelector(".form-check-input");
      if (!checkbox) return;

      // input 自体をクリックした場合はブラウザの既定トグルを使い、
      // 行クリック時のみ手動で反転する
      const isDirectInputClick = e.target === checkbox;
      if (!isDirectInputClick) {
        checkbox.checked = !checkbox.checked;
      }
      if (!action) return;

      if (checkbox.checked) {
        // 選択された場合：重複していなければ追加
        if (!action.users.includes(user)) {
          action.users.push(user);
        }
      } else {
        // 選択を外した場合：配列から削除
        action.users = action.users.filter((u) => u !== user);
      }
      // 状態を更新
      setJsonValue(`${entryId}.actions`, actions);
    }
    /* -------------------------
       通知内容
    ------------------------- */
    const typeRow = e.target.closest(".js-notify-type");
    if (typeRow) {
      action.id = typeRow.dataset.appNotify;
      setJsonValue(`${entryId}.actions`, actions);
      renderSelectNotice();
    }
  });
}

/******************************************
 * クリックイベント（モーダル系）
 ******************************************/
// オートメーション名を変更
const automationNameSection = document.querySelector(
  ".automation-name-section",
);
if (automationNameSection) {
  automationNameSection.addEventListener("click", (e) => {
    // オートメーションを追加ボタン（提案オートメーションへ遷移）
    changeAutomationNameBtn = e.target.closest(".change-automation-name-btn");
    if (changeAutomationNameBtn) {
      const entryAutoId = getJsonValue("entryId");
      const automationName = getJsonValue(`${entryAutoId}.name`);
      const modalEl = document.getElementById("automationNameModal"); // モーダル要素
      const modal = bootstrap.Modal.getOrCreateInstance(modalEl); // モーダル生成
      const inputEl = document.getElementById("scheduleName"); // input要素
      inputEl.value = automationName; // 現在のオートメーション名を表示
      modal.show(); // モーダル表示
    }
  });
}

// オートメーション削除ボタンのクリックイベント（新規オートメーションのみ／モーダル表示）
const deleteAutomation = document.querySelector(".js-delete-automation");
if (deleteAutomation) {
  deleteAutomation.addEventListener("click", (e) => {
    // 提案オートメーション（temp-1〜temp-6、new）
    const editAutomationBtn = e.target.closest(".js-delete-automation-btn");
    if (editAutomationBtn) {
      showModal("deleteAutomationModal");
    }
  });
}

/******************************************
 * レンダリング（小画面）
 ******************************************/
// シーン設定画面のレンダリング
const renderSetupScene = () => {
  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find((a) => a.actionId === actionId);
  if (!action || action.type !== "scene") return;
  const sceneId = action.id;

  /* シーン名 */
  const sceneNameEl = document.getElementById("sceneName");
  if (sceneNameEl) {
    sceneNameEl.textContent = SCENE_MASTER[sceneId]?.label ?? "";
  }
  /* 全非表示 */
  document
    .querySelectorAll(".allOff,.sleep,.returnWinter")
    .forEach((el) => el.classList.add("d-none"));
  /* 対象表示 */
  document
    .querySelectorAll(`.${sceneId}`)
    .forEach((el) => el.classList.remove("d-none"));
};

// 機器を選択画面
function renderSelectDevice() {
  const entryId = getJsonValue("entryId");
  const entryDeviceCard = getJsonValue(`${entryId}.entryDeviceCard`);
  const eqBtn = document.querySelector(
    ".js-select-device-btn[data-app-device='eq']",
  );
  // console.log(entryId);
  if (entryDeviceCard === "devices") eqBtn.style.display = "none";

  const targetSection = document.querySelector(".js-select-device-section");
  const btnRac1 = targetSection.querySelector(
    '.js-select-device-btn[data-app-device="rac-1"]',
  );
  const btnRac2 = targetSection.querySelector(
    '.js-select-device-btn[data-app-device="rac-2"]',
  );
  combinationCheckDevice();
  combinationDuplicateDevices(entryDeviceCard);
}

// しきい値が所定値を…機器選択後、機器の名前を表示する
const renderRoomTempTriggerButtons = () => {
  // 機器名を表示
  const entryId = getJsonValue("entryId");
  const deviceNameEl = document.getElementById("deviceName");
  const deviceName = getJsonValue(`${entryId}.triggers.devices.name`);
  deviceNameEl.textContent = deviceName ?? "選択された機器の名前"; // ここは実際には選択された機器の名前を入れる
  const underBtn = document.querySelector(
    ".js-threshold-btn[data-app-key='under']",
  );
  const overBtn = document.querySelector(
    ".js-threshold-btn[data-app-key='over']",
  );

  // JSONから condition 取得
  const condition = getJsonValue(`${entryId}.triggers.devices.condition`);
  if (!condition) return;

  updateToggleGroup("threshold", condition);

  // ボタン取得
  const buttons = document.querySelectorAll(".js-threshold-btn");
  buttons.forEach((btn) => {
    const onclick = btn.getAttribute("onclick") ?? "";
    // onclick から over / under 判定
    const isOver = onclick.includes("'over'");
    const isUnder = onclick.includes("'under'");

    let type = "";
    if (isOver) type = "over";
    if (isUnder) type = "under";
  });
};

// 室温が所定値を超えたとき／下回ったとき 画面
const selectRoomTemperatureStatus = () => {
  const entryId = getJsonValue("entryId");

  // JSONから condition 取得
  const condition = getJsonValue(`${entryId}.triggers.devices.condition`);
  if (!condition) return;

  // condition → over / under に変換
  let current = "";
  if (condition.includes("超え")) {
    // 入口に合わせて設定温度を変更
    renderSelectRoomTemperatureStatus(entryId);
    document.body.setAttribute(
      "data-app-header-set",
      "selectRoomTemperatureStatusOver",
    );
    document.getElementById("section-over").classList.remove("d-none");
    // initHeader(); // ← 追加
  }
  if (condition.includes("下回")) {
    document.body.setAttribute(
      "data-app-header-set",
      "selectRoomTemperatureStatusUnder",
    );
    document.getElementById("section-under").classList.remove("d-none");
    // initHeader(); // ← 追加
  }
};

function renderSelectRoomTemperatureStatus(entryId) {
  console.log(entryId);
  if (entryId === "auto-3") {
    document.querySelector(".setThresholdTemp").textContent = "27℃";
  }
}

/******************************************
 * レンダリング（オートメーション編集画面）
 ******************************************/
// オートメーション編集画面
const renderAutomationEditing = () => {
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);
  renderAutomationName(entryAutoId); // オートメーション名
  renderTriggerCard(entryAutoId, entryTrigger);
  renderTriggerSection(entryAutoId, entryTrigger); // トリガーイベントセクション
  renderActionCards(entryAutoId);
  deleteBtnState(entryAutoId);
  setSelectedUsers("js-share-user-holder"); // 家電シェアユーザー
  hideActionAddition(); // 追加：アクション追加のUIを非表示にする関数
  updateCompleteButton();
};

// トリガーイベントセクションを読み込む（親関数）
const renderTriggerSection = () => {
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);
  renderTriggerButtons(entryTrigger); // トリガーイベントボタン
  renderTriggerDescription(entryTrigger); // トリガーイベント条件（文章）
  renderScheduleDays(entryAutoId); // 曜日（繰り返し）
  renderScheduleDescription(entryAutoId); // 曜日説明文
  renderScheduleStartTime(entryAutoId); // 時間
  renderLocationUsers(entryAutoId); // 通知するユーザー（家電シェアユーザー）
  renderLocationCondition(entryAutoId); // 位置条件（近づいたとき／離れたとき）
  renderTriggerEventSection(entryAutoId, entryTrigger); // トリガーイベントセクション
};

// オートメーション名を読み込む
const renderAutomationName = (entryAutoId) => {
  const el = document.getElementById("autoName");
  const automationName = getJsonValue(`${entryAutoId}.name`);
  renderElementName("#autoName", automationName, (defaultText = ""));
};

// トリガーイベントボタンの状態を読み込む
const renderTriggerButtons = (entryTrigger) => {
  updateToggleGroup("triggerBtnGroup", entryTrigger);
};

// トリガーイベント条件（文章）の表示制御
const renderTriggerDescription = (entryTrigger) => {
  const targetElement = document.querySelector(".trigger-section");
  if (!targetElement) return;
  targetElement.innerText = TRIGGER_EVENT_DESCRIPTION_MASTER[entryTrigger];
};

// 曜日をレンダリングする
function renderSchedule(entryAutoId) {
  renderScheduleDays(entryAutoId);
  renderScheduleDescription(entryAutoId);
}

// 曜日を代入
const renderScheduleDays = (entryAutoId) => {
  const targetElements = document.querySelectorAll(".day-of-the-week");
  if (!targetElements.length) return;

  // schedule.days を安全に取得
  const days = getJsonValue(`${entryAutoId}.triggers.schedule.days`) ?? [];

  targetElements.forEach((el) => {
    const day = el.dataset.appScheduleDay;
    const isActive = days.includes(day);

    el.classList.toggle("active", isActive);
    el.setAttribute("aria-pressed", String(isActive));
  });
};

// 曜日説明文を代入
function renderScheduleDescription(entryAutoId) {
  const scheduleTrigger = getJsonValue(`${entryAutoId}.triggers.schedule`);
  if (!scheduleTrigger) return;

  const days = scheduleTrigger.days ?? [];
  const description = createScheduleDescription(days);

  const descriptionElement = document.getElementById("scheduleText");
  if (!descriptionElement) return;

  descriptionElement.textContent = description;
}

//　曜日説明文を作成
function createScheduleDescription(days) {
  const allDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const dayNames = {
    sun: "日",
    mon: "月",
    tue: "火",
    wed: "水",
    thu: "木",
    fri: "金",
    sat: "土",
  };

  if (!days || days.length === 0) {
    return "一度だけ実行します";
  }

  if (days.length === 7) {
    return "毎日実行します";
  }

  const selectedDayNames = days
    .sort((a, b) => allDays.indexOf(a) - allDays.indexOf(b))
    .map((day) => dayNames[day])
    .join("");

  return `毎週${selectedDayNames}曜日に実行します`;
}

// 時間を代入
const renderScheduleStartTime = (entryAutoId) => {
  const el = document.getElementById("autoStartTime");
  const automationTime = getJsonValue(`${entryAutoId}.triggers.schedule.time`);

  if (!el) return;
  const time = automationTime?.trim();
  if (time) {
    el.textContent = time;
  } else {
    el.textContent = "12:00";
  }
};

// トリガーイベントセクションの表示／非表示
const renderTriggerEventSection = (entryAutoId, entryTrigger) => {
  document
    .querySelectorAll(".schedule-section, .location-section, .devices-section")
    .forEach((el) => (el.style.display = "none"));

  const threshold = getJsonValue(`${entryAutoId}.triggers.devices.threshold`);
  const addBtn = document.getElementById("addDeviceButton");
  const cardBtn = document.querySelector(".trigger-card-button");

  // devices以外
  if (!(entryTrigger === "devices")) {
    const key = TRIGGER_EVENT_SECTION_MASTER[entryTrigger];
    const target = document.querySelector(`.${key}`);
    if (target) target.style.display = "";
  }

  // devices
  if (entryTrigger === "devices") {
    if (!threshold) {
      addBtn.style.display = "block";
      cardBtn ? (cardBtn.style.display = "none") : null;
    } else {
      addBtn.style.display = "none";
      cardBtn.style.display = "block";
    }
  }
};

// 通知するユーザー（家電シェアユーザー）のチェックボックスを選択する
const renderLocationUsers = (entryAutoId) => {
  // location-section 内の checkbox を取得
  const checkboxes = document.querySelectorAll(
    '.location-section input[type="checkbox"]',
  );
  if (!checkboxes.length) return;

  // location trigger を取得
  const locationTrigger = getJsonValue(`${entryAutoId}.triggers.location`);
  if (!locationTrigger) return;

  const selectedUsers = locationTrigger.users || [];
  checkboxes.forEach((checkbox) => {
    const userName = checkbox.value;
    // JSON に含まれていればチェックON
    checkbox.checked = selectedUsers.includes(userName);
  });
};

// 位置条件のイベントを代入（自宅に近づいたとき／自宅から離れたとき）
const renderLocationCondition = (entryAutoId) => {
  const selectedCondition = getJsonValue(
    `${entryAutoId}.triggers.location.event`,
  );
  // UI更新用の関数
  updateToggleGroup("locationCondition", selectedCondition);
};

// トリガーカードを作成（テンプレート要素取得）
function getTriggerCardElements(clone) {
  return {
    card: clone,
    name: clone.querySelector(".name"),
    description: clone.querySelector(".description"),
  };
}

// トリガーカードを作成（UI反映）
function setTriggerCardUI(el, ui) {
  el.name.textContent = ui.name;
  el.description.textContent = ui.description;
}

// トリガーカードを作成
function renderTriggerCard(entryAutoId) {
  const device = getJsonValue(`${entryAutoId}.triggers.devices`);
  if (!device?.threshold) return;

  const section = document.getElementById("devicesSection");
  const template = document.getElementById("deviceTemplate");
  const addBtn = document.getElementById("addDeviceButton");

  if (!section || !template || !addBtn) return;

  /* 既存削除 */
  section.querySelectorAll(".trigger-card-button").forEach((el) => el.remove());

  /* clone */
  const clone = template.content.firstElementChild.cloneNode(true);

  const el = getTriggerCardElements(clone);

  /* dataset */
  el.card.dataset.deviceId = device.id;
  el.card.dataset.entryId = entryAutoId;
  el.card.dataset.triggerType = "devices";

  /* UI */
  const ui = TRIGGER_CARD_MASTER.devices(device);
  setTriggerCardUI(el, ui);

  /* 挿入 */
  section.insertBefore(clone, addBtn);

  /* ＋ボタン非表示 */
  addBtn.style.display = "none";
}

// アクションカード作成（テンプレート要素取得）
function getActionCardElements(fragment) {
  return {
    card: fragment.querySelector(".js-action-card"),
    icon: fragment.querySelector(".source"),
    name: fragment.querySelector(".name"),
    description: fragment.querySelector(".description"),
  };
}

// アクションカード作成（UI反映）
function setActionCardUI(el, ui) {
  el.icon.src = ui.icon;
  el.name.textContent = ui.name;
  el.description.textContent = ui.description;
  el.card.dataset.actionUrl = ui.url;
}

// アクションカード作成（テンプレート要素取得）
function getActionCardElements(fragment) {
  return {
    card: fragment.querySelector(".js-action-card"),
    icon: fragment.querySelector(".source"),
    name: fragment.querySelector(".name"),
    description: fragment.querySelector(".description"),
  };
}

// アクションカード作成（本体）
function renderActionCards(entryAutoId) {
  const actions = getJsonValue(`${entryAutoId}.actions`) ?? [];
  if (actions.length > 5) {
    // alert("アクションは最大5つまでです");
    return;
  }

  const area = document.getElementById("actionCardSection");
  const template = document.getElementById("actionTemplate");
  if (!area || !template) return;

  /* 既存カード削除 */
  area.querySelectorAll(".js-action-card").forEach((el) => el.remove());
  actions.slice(0, 5).forEach((action, index) => {
    const fragment = template.content.cloneNode(true);
    const el = getActionCardElements(fragment);
    if (!el.card) return;

    /* dataset */
    el.card.dataset.actionId = action.actionId;
    el.card.dataset.actionType = action.type;
    el.card.dataset.actionIndex = index;

    /* UIマスター取得 */
    const ui = ACTION_CARD_MASTER[action.type]?.(action);
    if (!ui) return;

    /* UI反映 */
    setActionCardUI(el, ui);
    area.appendChild(fragment);
  });
  updateCompleteButtonState();
}

// オートメーション削除ボタンの表示／非表示
function deleteBtnState(entryId) {
  // const entryId = getJsonValue("entryId");
  const btn = document.querySelector(".js-delete-automation-btn");
  if (!btn) return;

  if (entryId !== "new") {
    btn.style.display = "none";
    return;
  }
  const status = getJsonValue("new.status");
  btn.style.display = status ? "block" : "none";
}

// 完了ボタンの制御関数
function updateCompleteButtonState() {
  const entryId = getJsonValue("entryId");
  const headerSetKey = document.body.dataset.appHeaderSet;
  if (headerSetKey === "editAutomation" && entryId !== "new") {
    const btn = document.getElementById("headerRightBtn");
    if (!btn) return;
    btn.disabled = true;
    btn.classList.remove("active");
    btn.classList.add("disabled");
    btn.setAttribute("aria-disabled", "true");
    return;
  }

  const actions = getJsonValue(`${entryId}.actions`) ?? [];

  const btn = document.getElementById("headerRightBtn");
  if (!btn) return;

  const isActive = actions.length > 0;

  btn.disabled = !isActive;
  btn.classList.toggle("disabled", !isActive);
  btn.classList.toggle("active", isActive);
}

// オートメーション画面でカードを生成する
function renderNewAutomationCard() {
  // 新規オートメーションカードを作成する領域
  const list = document.getElementById("newAutomationCard");
  if (!list) return;

  /* すでに生成済みなら終了 */
  if (list.querySelector('[data-app-key="new"]')) return;

  const newAuto = getJsonValue("new");
  if (!newAuto) return;
  if (newAuto.status !== true) return;

  const template = document.querySelector(".js-automation-template");
  if (!template) return;

  const clone = template.cloneNode(true);

  clone.style.removeProperty("display");
  clone.classList.remove("js-automation-template");
  clone.classList.add("js-edit-automation-btn");
  clone.dataset.appKey = "new";

  /* ---------- オートメーション名 ---------- */
  const nameEl = clone.querySelector(".automationName");
  if (nameEl) {
    nameEl.textContent = newAuto.name ?? "新しいオートメーション";
  }

  /* ---------- トリガー ---------- */
  const triggerIcon = clone.querySelector(".triggerIcon");
  const triggerCondition = clone.querySelector(".triggerCondition");
  const trigger = newAuto.entryTrigger;

  if (trigger === "schedule") {
    if (triggerIcon) {
      triggerIcon.src = "../assets/img/icon-clock.svg";
    }
    const time = newAuto.triggers?.schedule?.time ?? "";
    const days = newAuto.triggers?.schedule?.days ?? [];
    const text = createScheduleDescription(days);
    if (triggerCondition) {
      triggerCondition.textContent = `${time} ${text}`;
    }
  }

  if (trigger === "devices") {
    if (triggerIcon) {
      triggerIcon.src = "../assets/img/icon_AC_40pt.svg";
    }
    const device = newAuto.triggers?.devices;
    if (triggerCondition && device) {
      triggerCondition.textContent = `${device.condition} 温度${device.threshold}℃`;
    }
  }

  if (trigger === "location") {
    if (triggerIcon) {
      triggerIcon.src = "../assets/img/icon_GPS_40.svg";
    }
    const event = newAuto.triggers?.location?.event;
    if (triggerCondition) {
      triggerCondition.textContent =
        event === "close" ? "自宅に近づいたとき" : "自宅から離れたとき";
    }
  }

  /* ---------- アクション ---------- */
  const actionIconsContainer = clone.querySelector(".col-5");

  if (actionIconsContainer) {
    actionIconsContainer.innerHTML = ""; // 既存をクリア
  }

  const actions = newAuto.actions ?? [];
  const MAX = 3;

  actions.forEach((action, index) => {
    if (index >= MAX) return;

    let iconSrc = "";

    if (actions.length > MAX && index === MAX - 1) {
      iconSrc = "../assets/img/btn-others.svg";
    } else {
      if (action.type === "devices") {
        iconSrc = DEVICE_MASTER[action.id]?.icon ?? "";
      }
      if (action.type === "notify") {
        iconSrc = ACTION_MASTER.notify.icon;
      }
      if (action.type === "scene") {
        iconSrc = SCENE_MASTER[action.id]?.icon ?? "";
      }
    }

    if (!iconSrc) return;

    const img = document.createElement("img");
    img.src = iconSrc;

    actionIconsContainer.appendChild(img);
  }); /* ---------- 挿入 ---------- */
  list.style.display = "block";
  list.appendChild(clone);
}

// トリガーカードを削除する（しきい値が…）
function deleteTriggerCard(entryAutoId) {
  setJsonValue(`${entryAutoId}.triggers.devices`, {});
  renderAutomationEditing();
}

// アクションカードの内容を編集画面に反映させる
function initDeviceEditor() {
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  const { entryId, actionId, actions, action } = entryData;
  if (!action) return;

  /* 初期値 エアコン */
  const entryTrigger = getJsonValue(`${entryId}.entryTrigger`);
  if (action.id?.startsWith("rac")) {
    action.drive ??= "on";
    action.mode ??= "冷房";
    action.temp ??= "28.0";

    if (entryTrigger === "location") {
      action.description ??= buildDescription(action, entryTrigger);
    }
  }

  /* 初期値 給湯機 */
  if (action.id?.startsWith("eq")) {
    action.drive ??= "on";
  }
  setJsonValue(`${entryId}.actions`, actions);
}

function renderDeviceEditor() {
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  const { entryId, actions, action } = entryData;

  // 機器名
  const deviceName = document.getElementById("deviceName");
  if (deviceName)
    deviceName.textContent = DEVICE_MASTER[action.id]?.label ?? "";
  /* 運転ボタン */
  const driveBtn = document.querySelector(`[data-app-drive="${action.drive}"]`);
  driveBtn?.classList.add("active");
  /* モード */
  const modeBtn = document.querySelector(
    `.js-rac-mode[data-app-mode="${action.mode}"]`,
  );
  modeBtn?.classList.add("active");
  /* 温度 */
  const tempInput = document.querySelector(".js-temp");
  if (tempInput) tempInput.textContent = action.temp + "℃";
  /* 起動温度 */
  const currentTriggerEvent = getJsonValue("currentTriggerEvent");
  const startupTempSection = document.querySelector(".startTemperatureSection");
  const startupTempInput = document.querySelector(".js-startup-temp");

  if (currentTriggerEvent === "location") {
    if (startupTempSection && startupTempInput) {
      // startupTempSection.classList.remove("d-none");
      action.startupTemp ??= "28.0"; // 初期値 起動温度
      // action.startupTemp = action.mode === "暖房" ? "18.0" : "28.0";
      startupTempInput.textContent = action.startupTemp + "℃";
    }
  }
  updateRacControlState(driveBtn);
  renderStartTemperatureSection(action.mode, entryId);
}

// オートメーション削除の確認モーダルの「削除する」ボタンをクリック
document.addEventListener("click", (e) => {
  const btn = e.target.closest("#confirmDeleteAutomationBtn");
  if (!btn) return;
  setJsonValue("navigationMode", "complete");
  deleteAutomationCard();
});

// オートメーション削除後にappDataの内容を上書きする
function deleteAutomationCardUpdate() {
const appDataEdit = JSON.parse(sessionStorage.getItem("appDataEdit") || "{}");
if (appDataEdit.new !== undefined) {
  const appData = JSON.parse(sessionStorage.getItem("appData") || "{}");
  appData.new = appDataEdit.new;
  sessionStorage.setItem("appData", JSON.stringify(appData));
}}


// オートメーション削除関数
function deleteAutomationCard() {
  setJsonValue("new", {
    status: false,
    entryTrigger: "schedule",
    name: "オートメーション", // オートメーション名
    triggers: {
      schedule: {
        time: "12:00",
        days: [],
      },
      devices: {
        id: "",
        name: "",
        condition: "",
        threshold: null,
      },
    },
    actions: [],
  });
  deleteAutomationCardUpdate();
  window.location.href = "../automation/";
}
// 完了ボタンの制御関数（entryIdがnewのとき、actionsの数に応じて活性化）
function updateCompleteButtonState(entryId) {
  if (entryId !== "new") return false;
  const actions = getJsonValue("new.actions");
  return Array.isArray(actions) && actions.length > 0;
}

// 通知設定を選択する画面の初期値を設定
function initNotifyEditor() {
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  const { entryId, actionId, actions, action } = entryData;
  if (!action || action.type !== "notify") return;
  const notice = NOTICE_MASTER[action.id] ?? {};

  // id が無い場合の初期値
  action.id ??= "notify-1";

  renderLocationUsers(entryId);
}

// 起動室温
// function renderRacStartTemperature() {
//   const currentTriggerEvent = getJsonValue("currentTriggerEvent");
//   const startUpTemp = document.querySelector(".js-startup-temp");
// 起動室温セクション
// const startTemperatureSection = document.getElementById(
//   "startTemperatureSection",
// );
// if (!currentTriggerEvent) return;
// if (currentTriggerEvent === "location") {
// startTemperatureSection.classList.remove("d-none");
// renderElementName(".js-startup-temp", "28.0", (defaultText = ""));
//   }
// }

//　アクションカードを削除するときに表示されるモーダル内の描画
function renderDeleteActionCardModal(actionCard) {
  // 対象カード取得
  if (!actionCard) return;
  // カード内の情報取得
  const iconSrc = actionCard.querySelector("img")?.src || "";
  const name = actionCard.querySelector(".name")?.textContent || "";
  const description =
    actionCard.querySelector(".description")?.textContent || "";
  // モーダル取得
  const modalEl = document.getElementById("deleteActionCardButton");
  // モーダル内を書き換え
  modalEl.querySelector("img").src = iconSrc;
  modalEl.querySelector(".name").textContent = name;
  modalEl.querySelector(".description").textContent = description;
  modalEl.querySelector(".deleteActionCardButtonMsg").textContent =
    DELETE_MODAL_MESSAGE_MASTER[actionCard.dataset.actionType] || "";
}

//　アクションカードを削除するときに表示されるモーダル内の描画
function rendertemperatureSettingModal(entryId) {
  const modalEl = document.getElementById("temperatureOverModal");
  if (!modalEl) return;
  const imgEl = modalEl.querySelector(".temperatureOverModal");
  if (!imgEl) return;
  console.log(entryId);

  if (entryId === "auto-3") {
    imgEl.src = "../assets/img/modal-set-temperature-27.svg";
  } else {
    imgEl.src = "../assets/img/temperatureOverModal.svg";
  }
}

// ホーム画面 機器カードのクリックイベント（アプリへ遷移）
document.querySelectorAll(".card").forEach((card) => {
  card.addEventListener("click", () => {
    // オートメーション編集画面へ
    // window.location.href = "https://www.mitsubishielectric.co.jp/home/mymu/index.html";
  });
});

// ホーム画面 機器カードのトグルスイッチON／OFF
document.querySelectorAll(".js-app-card-toggle").forEach((toggle) => {
  toggle.addEventListener("click", (e) => {
    e.stopPropagation(); // カードクリック防止
    const currentState = e.target.checked; // 変更後の状態
    // アラート表示
    // alert("デモアプリではこのボタンは操作できません。");
    // 状態を元に戻す
    // toggle.checked = !currentState;
  });
});

// ホーム画面 機器カードのクリックイベント（アプリへ遷移）
document.querySelectorAll(".app-card").forEach((card) => {
  card.addEventListener("click", () => {
    const key = card.dataset.appKey;
    if (!key) return;
    let url = "";
    switch (key) {
      case "rac-1":
      case "rac-2":
        url = "https://www.mitsubishielectric.co.jp/home/mymu/demo/rac/";
        break;
      case "eq":
        url = "https://www.mitsubishielectric.co.jp/home/mymu/demo/eq/";
        break;
      case "ref":
        url =
          "https://www.mitsubishielectric.co.jp/home/reizouko/function/mymu/ref/#/";
        break;
      default:
        return;
    }
    window.location.href = url;
  });
});

//　ホーム画面のカードのトグルをオン・オフしたときに表示されるモーダル内の描画
function renderConfirmToggleModal(appCardId) {
  // 対象カード取得
  if (!appCardId) return;
  // カード内の情報取得
  const iconSrc = DEVICE_MASTER[appCardId]?.icon || "";
  const name = DEVICE_MASTER[appCardId]?.label || "";
  const description = CARD_MASTER[appCardId] || "";
  // モーダル取得
  const modalEl = document.getElementById("confirmToggleModal");
  // モーダル内を書き換え
  modalEl.querySelector("img").src = iconSrc;
  modalEl.querySelector(".name").textContent = name;
  modalEl.querySelector(".description").textContent = description;
}

//　モーダル（操作しますか？）で実行ボタンをクリック
function confirmToggleButton() {
  const appCardId = appState.appCardId;
  const appCard = appState.appCard;
  const isOn = appState.nextState;
  let cardOnStatus = getJsonValue("cardOnStatus") || [];
  if (isOn) {
    // ON → 配列に追加（重複防止）
    if (!cardOnStatus.includes(appCardId)) {
      cardOnStatus.push(appCardId);
    }
  } else {
    // OFF → 配列から削除
    cardOnStatus = cardOnStatus.filter((id) => id !== appCardId);
  }
  setJsonValue("cardOnStatus", cardOnStatus);
  appCard.checked = appState.nextState;
  // モーダルを閉じる
  const modalEl = document.getElementById("confirmToggleModal");
  const modal = bootstrap.Modal.getInstance(modalEl);
  modal.hide();
}

// ホーム画面 機器カードのレンダリング（トグルスイッチの状態を取得）
function renderHome() {
  const cards = document.querySelectorAll(".app-card");
  cards.forEach((card) => {
    const cardId = card.dataset.appKey;
    // セッションストレージから状態取得
    const activeIds = getJsonValue("cardOnStatus") || [];
    const toggle = card.querySelector(".js-app-card-toggle");
    const isOn = activeIds.includes(cardId);
    // トグル状態
    if (toggle) {
      toggle.checked = isOn;
    }
  });
}

// シーンを選択 画面のレンダリング
function renderSelectScene() {
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  const sceneId = entryData.actions.find((a) => a.type === "scene")?.id;
  if (sceneId) {
    document.querySelectorAll(".js-select-scene-btn").forEach((btn) => {
      const key = btn.dataset.appKey; // （ allOff | sleep | returnWinter ）
      const body = btn.querySelector(".scene-card-body"); // 不透明度を設定する領域
      const info = btn.querySelector(".info-icon"); // infoアイコンを表示する領域
      const added = btn.querySelector(".added-text"); // 「追加済み」を表示する領域

      const isSelected = key === sceneId;
      const hasScene = !!sceneId;

      // sceneがある場合カードを非活性
      body.classList.toggle("scene-disabled", hasScene);
      // infoアイコン表示
      info.classList.toggle("d-none", isSelected);
      // 追加済み表示
      added.classList.toggle("d-none", !isSelected);
      // ボタンを選択不可にする
      btn.disabled = true;
    });
  }
  combinationCheckScene();
}

// 機器の操作を追加 した場合、機器の状態を追加 で機器を選択できるようにする
function combinationCheckDeviceAble() {}

// 機器とシーンの組み合わせチェック（機器の操作を追加）
function combinationCheckDevice() {
  const entryData = getAutomationEntryData();
  const sceneId = entryData?.actions.find((a) => a.type === "scene")?.id;
  if (!sceneId) return;

  // デバイス要素の取得
  const devices = {
    rac1: document.querySelector(
      '.js-select-device-btn[data-app-device="rac-1"]',
    ),
    rac2: document.querySelector(
      '.js-select-device-btn[data-app-device="rac-2"]',
    ),
    eq: document.querySelector('.js-select-device-btn[data-app-device="eq"]'),
  };

  // 無効化処理の共通関数
  const disableDevice = (el) => {
    if (!el) return;
    el.disabled = true;
    el.querySelector(".icon-devices")?.classList.add("scene-disabled");
    el.querySelector(".name")?.classList.add("scene-disabled");
    el.querySelector(".icon-info")?.classList.remove("d-none");
  };

  // 条件に応じた無効化の実行
  if (sceneId === "allOff") {
    [devices.rac1, devices.rac2, devices.eq].forEach(disableDevice);
  } else if (sceneId === "sleep" || sceneId === "returnWinter") {
    [devices.rac1, devices.eq].forEach(disableDevice);
  }
}

// シーンと機器の組み合わせチェック（シーンの操作を追加）
function combinationCheckScene() {
  const entryData = getAutomationEntryData();
  const devicesId = entryData?.actions.find((a) => a.type === "devices")?.id;
  if (!devicesId) return;

  // // デバイス要素の取得
  const scene = {
    allOff: document.querySelector(
      '.js-select-scene-btn[data-app-key="allOff"]',
    ),
    sleep: document.querySelector('.js-select-scene-btn[data-app-key="sleep"]'),
    returnWinter: document.querySelector(
      '.js-select-scene-btn[data-app-key="returnWinter"]',
    ),
  };

  // 無効化処理の共通関数
  const disableScene = (el) => {
    if (!el) return;
    el.disabled = true;
    el.querySelector(".icon-scene")?.classList.add("scene-disabled");
    el.querySelector(".name")?.classList.add("scene-disabled");
    el.querySelector(".info-icon")?.classList.remove("d-none");
  };

  // 無効化処理の共通関数
  const ableScene = (el) => {
    if (!el) return;
    el.querySelector(".added-text")?.classList.remove("d-none");
  };

  // // 条件に応じた無効化の実行
  if (devicesId === "rac-1" || devicesId === "eq") {
    [scene.allOff, scene.sleep, scene.returnWinter].forEach(disableScene);
  } else if (devicesId === "rac-2") {
    [scene.allOff].forEach(disableScene);
  }
}

// 同じ機器IDは登録できない（登録済みの機器IDを返す）
function combinationDuplicateDevices(entryDeviceCard) {
  if (entryDeviceCard !== "action") return;

  const entryData = getAutomationEntryData();
  if (!entryData) return;

  // 登録済み機器ID取得
  const deviceIds =
    entryData.actions?.filter((a) => a.type === "devices").map((a) => a.id) ||
    [];

  // デバイス要素
  const devices = {
    "rac-1": document.querySelector(
      '.js-select-device-btn[data-app-device="rac-1"]',
    ),
    "rac-2": document.querySelector(
      '.js-select-device-btn[data-app-device="rac-2"]',
    ),
    eq: document.querySelector('.js-select-device-btn[data-app-device="eq"]'),
  };

  // 無効化関数
  const disableDevice = (el) => {
    if (!el) return;

    el.disabled = true;
    el.querySelector(".icon-devices")?.classList.add("scene-disabled");
    el.querySelector(".name")?.classList.add("scene-disabled");
    el.querySelector(".added-device")?.classList.remove("d-none");
  };

  // 登録済み機器を無効化
  deviceIds.forEach((id) => {
    disableDevice(devices[id]);
  });
}

/******************************************
 * クリックイベント
 ******************************************/
document.addEventListener("click", (e) => {
  // オートメーション情報を取得
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  const { entryId, actionId, actions, action } = entryData;
  // ボタン取得
  const el = e.target;
  const addAutoBtn = el.closest(".md-add-auto-btn"); // オートメーションを追加
  const autoBtn = el.closest(".md-auto-btn"); // auto-1〜3
  const tempBtn = el.closest(".md-temp-btn"); // temp-1〜6
  const newBtn = el.closest(".md-new-btn"); // new
  const selectSceneBtn = el.closest(".js-select-scene-btn"); // シーンを選択（外出一括オフ、就寝、冬の帰宅）
  const selectDaviceBtn = el.closest(".js-select-device-btn"); // 機器を選択（ac-1, rac-2, eq）
  const driveRacBtn = el.closest(".js-rac-drive"); // エアコン（運転）
  const modeRacBtn = el.closest(".js-rac-mode"); // エアコン（モード）
  const driveEqBtn = el.closest(".js-eq-drive"); // 給湯機（運転）
  const thresholdBtn = e.target.closest(".js-threshold-btn"); // しきい値を超えたとき／下回ったとき
  const entryDeviceCard = e.target.closest(".entry-device-card"); // 「機器の状態を追加」のクリックイベント（trigger／actionの入口を登録）
  const triggerEventBtn = e.target.closest(".js-trigger-event-btn"); // トリガーイベントボタンのクリックイベント（スケジュール／位置情報／機器）
  const dayBtn = e.target.closest(".day-of-the-week"); // 曜日のクリックイベント
  const locationConditionBtn = e.target.closest(".js-location-condition"); // 自宅に近づいたとき、離れたとき
  const completeBtn = e.target.closest(".js-complete-btn"); // オートメーション編集画面の完了ボタン
  const setTempCoolingBtn = e.target.closest(".set-temp-cooling-btn"); // 設定温度変更ボタン
  const checkExistingAutomation = e.target.closest(".js-new-automation-btn"); // デモアプリでは新規オートメーションは一つまでしか作成できません
  const temperatureOverModal = e.target.closest(".temperatureOverModal"); // 設定温度のモーダルで表示する画像を変更する（auto-3のみ27℃）

  // 設定温度のモーダルで表示する画像を変更する（auto-3のみ27℃）
  if (temperatureOverModal) {
    rendertemperatureSettingModal(entryId);
  }

  // オートメーション編集画面の完了ボタン
  if (completeBtn) {
    const entryId = getJsonValue("entryId");
    if (
      document.body.dataset.appHeaderSet === "editAutomation" &&
      entryId !== "new"
    ) {
      setJsonValue("navigationMode", "back");
      window.location.href = "../automation/";
      return;
    }
    const btn = document.body.dataset.appHeaderSet;
    updateAppData();
    window.location.href = COMPLETE_BTN_MASTER[btn];
  }

  // 新規オートメーションは一つまでしか作成できない
  if (checkExistingAutomation) {
    backToAutomationScreen();
  }

  // エアコン温度設定ボタン表示
  if (setTempCoolingBtn) {
    showModal("temperatureSettingModal");
  }

  // 自宅に近づいたとき、離れたとき
  if (locationConditionBtn) {
    const condition = locationConditionBtn.dataset.appLocationCondition;
    let locationTrigger = getJsonValue(`${entryId}.triggers.location`) ?? {};
    locationTrigger.event = condition;
    setJsonValue(`${entryId}.triggers.location`, locationTrigger);
    renderLocationCondition(entryId);
    updateCompleteButton();
    // window.location.href = "../select-device-operation/";
  }

  // 曜日のクリックイベント
  if (dayBtn) {
    const entryAutoId = getJsonValue("entryId");
    const day = dayBtn.dataset.appScheduleDay;
    toggleScheduleDay(entryAutoId, day);
  }

  // トリガーの状態をクリア
  const clearOtherTriggers = (entryAutoId, selectedKey) => {
    const triggers = ["schedule", "location", "devices"];

    triggers.forEach((trigger) => {
      if (trigger !== selectedKey) {
        // スケジュールを初期化（appDataEdit）
        if (trigger === "schedule") {
          setJsonValue(`${entryAutoId}.triggers.${trigger}`, {
            time: "12:00",
            days: [],
          });
          // 位置情報を初期化（appDataEdit）
        } else if (trigger === "location") {
          setJsonValue(`${entryAutoId}.triggers.${trigger}`, {
            users: ["お父さん"],
          });
        } else if (trigger === "devices") {
          setJsonValue(`${entryAutoId}.triggers.${trigger}`, {
            id: "",
            name: "",
            condition: "",
            threshold: null,
          });
        }
      }
    });
  };

  // トリガーイベントボタンのクリックイベント（スケジュール／位置情報／機器）
  if (triggerEventBtn) {
    const key = triggerEventBtn.dataset.appKey;
    const entryAutoId = getJsonValue("entryId");

    // ★ 他トリガーの状態をクリア
    // clearOtherTriggers(entryAutoId, key);

    // schedule選択時は説明文レンダリング用の初期値を保証する
    if (key === "schedule") {
      const schedulePath = `${entryAutoId}.triggers.schedule`;
      const schedule = getJsonValue(schedulePath) ?? {};
      setJsonValue(schedulePath, {
        time: schedule.time ?? "12:00",
        days: Array.isArray(schedule.days) ? schedule.days : [],
      });
    }

    setJsonValue(`${entryAutoId}.entryTrigger`, key);
    setJsonValue("currentTriggerEvent", key);
    renderTriggerSection();
    updateCompleteButton();
  }

  // 「機器の状態を追加」のクリックイベント（trigger／actionの入口を登録）
  if (entryDeviceCard) {
    const key = entryDeviceCard.dataset.appKey;
    setJsonValue(`${entryId}.entryDeviceCard`, key);
    saveSnapshot(); // entryDeviceCard を含む状態をスナップショットに保存
    window.location.href = "../select-device/";
  }

  // オートメーションを追加 ボタンjs-eq-drive
  if (addAutoBtn) {
    window.location.href = "../proposal-automation/";
  }

  // しきい値を超えたとき／下回ったとき
  else if (thresholdBtn) {
    const key = thresholdBtn.dataset.appKey;
    setJsonValue(
      `${entryId}.triggers.devices.condition`,
      THRESHOLD_MASTER[key].label,
    );
    // auto-3（室温が〜℃のとき）以外は、しきい値を初期化する
    if (entryId !== "auto-3") {
      setJsonValue(
        `${entryId}.triggers.devices.threshold`,
        THRESHOLD_MASTER[key].tempture,
      );
    }

    setJsonValue(`${entryId}.entryTrigger`, "devices");
    setJsonValue("currentTriggerEvent", "devices");
    window.location.href = "../select-room-temperature-status/";
  }

  // 給湯機（運転）
  else if (driveEqBtn) {
    const drive = driveEqBtn.dataset.appDrive;
    action.drive = drive;
    setJsonValue(`${entryId}.actions`, actions); // JSON保存
    updateToggleGroup("driveBtnGroup", action.drive); // UI排他
    updateCompleteButton();
  }

  // エアコン（モード）
  else if (modeRacBtn) {
    handleModeClick(modeRacBtn);
  }

  // エアコン（運転）
  else if (driveRacBtn) {
    handleDriveClick(driveRacBtn);
  }

  // 機器を選択（rac-1, rac-2, eq）
  else if (selectDaviceBtn) {
    // const key = selectDaviceBtn.dataset.appKey; // trigger
    const entryId = getJsonValue("entryId");
    const entryDeviceCard = getJsonValue(`${entryId}.entryDeviceCard`);
    const deviceId = selectDaviceBtn.dataset.appDevice; // rac-1 / rac-2 / eq
    const newAction = { actionId: createId(), type: "devices", id: deviceId };
    actions.push(newAction);
    // アクションから遷移した場合であればJSONを準備しておく
    if (entryDeviceCard === "action") {
      setJsonValue(`${entryId}.actions`, actions);
      actions.push(actions);
      setJsonValue("editActionId", newAction.actionId);
    }

    // トリガーから遷移した場合
    if (entryDeviceCard === "devices") {
      window.location.href = "../select-device-operation/";
    } else if (entryDeviceCard === "action" && deviceId.startsWith("rac")) {
      window.location.href = "../device-settings-rac/";
    } else if (entryDeviceCard === "action" && deviceId.startsWith("eq")) {
      window.location.href = "../device-settings-eq/";
    }
  }

  // シーンを選択（外出一括オフ、就寝、冬の帰宅）
  else if (selectSceneBtn) {
    const key = selectSceneBtn.dataset.appKey; // allOff / sleep / returnWinter
    const newAction = { actionId: createId(), type: "scene", id: key };
    actions.push(newAction);
    setJsonValue(`${entryId}.actions`, actions);
    setJsonValue("editActionId", newAction.actionId);
    window.location.href = "../setup-scene/";
  }

  // auto-1〜3
  else if (autoBtn) {
    const key = autoBtn.data.appKey;
    setJsonValue("entryId", key); // entryIdをセット
    // スナップショットを作成する
    createAppDataSnapshotBase();
    window.location.href = "../proposal-automation/";
  }
  // temp-1〜6
  else if (tempBtn) {
    const key = tempBtn.dataset.appKey;
    const entryTrigger = tempBtn.dataset.appEntryTrigger;
    setJsonValue("entryId", key); // entryIdをセット
    setJsonValue("currentTriggerEvent", entryTrigger); // currentTriggerEventをセット
    // スナップショットを作成する
    createAppDataSnapshotBase();
    window.location.href = "../edit-automation/";
  }
  // new
  else if (newBtn) {
    if (isNewAutomationExist()) {
      alert("デモアプリでは新規オートメーションは一つまでしか作成できません。");
      return; // ← 遷移させない
    }
    const key = newBtn.dataset.appKey;
    setJsonValue("entryId", key); // entryIdをセット
    setJsonValue("editActionId", null); // editActionIdをセット
    // スナップショットを作成する
    createAppDataSnapshotBase();
    window.location.href = "../edit-automation/";
  }
});

// 現在の編集用JSONをスナップショットにコピーする
function saveSnapshot() {
  const draft = sessionStorage.getItem("appDataEdit");
  // console.log("📸 [Save] 保存前のEditデータ:", draft ? JSON.parse(draft) : "空です"); // 追加
  if (draft) {
    sessionStorage.setItem("appDataSnapshot", draft);
  }
}

// 画面内の「遷移するボタン」すべてに保存処理を紐付ける
document.querySelectorAll(".btn-save-state").forEach((button) => {
  button.addEventListener("click", () => {
    saveSnapshot();
    // ここでボタン本来の遷移処理などが続く
  });
});

// 戻るボタンで戻ってきたか？（ヒストリーを利用）
function handleBackNavigation(event) {
  const returnMode = sessionStorage.getItem("appDataReturnMode");
  const backup = sessionStorage.getItem("appDataSnapshot");

  // 子画面から戻るときは、明示フラグを優先して復元有無を判断する
  if (returnMode === "cancel") {
    if (backup) {
      sessionStorage.setItem("appDataEdit", backup);
    }
    sessionStorage.removeItem("appDataReturnMode");
    return;
  }

  if (returnMode === "keep") {
    sessionStorage.removeItem("appDataReturnMode");
    return;
  }

  const isBack =
    event.persisted ||
    performance.getEntriesByType("navigation")[0]?.type === "back_forward";
  if (isBack) {
    // alert("戻る操作を検知");
    if (backup) {
      sessionStorage.setItem("appDataEdit", backup);
      // alert("データを復元");
    }
  }
}

// エアコンの操作設定（起動室温の操作）
function renderStartTemperatureSection(mode, entryId) {
  const entryTrigger = getJsonValue(`${entryId}.entryTrigger`);
  if (entryTrigger !== "location") return;
  const isCooling = mode === "冷房";
  const isHeating = mode === "暖房";
  if (!isCooling && !isHeating) return;
  // 表示の切り替え
  document
    .getElementById("startTemperatureCool")
    .classList.toggle("d-none", !isCooling);
  document
    .getElementById("startTemperatureHeat")
    .classList.toggle("d-none", !isHeating);
  // ラベルの更新
  document.querySelector(".js-startup-temp-label").textContent =
    `${mode}起動温度`;
  document.querySelector(".startTemperatureSection").classList.remove("d-none");
  //　起動温度の更新
  if (isCooling) {
    document.querySelector(".js-startup-temp").textContent = "28.0℃";
  } else if (isHeating) {
    document.querySelector(".js-startup-temp").textContent = "18.0℃";
  }
}

// 通知内容のクリックイベント（ラジオボタン）notify-modal
const notifyModal = document.querySelector(".notify-modal");
if (notifyModal) {
  notifyModal.addEventListener("change", (e) => {
    if (e.target.checked) {
      showModal("textNotificationModal");
    }
  });
}

// 家電シェアユーザーの選択⇒ JSON登録の処理（通知先の同処理から展開）
function setSelectedUsers(parentClass) {
  const entryId = getJsonValue("entryId");
  const pathMap = {
    "js-share-user-holder": `${entryId}.triggers.location.users`,
    "js-notify-user-holder": `${entryId}.triggers.location.users`,
  };
  const jsonPath = pathMap[parentClass];
  // 親要素取得
  const parent = document.querySelector(`.${parentClass}`);
  if (!parent) return;
  // JSONから初期値取得
  appState.selectedUsers = getJsonValue(jsonPath) || ["お父さん"];
  parent.querySelectorAll(".js-share-user").forEach((checkbox) => {
    checkbox.addEventListener("change", (e) => {
      const name = e.target.dataset.appKey;
      if (e.target.checked) {
        // 追加（重複防止）
        if (!appState.selectedUsers.includes(name)) {
          appState.selectedUsers.push(name);
        }
      } else {
        // 削除
        appState.selectedUsers = appState.selectedUsers.filter(
          (user) => user !== name,
        );
      }
      setJsonValue(jsonPath, appState.selectedUsers);
    });
  });
}

function clearSnapshot() {
  sessionStorage.removeItem("appDataSnapshot");
}
// オートメーション画面に戻ったとき、編集用とスナップ用のJSONを比較して変更がなければスナップ用⇒ 編集用
function resetAppDataJson() {
  const mode = getJsonValue("navigationMode");
  // snapshot取得
  const snapshot = sessionStorage.getItem("appDataSnapshotBase");

  if (mode === "back") {
    if (snapshot) {
      const parsed = JSON.parse(snapshot);
      sessionStorage.setItem("appDataEdit", JSON.stringify(parsed));
      // setJsonValue("appDataEdit", parsed);
      // console.log("バックされました");
    }
    // clearSnapshot();
  }

  if (mode === "complete") {
    const edit = getJsonValue("appDataEdit");
    if (edit) {
      sessionStorage.setItem("appData", JSON.stringify(edit));
      // setJsonValue("appData", edit);
    }
    // clearSnapshot();
  }
  // console.log(snapshot);
}

// アクション追加領域を非表示
function hideActionAddition() {
  // 現在のアクション数を取得
  const actionCount = document.querySelectorAll(".js-action-card").length;
  // 追加ボタン要素
  const addButtons = document.querySelectorAll(".js-action-btn-el");
  if (actionCount >= 6) {
    // 5件以上 → 非表示
    addButtons.forEach((el) => el.classList.add("d-none"));
  } else {
    // 5件未満 → 表示
    addButtons.forEach((el) => el.classList.remove("d-none"));
  }
}

// スナップショットを作成する
function createAppDataSnapshotBase() {
  const draft = sessionStorage.getItem("appData");
  if (draft) {
    sessionStorage.setItem("appDataSnapshotBase", draft);
  }
}

function backToAutomationScreen() {
  if (isNewAutomationExist()) {
  }
  // window.location.href = "../automation/";
}

// 新規オートメーションは一つまでしか作成できない
function isNewAutomationExist() {
  const entryData = getAutomationEntryData();
  if (!entryData) return;
  const { entryId, actionId, actions, action } = entryData;
  return entryId === "new" && actions.length > 0;
}

function renderScheduleTimeModal(entryId) {
  const modalEl = document.getElementById("scheduleTimeModal");
  if (!modalEl) return;
  const imgEl = modalEl.querySelector(".modal-set-time");
  if (!imgEl) return;
  const src =
    SCHEDULE_TIME_MODAL_MASTER[entryId] ?? SCHEDULE_TIME_MODAL_MASTER.new;
  if (!src) return;
  imgEl.src = src;
}

/******************************************
 * クリックイベント（シーン関連）
 ******************************************/
// 状態管理用オブジェクト
const sceneDeviceStatus = {
  deviceId: null,
  drive: null,
  id: null,
  mode: null,
  name: null,
  status: null,
  temp: null,
  types: null,
}

document.addEventListener("click", (e) => {
  const el = e.target;

  // 新規シーンを追加（シーン作成画面／カスタムシーン作成ボタン）
  const addNewSceneBtn = el.closest(".js-new-scene-btn"); 
  if (addNewSceneBtn) {
    window.location.href = "../edit-scene/";
  };

  // シーン作成で機器を追加（シーン編集／機器を選択して操作を追加ボタン）
  const addNewSceneDevicesBtn = el.closest(".js-new-scene-devices-btn"); 
  if (addNewSceneDevicesBtn) {
    window.location.href = "../select-device-scene/";
  };

  // シーン作成で機器をクリック（機器の操作を選択／リビング・寝室のエアコン、給湯機）
  const selectDevice = el.closest(".js-select-scene-device-btn"); 
  if (selectDevice) {
    const deviceId = selectDevice.dataset.appDevice; // rac-1 / rac-2 / eq
    window.location.href = DEVICE_MASTER[deviceId].settingsScene;
    setJsonValue("entryDeviceCardScene", deviceId);
  };

  // シーン作成で機器の運転をクリック（機器の操作を選択／リビング・寝室のエアコン、給湯機）
  const driveBtnScene = el.closest(".js-drive-scene"); // 給湯機（運転）
  if (driveBtnScene) {
    const drive = driveBtnScene.dataset.appDrive;
    sceneDeviceStatus.drive = drive;
    // setJsonValue(`${entryId}.actions`, actions); // JSON保存
    updateToggleGroup("driveBtnGroupScene", sceneDeviceStatus.drive); // UI排他
    // updateCompleteButton();
  };

  // シーン作成で機器のモードをクリック（機器の操作を選択／リビング・寝室のエアコン、給湯機）
  const modeBtnScene = el.closest(".js-mode-scene"); // 給湯機（運転）
  if (modeBtnScene) {
    const mode = modeBtnScene.dataset.appMode;
    sceneDeviceStatus.mode = mode;
    // setJsonValue(`${entryId}.actions`, actions); // JSON保存
    updateToggleGroup("modeBtnGroupScene", sceneDeviceStatus.mode); // UI排他
    // updateCompleteButton();
  };

  // シーン作成で機器をクリック（機器の操作を選択／リビング・寝室のエアコン、給湯機）
  const selectIcon = el.closest(".js-select-scene-icon-btn"); 
  if (selectIcon) {
    // const deviceId = selectDevice.dataset.appDevice; // rac-1 / rac-2 / eq
    window.location.href = "../select-icon/";
    // setJsonValue("entryDeviceCardScene", deviceId);
  };
  
})


// 機器IDを取得して、シーン編集画面に遷移する際に、機器の操作を選択する画面に遷移する
function initDeviceEditorScene() {
  const entryDataScene = getJsonValue("entryDeviceCardScene");
  const customeSceneDevicesArray = getJsonValue("customScene.devices") ?? [];
  const scene = customeSceneDevicesArray.find((a) => a.id === entryDataScene);

  document.getElementById("deviceName").textContent = scene.name ?? ""; // 機器名を代入
  document.querySelector(`[data-app-drive="${scene.drive}"]`)?.classList.add("active"); // 運転を描画
  document.querySelector(`.js-mode-scene[data-app-mode="${scene.mode}"]`)?.classList.add("active"); // モードを描画
  const settingTemp = document.getElementById("racSettingTemperature");     // 設定温度を定義
  if (settingTemp) settingTemp.textContent = ` ${scene.temp}℃` ?? "";   // 設定温度を代入

}

// 
function renderDeviceEditorScene() {

  // const deviceName = document.getElementById("deviceName");     // 機器名を設定
  // const deviceNameScene = getJsonValue("entryDeviceCardScene"); // 機器ID（rac-1 / rac-2 / eq）を設定

  // if (!deviceName) return;
  // deviceName.textContent = DEVICE_MASTER[deviceNameScene]?.label ?? "";   // 機器名を代入
  
  // const mode = getJsonValue("entryDeviceCardSceneMode"); // 運転モード（冷房／暖房／給湯）を取得
  // const driveBtn = document.querySelector(`[data-app-drive="${action.drive}"]`);
  // driveBtn?.classList.add("active");

}

// カスタムシーン編集画面のカードボタンを生成
function renderCustomSceneCard() {

  getJsonValue("customScene.devices")?.forEach((device) => {
    // const cardContainer = document.getElementById("customSceneCardContainer");
    if (!device.status) return;

    const deviceId = device.id;
    const deviceDrive = device.drive;
    const template = document.getElementById("sceneTemplate");
    // template の中身を複製
    const fragment = template.content.cloneNode(true);
    const container = document.getElementById("sceneCardContainer");
    if (!template || !container) return;
    const button = fragment.querySelector(".custom-scene-button");

    // data属性
    button.dataset.sceneDevice = deviceId;
    console.log(button.dataset.sceneDevice);


    // 表示テキストと画像
    // fragment.querySelector(".source").src = device.iconSrc;
    // fragment.querySelector(".source").alt = device.name;

    // マスターから取得
    const name = CUSTOM_SCENE_MASTER[deviceId].label;   // 機器名称
    const iconSrc = CUSTOM_SCENE_MASTER[deviceId].icon; // 機器アイコン
    const mode = CUSTOM_SCENE_MASTER[deviceId][deviceDrive];     // 運転モード状態
    const temp = CUSTOM_SCENE_MASTER[deviceId].temp ?? "";     // 設定温度
    let description = ""; // 初期値として空文字列を設定

    // descriptionの内容を条件に応じて設定
    if (device.drive === "off" ) {
      description = CUSTOM_SCENE_MASTER[deviceId].off;
    } else if (device.drive === "on" ) {
      description = `${CUSTOM_SCENE_MASTER[deviceId].on} ${mode} ${temp}`;
    } 
    fragment.querySelector(".description").textContent = description;
     container.appendChild(fragment);

  });


}
