/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/alert.txt").then((r) => r.text()),
      fetch("../../partials/header.txt").then((r) => r.text()),
      fetch("../../partials/footer.txt").then((r) => r.text()),
      fetch("../../partials/modal.txt").then((r) => r.text()),
      fetch("../../partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  // initModalDriveModeSelectButtons();
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  // 基本機能 画面
  // renderDriveModeSwitchBtnAndSettingPanelOperation();
}

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("appData", JSON.stringify(data));
  // console.log(data.automation.items["auto-1"].actions[0]);
};

/******************************************
 * JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）ヘッダー用
 ******************************************/
const setHeaderJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("headerSet", JSON.stringify(data));
  // console.log(data.automation.items["new"].triggers[0].days);
};


/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");

  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = "../schedule/";
      break;

    // アラート表示
    case "touch-airflow-back":
      alert(
        "風向を設定しました。やり直す場合は画像をダブルタップしてください。",
      );
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 * 対象：フッターのアイコン
 * アクション：JSON更新(currentPage)
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 * 対象：フッターのアイコン
 * アクション：アクティブページのフッターアイコンの表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * ユーティリティ：全画面
 * 対象：トグルスイッチ（button要素内にあるスイッチ）
 * アクション：クリック時の伝播を防ぐ
 ******************************************/
document.querySelectorAll(".form-check-input").forEach((toggle) => {
  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});

/******************************************
 * ユーティリティ：全画面
 * 対象：button要素、スイッチ要素
 * アクション：「デモアプリではこのボタンは操作できません。」を表示する
 ******************************************/
document.addEventListener("click", (e) => {
  const target = e.target.closest(".demo-toggle-alert");
  if (!target) return;

  // 現在の状態を保持（クリック後の状態）
  const currentChecked = target.checked;
  e.stopPropagation();

  alert("デモアプリではこのボタンは操作できません。");

  // 元の状態に戻す
  target.checked = !currentChecked;
});

/******************************************
 * マッピングオブジェクト
 ******************************************/
// 機器名、アイコンマスター
const DEVICE_MASTER = {
  "rac-1": {
    label: "リビングのエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
  },
  "rac-2": {
    label: "寝室のエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
  },
  "eq": {
    label: "給湯機",
    icon: "../assets/img/product_Icon_EQ_40pt.svg",
    settings: "../device-settings-eq/",
  },
};

// 製品カテゴリマスター
const CATEGORY_MASTER = {
  "rac-1": "rac",
  "rac-2": "rac",
  "eq": "eq",
};

// トリガーイベント条件
const TRIGGER_EVENT_DESCRIPTION_MASTER = {
  "schedule": "設定した時刻に指定されたアクションを実行します。繰り返し設定を行わない場合、１度だけ指定されたアクションを実行します。",
  "location": "選択された家電シェアユーザーのうちの1名以上が位置条件を満たした場合に、指定されたアクションを実行します。",
  "devices": "機器の運転状態を元に、指定されたアクションを実行します。トリガーイベントとして指定できる機器の運転状態は1つです。",
};

// トリガーイベントセクション表示／非表示
const TRIGGER_EVENT_SECTION_MASTER = {
  "schedule": "schedule-section",
  "location": "location-section",
  "devices": "devices-section",
}

/******************************************
 * オートメーション編集 画面
 ******************************************/
// オートメーション編集画面
const renderAutomationEditing = () => {
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);

  renderAutomationName(entryAutoId);                // オートメーション名
  renderTriggerSection(entryAutoId, entryTrigger);  // トリガーイベントセクション

    // createAutomationTriggerButton(entryAutoId); //
    renderDeviceTriggerButton(entryAutoId);        // 機器の状態を追加で生成されるカードボタン
}

// オートメーション名を読み込む
const renderAutomationName = (entryAutoId) => {
  const el = document.getElementById("autoName");
  const automationName = getJsonValue(`${entryAutoId}.name`);

  if (!el) return;
  const name = automationName?.trim();
  if (name) {
    el.textContent = name;
  } else {
    el.textContent = "オートメーション名（未設定）";
  }
};

// トリガーイベントセクションを読み込む（親関数）
const renderTriggerSection = (entryAutoId, entryTrigger) => {
  renderTriggerButtons(entryTrigger); // トリガーイベントボタン
  renderTriggerEventSection(entryAutoId, entryTrigger); // トリガーイベントセクション
  renderTriggerDescription(entryTrigger); // トリガーイベント条件（文章）
  renderScheduleDays(entryAutoId);         // 曜日（繰り返し）
  renderScheduleDescription(entryAutoId);  // 曜日説明文
  renderScheduleStartTime(entryAutoId);    // 時間
  renderSchedule(entryAutoId)
  renderLocationUsers(entryAutoId);        // 通知するユーザー（家電シェアユーザー）
  renderLocationCondition(entryAutoId);    // 位置条件（近づいたとき／離れたとき）
};

// トリガーイベントボタンの状態を読み込む
const renderTriggerButtons = (entryTrigger) => {
  const targetElements = document.querySelectorAll(".js-trigger-event");
  targetElements.forEach((el) => {
    const key = el.dataset.appKey;
    if (key === entryTrigger) {
      el.classList.add("active");
      el.setAttribute("aria-pressed", "true");
    } else {
      el.classList.remove("active");
      el.setAttribute("aria-pressed", "false");
    }
  });
};

// トリガーイベントセクションの表示／非表示
const renderTriggerEventSection = (entryAutoId, entryTrigger) => {
  document
    .querySelectorAll(".schedule-section, .location-section, .devices-section")
    .forEach(el => el.style.display = "none");
  
    const threshold = getJsonValue(`${entryAutoId}.triggers.devices.threshold`);
    const template = document.querySelector(".deviceTemplate");
    const addBtn = document.querySelector(".addDeviceButton");

    if (!(entryTrigger === "devices")) {
      const key = TRIGGER_EVENT_SECTION_MASTER[entryTrigger];
      const target = document.querySelector(`.${key}`);
      if (target) target.style.display = "";
    }

    if ((entryTrigger === "devices")) {
      if (!threshold) {
        addBtn.classList.remove("devices-section");
        addBtn.style.display = "block";
     }else {
        addBtn.classList.remove("devices-section");
        template.style.display = "block";
     }
  }
};

// トリガーイベント条件（文章）の表示制御
const renderTriggerDescription = (entryTrigger) => {
  const targetElement = document.querySelector(".trigger-section");
  targetElement.innerText = TRIGGER_EVENT_DESCRIPTION_MASTER[entryTrigger];
};

// トリガーイベントボタンのクリックイベント
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-trigger-event");
  if (!btn) return;

  const key = btn.dataset.appKey;
  const entryAutoId = getJsonValue("entryId");
  setJsonValue(`${entryAutoId}.entryTrigger`, key);

  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);
  renderTriggerSection(entryAutoId, entryTrigger);
});

// 時間を代入
const renderScheduleStartTime = (entryAutoId) => {
  const el = document.getElementById("autoStartTime");
  const automationTime = getJsonValue(`${entryAutoId}.triggers.schedule.time`);

  if (!el) return;
  const time = automationTime?.trim();
  if (time) {
    el.textContent = time;
  } else {
    el.textContent = "開始時間（未設定）";
  }
};

// 曜日を代入
const renderScheduleDays = (entryAutoId) => {
  const targetElements = document.querySelectorAll(".day-of-the-week");
  if (!targetElements.length) return;

  // schedule.days を安全に取得
  const days = getJsonValue(`${entryAutoId}.triggers.schedule.days`) ?? [];

  targetElements.forEach((el) => {
    const day = el.dataset.appScheduleDay;
    const isActive = days.includes(day);

    el.classList.toggle("active", isActive);
    el.setAttribute("aria-pressed", String(isActive));
  });
};

  // 曜日説明文を代入
function renderScheduleDescription(entryAutoId) {
  const scheduleTrigger = getJsonValue(`${entryAutoId}.triggers.schedule`);
  if (!scheduleTrigger) return;

  const days = scheduleTrigger.days ?? [];
  const description = createScheduleDescription(days);

  const descriptionElement = document.getElementById("scheduleText");
  if (!descriptionElement) return;

  descriptionElement.textContent = description;
}


// 通知するユーザー（家電シェアユーザー）のチェックボックスを選択する
const renderLocationUsers = (entryAutoId) => {
  // location-section 内の checkbox を取得
  const checkboxes = document.querySelectorAll(
    '.location-section input[type="checkbox"]'
  );

  if (!checkboxes.length) return;

  // location trigger を取得
  const locationTrigger = getJsonValue(`${entryAutoId}.triggers.location`);
  if (!locationTrigger) return;

  const selectedUsers = locationTrigger.users || [];

  checkboxes.forEach((checkbox) => {
    const userName = checkbox.value;

    // JSON に含まれていればチェックON
    checkbox.checked = selectedUsers.includes(userName);
  });
};

// 位置条件のイベントを代入
const renderLocationCondition = (entryAutoId) => {

  const selectedCondition = getJsonValue(
    `${entryAutoId}.triggers.location.event`
  );

  // UI更新用の関数
  function updateLocationConditionUI(conditionValue) {

    const targetElements = document.querySelectorAll(".js-location-condition");

    targetElements.forEach((el) => {
      const condition = el.dataset.appLocationCondition;

      if (condition === conditionValue) {
        el.setAttribute("aria-pressed", "true");
        el.classList.add("active");
      } else {
        el.setAttribute("aria-pressed", "false");
        el.classList.remove("active");
      }
    });
  }

  updateLocationConditionUI(selectedCondition);
};

// 「機器の状態を追加」のあとで生成されるカードボタンを作成
const createAutomationTriggerButton = (entryAutoId) => {
  const threshold = getJsonValue(`${entryAutoId}.triggers.devices.threshold`);
  if (!threshold) return;

  const area = document.getElementById("devicesArea");
  if (!area) return;
  const template = document.getElementById("deviceTemplate");
  if (!template) return;
  const addBtn = document.getElementById("addDeviceButton");
  if (!addBtn) return;

  // クローン
  const card = template.cloneNode(true); // クローンを作成
  template.classList.remove("devices-section"); // テンプレートからクラスを削除（devices-section）

  // card.removeAttribute("id");
  // card.style.display = "";
  // card.classList.add("devices-section");

  // 仮データ反映（あとでJSONに差し替え）
  card.querySelector(".name").textContent = "リビングのエアコン";
  card.querySelector(".description").textContent = "室温28度以上";

  // 追加（＋の前に入れる）
  area.insertBefore(card, addBtn);
  template.style.display = "none";

  // ＋ボタンを隠す
  addBtn.style.display = "none";
};

/******************************************
 * オートメーション編集 画面
 * アクションセクション内の処理
 ******************************************/
// イニシャライズ：アクション内のカードボタン（シーン／機器操作／通知 を追加）
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-trigger-section");
  if (!btn) return;
  const section = btn.dataset.appAction;

  if (section === "scene") {
    window.location.href = "../select-scene/";
  } else if (section === "devices") {
    window.location.href = "../select-device/";
  } else if (section === "notify") {
    window.location.href = "../select-notice/";
  }
});

/******************************************
 * オートメーション 画面
 ******************************************/
// エントリー用のオートメーションIDをJSONに保存、編集画面へ遷移する
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-automation-id");
  if (!btn) return;

  const key = btn.dataset.appKey;
  setJsonValue("entryId", key);
  window.location.href = "../edit-automation/";
});

const updateDeviceAddButton = () => {

  const area = document.getElementById("devicesArea");
  const addBtn = document.getElementById("addDeviceButton");

  // 実カードを探す（テンプレ以外）
  const cards = area.querySelectorAll(
    ':scope > div:not(#deviceTemplate):not(#addDeviceButton)'
  );

  addBtn.style.display = cards.length > 0 ? "none" : "";
};


/******************************************
 * オートメーション編集 画面
 * イニシャライズ
 ******************************************/
function createScheduleDescription(days) {
  const allDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const dayNames = {
    sun: "日",
    mon: "月",
    tue: "火",
    wed: "水",
    thu: "木",
    fri: "金",
    sat: "土",
  };

  if (!days || days.length === 0) {
    return "一度だけ実行します";
  }

  if (days.length === 7) {
    return "毎日実行します";
  }

  const selectedDayNames = days
    .sort((a, b) => allDays.indexOf(a) - allDays.indexOf(b))
    .map((day) => dayNames[day])
    .join("");

  return `毎週${selectedDayNames}曜日に実行します`;
}

//　クリックした曜日を渡す
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".day-of-the-week");
  if (!btn) return;

  const entryAutoId = getJsonValue("entryId");
  const day = btn.dataset.appScheduleDay;
  toggleScheduleDay(entryAutoId, day);
});

// 受け取った曜日を配列⇒JSONに保存
function toggleScheduleDay(entryAutoId, day) {
  const path = `${entryAutoId}.triggers.schedule.days`;

  let days = getJsonValue(path) ?? [];

  if (days.includes(day)) {
    days = days.filter(d => d !== day);
  } else {
    days.push(day);
  }

  setJsonValue(path, days);
  renderSchedule(entryAutoId);
}

// レンダリングする
function renderSchedule(entryAutoId) {
  renderScheduleDays(entryAutoId);
  renderScheduleDescription(entryAutoId);
}

// /******************************************
//  * イニシャライズ：オートメーション 画面
//  * 対象：＋ボタン
//  * アクション：新規オートメーション画面へ遷移する
//  ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-add-automation");
  if (!btn) return;
  window.location.href = "../proposal-automation/";
});



renderDeviceTriggerButton = (entryAutoId) => {
createCardButton(entryAutoId);
}

function createCardButton(entryAutoId) {
  const template = document.getElementById("deviceTemplate");
  if (!template) return null;

  const clone = template.cloneNode(true);

  // id削除
  clone.removeAttribute("id");

  // 表示する
  clone.style.display = "";
  clone.classList.remove("deviceTemplate");

  return clone;
}

function addButton(clone) {
  if (!clone) return;

  const area = document.getElementById("devicesArea");
  const addBtn = document.getElementById("addDeviceButton");

  if (!area || !addBtn) return;

  // ＋ボタンの前に追加
  area.insertBefore(clone, addBtn);
}
