const initialAppData = {
  currentPage: "mymu", // (mymu | automation | mymuPlus | notice)
  currentTriggerEvent: "schedule", // (schedule | location | statusOfDevice)
  automation: {
    selectedId: "auto-1",
    items: {
      "auto-1": {
        status: true,
        name: "冬の帰宅",
        triggers: [
          {
            type: "schedule",
            startTime: "18:00",
            days: ["mon", "tue", "wed", "thu", "fri"]
          }
        ],
        actions: [
          {
            type: "product",
            productId: "rac-living",
            drive: "on",
            mode: "heat",
            temperature: 20
          }
        ]
      },

      "auto-2": {
        status: true,
        name: "夏の帰宅",
        triggers: [
          {
            type: "schedule",
            startTime: "19:00",
            days: ["mon", "wed", "fri"]
          }
        ],
        actions: [
          {
            type: "product",
            productId: "rac-living",
            drive: "on",
            mode: "cool",
            temperature: 27
          }
        ]
      },

      "auto-3": {
        status: true,
        name: "高温おしらせ",
        triggers: [
          {
            type: "product",
            productId: "rac-living",
            condition: "temperatureAbove",
            threshold: 28
          }
        ],
        actions: [
          {
            type: "product",
            productId: "rac-living",
            drive: "on",
            mode: "cool",
            temperature: 27
          },
          {
            type: "notification",
            target: "mother",
            message: "リビングのエアコン 室温"
          }
        ]
      }
    }
  },
};



// テンプレート（提案オートメーションの場合）
const TEMPLATE_AUTOMATION_N = {
  status: true,
  name: "おかえりON", // "高温のおしらせ" | "低温のおしらせ" | "おかえりON" | "おでかけOFF" | "エアコン入タイマー" | "エアコン切タイマー"
  triggers: [
    {
      type: "location", // "schedule" | "location" | "product"
      name: "リビングのエアコン", // "リビングのエアコン" | "寝室のエアコン" | "給湯機"
      user: ["user1", "user2"], // "user1（お父さん）" | "user2（お母さん）" | "user3（たかし）" | "user4（あいこ）"
      condition: "arrive" // "arrive" | "leave"
    },
  ],
  actions: [
    {
      type: "location", // "scenes" | "products" | "notifications"
      deviceId: "rac", // "rac" | "eq" 
      name: "リビングのエアコン", // "リビングのエアコン" | "寝室のエアコン" | "給湯機"
      icon: "../assets/img/icon_AC_40pt.svg", // "エアコン" | "給湯機" | "通知" | "ロケーション"
      drive: "on",
      mode: "cooling",// "エアコン" | "給湯機" | "通知" | "ロケーション"
      temperature: "27.0",
      description: "室温",  // above | below
    }
  ],
};
