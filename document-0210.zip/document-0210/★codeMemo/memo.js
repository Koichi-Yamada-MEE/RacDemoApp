// JSで active を付与する（超最小）
const currentPage = jsonData.currentPage;

document.querySelectorAll('.footer-btn').forEach(btn => {
  btn.classList.remove('active');
  if (btn.dataset.page === currentPage) {
    btn.classList.add('active');
  }
});


const updateStartStopStatusBtn = () => {
  const btn = document.getElementById("btnStartStop");
  getJsonValue("currentDriveStatus")
    ? btn.classList.add("active")
    : btn.classList.remove("active");
};

        // ? btn.classList.add("active") // true 運転中のため active クラスを追加
        // : btn.classList.remove("active") // false 停止中のため active クラスを削除


document.addEventListener("click", (e) => {
  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  const target = e.target.closest(".demo-disabled-button");
  if (target) {
    e.preventDefault(); // リンクの遷移を止める
    alert("デモアプリではこのボタンは操作できません。");
  }
});

document.addEventListener("click", (e) => {
  const trigger = e.target.closest(".js-drive-trigger");
  if (!trigger) return;

  const isRunning = getJsonValue("modalDrive.isRunning");
  const modal = document.getElementById("modalRacStartStop");
  if (!modal) return;

  const messageEl = modal.querySelector("#modalRacStartStopMessage");
  const okBtn = modal.querySelector(".js-modal-drive");

  if (!messageEl || !okBtn) return;

  if (isRunning) {
    messageEl.textContent = trigger.dataset.messageRun;
    okBtn.dataset.appDrive = "runToStop";
  } else {
    messageEl.textContent = trigger.dataset.messageStop;
    okBtn.dataset.appDrive = "stopToRun";
  }

  showModal("modalRacStartStop");
});



const renderThermalImage = (value) => {
  const thermalImageElement = document.querySelector(".js-img");
  thermalImageElement.style.visibility = value ? "visible" : "hidden";
}

const isAiAuto = getJsonValue("currentMode").includes("ai-auto");
const btn = document.getElementById("toggleTouchAirflow");
if (isAiAuto) {
  btn.checked = true;
  btn.nextElementSibling.innerText = "ON";
} else {
  btn.checked = false;
  btn.nextElementSibling.innerText = "OFF";
}

const overlayUpdate = () => {
  const overlay = document.querySelector(".wind-overlay");
  getJsonValue("currentMode")?.includes("ai-auto")
    ? overlay.classList.remove("d-none")
    : overlay.classList.add("d-none");
};

// 運転モード選択ボタン, 操作パネル表示処理
document.addEventListener('DOMContentLoaded', () => {
  // 1. 初期表示
  driveModeSwitchBtnAndSettingPanelOperation();
  setTimeout(() => {
    document.querySelectorAll('.modal-drive-select-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        // 2. 更新前のスタイルリセット
        let initialStyle = "btn rounded-pill d-flex justify-content-center align-items-center gap-2 mt-3 app-drive-btn"
        document.getElementById("driveModeSwitchBtn").className = initialStyle;
        // 2.2 オーバーレイ表示のリセット
        document.querySelector('.wind-overlay').className = 'wind-overlay d-none';
        // 3. JSON更新
        setJsonValue("currentMode", btn.dataset.appMode);
        // 4. 表示更新
        // 4.1 運転モード選択ボタンのスタイル更新
        driveModeSwitchBtnAndSettingPanelOperation();
        // 4.2 操作パネルの表示更新
        onModeChanged();
        overlayUpdate();
      });
    });
  }, 100);
});


    // 運転モード選択ボタン, 操作パネル表示処理
    document.addEventListener('DOMContentLoaded', () => {
      // 1. 初期表示
      driveModeSwitchBtnAndSettingPanelOperation();
      setTimeout(() => {
        document.querySelectorAll('.modal-drive-select-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            // 2. 更新前のスタイルリセット
            let initialStyle = "btn rounded-pill d-flex justify-content-center align-items-center gap-2 mt-3 app-drive-btn"
            document.getElementById("driveModeSwitchBtn").className = initialStyle;
            // 2.2 オーバーレイ表示のリセット
            document.querySelector('.wind-overlay').className = 'wind-overlay d-none';
            // 3. JSON更新
            setJsonValue("currentMode", btn.dataset.appMode);
            // 4. 表示更新
            // 4.1 運転モード選択ボタンのスタイル更新
            driveModeSwitchBtnAndSettingPanelOperation();
            // 4.2 操作パネルの表示更新
            onModeChanged();
            overlayUpdate();
          });
        });
      }, 100);
    });


    btn.style.backgroundColor = "white";
    btn.style.color = "var(--app-color-cooling)";
    btn.innerText = "停止する";

    ? overlay.style.display = "block"
    : overlay.style.display = "none";


document.addEventListener('click', (e) => {
  const btn = e.target.closest('[role="button"][data-app-modeid]');
  if (!btn) return;
  const modeId = btn.dataset.appModeid;
  setJsonValue("currentModeId", modeId);
  onModeChanged();
});
setJsonValue("currentMode", btn.dataset.appMode);


document.addEventListener("DOMContentLoaded", () => {


});

/******************************************
 * レンダリング：基本画面
 * 対象：操作パネル（運転モード選択ボタン／ラベル／アイコン／設定表示（温度／湿度・送風））
 * アクション：操作パネルの更新
 ******************************************/


const renderElectricityBillCheckTab = () => {
  const isElectricityBillSelected = getJsonValue("electricityBill.isSelected");
  const electricityBillTab = document.getElementById("electricityBillTab");

  const addBorderLineColor = () => {
    electricityBillTab.classList.add("selected-tab");
  };

  isElectricityBillSelected ? addBorderLineColor() : null;
};



'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>'

console.log("result", xxxxx)

/******************************************
* 
* 
* 
******************************************/


function renderEditAutomationScreen(mode, automationId = null) {
  initAutomationDraft();
  renderAutomationName();
  renderTriggerEventSection();
  renderScheduleStartTime();
  renderScheduleDays();
  renderScheduleDescription();
  renderLocationCondition();
  renderActions();
}

const initialAppData = {
  currentPage: "mymu", // (mymu | automation | mymuPlus | notice)
  currentTriggerEvent: "schedule", // (schedule | location | statusOfDevice)
  automation: {
    selectedId: "auto-1",
    items: {
      "auto-1": {
        status: true,
        name: "冬の帰宅",
        triggers: [
          {
            type: "schedule",
            startTime: "18:00",
            days: ["mon", "tue", "wed", "thu", "fri"]
          }
        ],
        actions: [
          {
            type: "product", // (scenes | products | notifications)
            productId: "rac",
            name: "リビングエアコン",
            drive: "on",
            mode: "heating",
            temperature: "20.0"
          },
          {
            type: "product", // (scenes | products | notifications)
            productId: "eq",
            name: "給湯機",
            drive: "on",
          }
        ]
      },

      "auto-2": {
        status: true,
        name: "夏の帰宅",
        triggers: [
          {
            type: "schedule",
            startTime: "19:00",
            days: ["mon", "wed", "fri"]
          }
        ],
        actions: [
          {
            type: "product", // (scenes | products | notifications)
            productId: "rac",
            name: "リビングのエアコン",
            drive: "on",
            mode: "cooling",
            temperature: "27.0"
          }
        ]
      },

      "auto-3": {
        status: true,
        name: "高温おしらせ",
        triggers: [
          {
            type: "product",
            productId: "rac",
            condition: "temperatureAbove",
            threshold: 28
          }
        ],
        actions: [
          {
            type: "product",
            productId: "rac",
            name: "リビングのエアコン",
            drive: "on",
            mode: "cooling",
            temperature: "27.0"
          },
          {
            type: "notification",
            name: "リビングのエアコン",
            target: "mother",
            message: "室温"
          }
        ]
      }
    }
  },
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();




document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-add-automation");
  if (!btn) return;
  window.location.href = "../proposal-automation/";
});

// テンプレート（提案オートメーションの場合）
const TEMPLATE_AUTOMATION_N = {
  status: true,
  name: "おかえりON", // "高温のおしらせ" | "低温のおしらせ" | "おかえりON" | "おでかけOFF" | "エアコン入タイマー" | "エアコン切タイマー"
  triggers: [
    {
      type: "location", // "schedule" | "location" | "product"
      name: "リビングのエアコン", // "リビングのエアコン" | "寝室のエアコン" | "給湯機"
      user: ["user1", "user2"], // "user1（お父さん）" | "user2（お母さん）" | "user3（たかし）" | "user4（あいこ）"
      condition: "arrive" // "arrive" | "leave"
    },
  ],
  actions: [
    {
      type: "location", // "scenes" | "products" | "notifications"
      deviceId: "rac", // "rac" | "eq" 
      name: "リビングのエアコン", // "リビングのエアコン" | "寝室のエアコン" | "給湯機"
      icon: "../assets/img/icon_AC_40pt.svg", // "エアコン" | "給湯機" | "通知" | "ロケーション"
      drive: "on",
      mode: "cooling",// "エアコン" | "給湯機" | "通知" | "ロケーション"
      temperature: "27.0",
      description: "室温",  // above | below
    }
  ],
};
