スマートスイッチの設定情報シールは取扱説明書、またはスイッチカバーを外した機器本体に貼り付けてあります。


機器の貼付位置は


MACアドレスは取扱説明書やスイッチカバーを外した機器本体に記載されています。または、QRコードを読み取ることでも確認できます。

ハウジングエアコン、床置形のハウジングエアコンは未対応です。
ハウジングエアコン（天井カセット形・床置形）は未対応です。

┌──────────────────────┐ 1080px
│ main（Swiper）        │
│                      │ ← 可変（残り高さ）
│                      │
├──────────────────────┤
│ footer（文章）        │ ← 固定高さ・複数行
└──────────────────────┘
        810px



body
└─container
    ├─main
    │  └─swiper
    └─footer



D:.
└─ecocuteDemoApp
    │
    ├─amount-of-hot-water
    │      last-2weeks.html
    │      yesterday-today.html
    │
    ├─assets
    │  ├─css
    │  │      demo_app.css
    │  │      ecocute_demo_app.css
    │  │
    │  ├─img
    │  │  │  bath-img-auto.png
    │  │  │  bath-img-kirariyu.png
    │  │  │  txt-wakiage.png
    │  │  │
    │  │  └─favicon
    │  │          favicon.ico
    │  │
    │  └─js
    │          ecocute_demo_app.js
    │          ecocute_demo_app_json.js
    │          session-check.js
    │
    ├─help
    │      help.html
    │
    ├─home
    │      bath.html
    │      shower.html
    │      tank.html
    │
    ├─partials
    │      modal-hamburger.html
    │
    └─settings


automationEditDraft   ← 編集中の実体（唯一）
automationEditContext ← 今どこを編集中か
appData               ← 本番（触らない）
