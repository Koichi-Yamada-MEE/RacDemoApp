const initialAppData = {
  automation: {
    selectedId: "auto-1",
    items: {
      "auto-1": {
        status: true,
        name: "冬の帰宅",
        triggers: [
          {
            type: "schedule",
            startTime: "18:00",
            days: ["mon", "tue", "wed", "thu", "fri"]
          }
        ],
        actions: [
          {
            type: "product", // (scenes | products | notifications)
            productId: "rac",
            name: "リビングエアコン",
            drive: "on",
            mode: "heating",
            temperature: "20.0"
          },
          {
            type: "product", // (scenes | products | notifications)
            productId: "eq",
            name: "給湯機",
            drive: "on",
          }
        ]
      },

      "auto-2": {
        status: true,
        name: "夏の帰宅",
        triggers: [
          {
            type: "schedule",
            startTime: "19:00",
            days: ["mon", "wed", "fri"]
          }
        ],
        actions: [
          {
            type: "product", // (scenes | products | notifications)
            productId: "rac",
            name: "リビングのエアコン",
            drive: "on",
            mode: "cooling",
            temperature: "27.0"
          }
        ]
      },

      "auto-3": {
        status: true,
        name: "高温おしらせ",
        triggers: [
          {
            type: "product",
            productId: "rac",
            condition: "temperatureAbove",
            threshold: 28
          }
        ],
        actions: [
          {
            type: "product",
            productId: "rac",
            name: "リビングのエアコン",
            drive: "on",
            mode: "cooling",
            temperature: "27.0"
          },
          {
            type: "notification",
            name: "リビングのエアコン",
            target: "mother",
            message: "室温"
          }
        ]
      }
    }
  },
};

const clone = structuredClone(initialAppData.automation.items["auto-1"]); // ディープコピー
console.log(clone);