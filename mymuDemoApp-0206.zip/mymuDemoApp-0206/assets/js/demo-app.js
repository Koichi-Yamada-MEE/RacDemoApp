/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/alert.txt").then((r) => r.text()),
      fetch("../../partials/header.txt").then((r) => r.text()),
      fetch("../../partials/footer.txt").then((r) => r.text()),
      fetch("../../partials/modal.txt").then((r) => r.text()),
      fetch("../../partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  // initModalDriveModeSelectButtons();
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  // 基本機能 画面
  // renderDriveModeSwitchBtnAndSettingPanelOperation();
}


/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("appData", JSON.stringify(data));
  console.log(data.automation.items["auto-1"].actions[0]);
};

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getJsonValue(`headerSet.${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");

  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = '../schedule/';
      break;

    // アラート表示
    case "touch-airflow-back":
      alert(
        "風向を設定しました。やり直す場合は画像をダブルタップしてください。",
      );
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 * 対象：フッターのアイコン
 * アクション：JSON更新(currentPage)
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 * 対象：フッターのアイコン
 * アクション：アクティブページのフッターアイコンの表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * ユーティリティ：全画面
 * 対象：トグルスイッチ（button要素内にあるスイッチ）
 * アクション：クリック時の伝播を防ぐ
 ******************************************/
document.querySelectorAll(".form-check-input").forEach((toggle) => {
  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});

/******************************************
 * ユーティリティ：全画面
 * 対象：button要素、スイッチ要素
 * アクション：「デモアプリではこのボタンは操作できません。」を表示する
 ******************************************/
document.addEventListener("click", (e) => {
  const target = e.target.closest(".demo-toggle-alert");
  if (!target) return;

  // 現在の状態を保持（クリック後の状態）
  const currentChecked = target.checked;
  e.stopPropagation();

  alert("デモアプリではこのボタンは操作できません。");

  // 元の状態に戻す
  target.checked = !currentChecked;
});


/******************************************
 * イニシャライズ：オートメーション 画面
 * 対象：＋ボタン
 * アクション：オートメーション追加画面が表示される
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-add-automation");
  if (!btn) return;
  window.location.href = "../new-automation/";
});

/******************************************
 * イニシャライズ：新規オートメーション 画面
 * 対象：カスタムオートメーション作成 ボタン
 * アクション：ボタンをクリックすると、カスタムオートメーション画面へ遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-new-automation");
  if (!btn) return;
  window.location.href = "../custom-automation/";
});

/******************************************
 * イニシャライズ：カスタムオートメーション 画面
 * 対象：スケジュール／位置情報／機器の状態 ボタン
 * アクション：JSONデータ更新
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-trigger-event");
  if (!btn) return;
  const triggerEvent = btn.dataset.appTriggerEvent;
  if (!triggerEvent) return;
  // JSONデータ更新
  setJsonValue("currentTriggerEvent", triggerEvent);
  renderCustomAutomationTriggerEventBtn();
  renderCustomAutomationTriggerEventBlockDisplay(triggerEvent);
});

/******************************************
 * レンダリング：カスタムオートメーション 画面
 * 対象：トリガーイベント ボタン（スケジュール／位置情報／機器の状態 ボタン）
 * アクション：JSONデータ更新
 ******************************************/
const renderCustomAutomationTriggerEventBtn = () => {
  const triggerEvent = getJsonValue(
    "currentTriggerEvent.triggerEvent",
  );
  const triggerEventButtons = document.querySelectorAll(
    ".js-trigger-event",
  );
  triggerEventButtons.forEach((btn) => {
    btn.classList.remove("active");
    if (btn.dataset.appTriggerEvent === triggerEvent) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * レンダリング：カスタムオートメーション 画面
 * 対象：トリガーイベント 家電シェアユーザー／位置条件の表示⇔非表示
 * アクション：JSONデータを取得して表示⇔非表示を切り替え
 ******************************************/
const renderCustomAutomationTriggerEventBlockDisplay = (triggerEvent) => {
  const sections = {
    schedule: "trigger-event-schedule",
    location: "trigger-event-location",
    product: "trigger-event-product",
  };

  const allSections = document.querySelectorAll(".trigger-event-section");

  // いったん全て非表示
  allSections.forEach((section) => {
    section.classList.add("d-none");
  });

  // 対象をすべて表示（querySelectorAll を使用）
  const targetSectionName = sections[triggerEvent];

  document
    .querySelectorAll(`.trigger-event-section[data-app-key="${targetSectionName}"]`)
    .forEach((el) => el.classList.remove("d-none"));
};


/******************************************
 * イニシャライズ：カスタムオートメーション 画面
 * 対象：シーンを追加／機器の操作を追加／通知を追加 ボタン
 * アクション：画面を遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const action = e.target.closest(".js-trigger-event")?.dataset?.appAction;
  const routes = {
    scene: "../select-scene/",
    operation: "../select-device/",
    notification: "../notice-settings/",
  };
  if (action && routes[action]) location.href = routes[action];
});

/******************************************
 * イニシャライズ：機器を選択 画面
 * 対象：シーンを追加／機器の操作を追加／通知を追加 ボタン
 * アクション：画面を遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const action = e.target.closest(".js-trigger-event")?.dataset?.appAction;
  const routes = {
    ac1: "../device-settings-ac-1/",
    ac2: "../device-settings-ac-2/",
    eq: "../device-settings-eq/",
  };
  if (action && routes[action]) location.href = routes[action];
});

/******************************************
 * イニシャライズ：操作設定 画面
 * 対象：運転／停止、冷房／暖房／除湿／送風 ボタン
 * アクション：JSONの値を更新する
 ******************************************/
document.addEventListener("click", (e) => {
  const targetDevice =
    e.target.closest(".js-trigger-event")?.dataset?.appDevice;
  const btnDrive = e.target.closest(".js-trigger-event")?.dataset?.appIsDrive;
  const btnMode = e.target.closest(".js-trigger-event")?.dataset?.appMode;

  if (btnDrive !== undefined && targetDevice) {
    const isDrive = btnDrive === "true";
    setJsonValue(`operationSettings.${targetDevice}.isDrive`, isDrive);
  }

  if (btnMode && targetDevice) {
    setJsonValue(`operationSettings.${targetDevice}.mode`, btnMode);
  }
});

/******************************************
 * レンダリング：操作設定 画面
 * 対象：運転／停止、モード ボタン
 * アクション：JSONの値からボタンの初期状態を復元する
 ******************************************/
const renderDeviceSettingsButtons = (deviceId) => {
  if (!deviceId) return;

  const targetPath = `automation.items.${deviceId}.actions[0]`;

  // deviceId と 機器名表示先の対応
  const productMap = {
    "auto-1": "product-1",
    "auto-2": "product-2",
    "auto-3": "product-3",
  };

  const productElId = productMap[deviceId];
  if (!productElId) return;

  // 機器名
  document.getElementById(productElId).innerText =
    getJsonValue(`${targetPath}.name`);

  // 運転 ON / OFF
  const drive = getJsonValue(`${targetPath}.drive`);
  document
    .getElementById("racDriveOnBtn")
    .classList.toggle("active", !!drive);
  document
    .getElementById("racDriveOffBtn")
    .classList.toggle("active", !drive);

  // モードボタン
  const mode = getJsonValue(`${targetPath}.mode`);
  if (mode) {
    document.querySelectorAll(".js-drive-mode").forEach((btn) => {
      btn.classList.toggle(
        "active",
        btn.dataset.appMode === mode
      );
    });
  }

  // 設定温度（auto-1 / auto-2 のみ存在）
  const temperature = getJsonValue(`${targetPath}.temperature`);
  if (temperature !== undefined) {
    document.getElementById("racSettingTemperature").innerText =
      temperature;
  }
};


/******************************************
 * イニシャライズ：オートメーション 画面
 * 対象：オートメーション カード ボタン
 * アクション：クリックすると、JSONの値を更新、画面遷移する
 *  ******************************************/
document.addEventListener("click", (e) => {
  const autoId = e.target.closest(".js-trigger-auto-id")?.dataset?.appKey;
  const triggerEvent = e.target.closest(".js-trigger-auto-id")?.dataset?.appKeyTriggerEvent;
  if(!autoId) return;
  if(!triggerEvent) return;

  setJsonValue("automation.selectedId", `${autoId}`);
  setJsonValue(`automation.items.${autoId}.triggers[0].type`, `${triggerEvent}`);
  window.location.href = '../edit-automation/';
});

/******************************************
 * レンダリング：オートメーション編集 画面
 * 対象：画面の全ての設定要素
 * アクション：JSONから値を取得して画面を更新する
 ******************************************/
const renderAutomationEditScreen = () => {
  // 選択されたオートメーションIDとトリガーイベントを取得
  const selectedId = getJsonValue("automation.selectedId");
  const targetPath = `automation.items.${selectedId}`; // auto-x までのpath
  const triggerEvent = getJsonValue(`${targetPath}.triggers[0].type`);

// セクションの表示⇔非表示
  renderCustomAutomationTriggerEventBlockDisplay(triggerEvent);

  // トリガーイベント
  const targetButton = document.querySelector(
    `.js-trigger-event[data-app-trigger-event="${triggerEvent}"]`,
  );
  targetButton.classList.add("active");

  // オートメーション名
  document.getElementById("autoName").innerText = getJsonValue(
    `${targetPath}.name`,
  );

  // 時間
  document.getElementById("autoStartTime").innerText =
    getJsonValue(`${targetPath}.triggers[0].startTime`) ?? ""; // プロパティがない場合は空配列を使用

  // 曜日
  const days = getJsonValue(`${targetPath}.triggers[0].days`) ?? []; // プロパティがない場合は空配列を使用
  document.querySelectorAll(".day-of-the-week").forEach((button) => {
    const day = button.dataset.appScheduleDay;
    button.classList.toggle("active", days.includes(day));
  });

  // 説明文を更新
  updateScheduleDescription(days);
};


/******************************************
 * イニシャライズ：ユーティリティ
 * 対象：.setting-btn ボタン
 * アクション：選択すると .active クラスを追加する
 ******************************************/
document.addEventListener("click", (e) => {
  // const targetButton = e.target.closest(".setting-btn");
  // targetButton.classList.add("active");
});

/******************************************
 * イニシャライズ：オートメーション編集／カスタムオートメーション 画面
 * 対象：曜日ボタン（繰り返し）
 * アクション：クリックするとJSONの値を更新する／説明文を表示する
 ******************************************/
document.addEventListener("click", (e) => {
  const targetButton = e.target.closest(".day-of-the-week");
  if (!targetButton) return;

  const selectedDay = targetButton.dataset.appScheduleDay;
  const selectedId = getJsonValue("automation.selectedId");
  const targetPath = `automation.items.${selectedId}.triggers[0].days`;

  // 現在の曜日配列を取得
  let days = getJsonValue(targetPath) || [];

  if (days.includes(selectedDay)) {
    // すでに含まれている場合は削除（OFF）
    days = days.filter((day) => day !== selectedDay);
  } else {
    // 含まれていない場合は追加（ON）
    days.push(selectedDay);
  }

  // JSON更新（ONのみを記述）
  setJsonValue(targetPath, days);

  // ボタンのアクティブ状態を更新
  targetButton.classList.toggle("active", days.includes(selectedDay));

  // 説明文を更新
  updateScheduleDescription(days);
});

/******************************************
 * ユーティリティ：スケジュール説明文の更新
 * 対象：曜日選択に応じた説明文
 * アクション：選択状態に応じて説明文を表示
 ******************************************/
const updateScheduleDescription = (days) => {
  const allDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const dayNames = {
    sun: "日",
    mon: "月",
    tue: "火",
    wed: "水",
    thu: "木",
    fri: "金",
    sat: "土"
  };

  let description = "";

  if (days.length === 0) {
    // 何も選択されていない：一度だけ実行
    description = "一度だけ実行します";
  } else if (days.length === 7) {
    // 全て選択：毎日実行
    description = "毎日実行します";
  } else {
    // 一部選択：選択された曜日に実行
    const selectedDayNames = days
      .sort((a, b) => allDays.indexOf(a) - allDays.indexOf(b))
      .map(day => dayNames[day])
      .join("");
    description = `毎週${selectedDayNames}曜日に実行します`;
  }

  // 説明文を表示する要素を探して更新
  const descriptionElement = document.querySelector('[data-app-key="trigger-event-schedule"] p.fs-14.fc-gray');
  if (descriptionElement) {
    descriptionElement.textContent = description;
  }

  document.getElementById("scheduleText").innerText = description;
  console.log(`スケジュール説明: ${description}`);
};





/******************************************
 * イニシャライズ：
 * 対象：
 * アクション：
 ******************************************/
