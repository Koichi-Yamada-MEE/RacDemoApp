/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/alert.txt").then((r) => r.text()),
      fetch("../../partials/header.txt").then((r) => r.text()),
      fetch("../../partials/footer.txt").then((r) => r.text()),
      fetch("../../partials/modal.txt").then((r) => r.text()),
      fetch("../../partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * ユーティリティ：JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  sessionStorage.setItem("appData", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * ユーティリティ：モーダル表示
 ******************************************/
function showModal(modalId) {
  const modalEl = document.getElementById(modalId);
  if (!modalEl) return;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();
}

/******************************************
 * ユーティリティ：「デモアプリではこのボタンは操作できません。」
 ******************************************/
document.addEventListener("click", (e) => {
  const target = e.target.closest(".demo-toggle-alert");
  if (!target) return;

  // 現在の状態を保持（クリック後の状態）
  const currentChecked = target.checked;
  e.stopPropagation();

  alert("デモアプリではこのボタンは操作できません。");

  // 元の状態に戻す
  target.checked = !currentChecked;
});

/******************************************
 * ユーティリティ：オートメーション編集画面に戻ったとき、セッションストレージをリセットする
 ******************************************/
function resetAutomationExceptNew() {

  const current =
    JSON.parse(sessionStorage.getItem("appData")) ?? {};

  const original =
    JSON.parse(sessionStorage.getItem("cloneData")) ?? {};

  const currentNew = current.new ?? null;

  // cloneDataをベースに戻す
  const resetData = JSON.parse(JSON.stringify(original));

  // newだけ保持
  if (currentNew) {
    resetData.new = currentNew;
  }

  sessionStorage.setItem(
    "appData",
    JSON.stringify(resetData)
  );
}

/******************************************
 * ID作成（カードボタン用）
 ******************************************/
function createId(){
  return crypto.randomUUID().replace(/-/g,"").slice(0,10);
}

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

function initUI() {
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");

  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";

  // ★ bodyのdata属性チェック
  const headerSetKey = document.body.dataset.appHeaderSet;

  if (headerSetKey === "setupScene" || headerSetKey === "selectRoomTemperatureStatusOver" || headerSetKey === "selectRoomTemperatureStatusUnder" || headerSetKey === "deviceSettingsRac") {
    headerDomRight.disabled = false;
    headerDomRight.classList.add("active");
  }

// オートメーション編集画面の場合
if (headerSetKey === "editAutomation") {
  const entryId = getJsonValue("entryId");
  const shouldActivate =
    entryId !== "new" || updateCompleteButtonState(entryId);
  if (shouldActivate) {
    headerDomRight.disabled = false;
    headerDomRight.classList.add("active");
  }
}

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      const entryId = getJsonValue("entryId");
      if (entryId === "new") {
        setJsonValue("new.status", true);
      }
      window.history.back();
      break;

    // オートメーション画面へ遷移
    case "editAutomation":
      const newAutomation = getJsonValue("entryId");
      if (newAutomation === "new") {
        setJsonValue("new.status", true);
      }
      window.location.href = "../automation/";
      break;

    // オートメーション編集画面へ遷移
    case "goToEditAutomation":
      window.location.href = "../edit-automation/";
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // アラート表示activateAndGoToEditAutomation
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = "../schedule/";
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * グローバル変数
 ******************************************/
const AppState = {
  deleteActionId: null,
  deletingCard: null,
  deletingType: null,
  deleteContext: null,
  editActionId: null,
  selectedScene: null,
  isEdited: false
};

/******************************************
 * マッピングオブジェクト
 ******************************************/
// 機器名、アイコンマスター
const DEVICE_MASTER = {
  "rac-1": {
    label: "リビングのエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
    on: "運転開始",
    off: "運転停止",
  },
  "rac-2": {
    label: "寝室のエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
    on: "運転開始",
    off: "運転停止",
  },
  "eq": {
    label: "給湯機",
    icon: "../assets/img/product_Icon_EQ_40pt.svg",
    settings: "../device-settings-eq/",
    on: "ふろ自動開始",
    off: "ふろ自動停止",
  },
};

// 製品カテゴリマスター
const CATEGORY_MASTER = {
  "rac-1": "rac",
  "rac-2": "rac",
  "eq": "eq",
};

// アクション マスター
const ACTION_MASTER = {
  devices: {
    "rac-1": {
      icon: "../assets/img/icon_AC_40pt.svg",
      url: "../device-settings-rac/",
    },
    "rac-2": {
      icon: "../assets/img/icon_AC_40pt.svg",
      url: "../device-settings-rac/",
    },
    "eq": {
      icon: "../assets/img/product_Icon_EQ_40pt.svg",
      url: "../device-settings-eq/",
    },
  },
  notify: {
    icon: "../assets/img/icon_Notifications_40.svg",
    url: "../select-notice/",
  },
};

// シーンマスター
const SCENE_MASTER = {
  allOff: {
    label: "外出一括オフ",
    icon: "../assets/img/scene_off_40_40.svg",
    url: "../setup-scene/"
  },
  sleep: {
    label: "就寝",
    icon: "../assets/img/scene_sleep.svg",
    url: "../setup-scene/"
  },
  returnWinter: {
    label: "冬の帰宅",
    icon: "../assets/img/scene-icon-returning-home-winter.svg",
    url: "../setup-scene/"
  }
};

// トリガーイベント条件マスター
const TRIGGER_EVENT_DESCRIPTION_MASTER = {
  "schedule": "設定した時刻に指定されたアクションを実行します。繰り返し設定を行わない場合、１度だけ指定されたアクションを実行します。",
  "location": "選択された家電シェアユーザーのうちの1名以上が位置条件を満たした場合に、指定されたアクションを実行します。",
  "devices": "機器の運転状態を元に、指定されたアクションを実行します。トリガーイベントとして指定できる機器の運転状態は1つです。",
};

// トリガーイベントセクション表示／非表示マスター
const TRIGGER_EVENT_SECTION_MASTER = {
  "schedule": "schedule-section",
  "location": "location-section",
  "devices": "devices-section",
}

// アクションセレクトURLマスター
const ACTION_SELECT_URL = {
  scene: "../select-scene/",
  devices: "../select-device/",
  notify: "../select-notice/",
};

// しきい値マスター
const THRESHOLD_MASTER = {
    over: {
    label: "しきい値を超えたとき",
    tempture: "28"
  },
    under: {
    label: "しきい値を下回ったとき",
    tempture: "15"
  }
};

/******************************************
 * クリックイベント
 ******************************************/
const actionCardSection = document.getElementById("actionCardSection");
const addDeviceButton = document.getElementById("addDeviceButton");
const selectDeviceSection = document.querySelector(".js-select-device-section");
const thresholdBtnContainer = document.querySelector(".js-threshold-btn-container");
const actionSection = document.getElementById("actionSection");
const selectSceneSection = document.querySelector(".js-select-scene-section");

// 「シーンを選択」のクリックイベント（外出一括オフ／就寝／冬の帰宅）
if (selectSceneSection) {
  selectSceneSection.addEventListener("click", (e) => {

    const selectSceneBtn = e.target.closest(".js-select-scene-btn");
    if (!selectSceneBtn) return;

    const sceneId = selectSceneBtn.dataset.appKey;   // allOff / sleep / returnWinter
    const entryId = getJsonValue("entryId");

    if (!entryId) return;

    let actions = getJsonValue(`${entryId}.actions`) ?? [];

    // 最大5個制限
    if (actions.length >= 5) {
      alert("アクションは最大5つまでです");
      return;
    }

    // 新しいアクション作成
    const newAction = {
      actionId: createId(),
      type: "scene",
      id: sceneId
    };

    actions.push(newAction);

    // JSON保存
    setJsonValue(`${entryId}.actions`, actions);

    // 編集対象保存
    setJsonValue("editActionId", newAction.actionId);

    // シーン設定画面へ
    window.location.href = "../setup-scene/";

  });
}

// アクション追加のカードボタンをクリック（シーン／機器／通知）
if (actionSection) {
  actionSection.addEventListener("click", (e) => {
    const addActionBtn = e.target.closest(".js-add-action-btn");
    const actionType = addActionBtn.dataset.appAction;

    // devices のときだけ入口状態を保存
    if (actionType === "devices") {
      setJsonValue("entryDeviceCard", "action");
    }

    const url = ACTION_SELECT_URL[actionType];
    if (url) {
      window.location.href = url;
    }
  });
}

// 機器の状態を選択後のクリックイベント（しきい値を超えたとき／下回ったとき）
if (thresholdBtnContainer) {
  const entryAutoId = getJsonValue("entryId");
  thresholdBtnContainer.addEventListener("click", (e) => {
    const entryDeviceCard = e.target.closest(".js-threshold-btn");
    if (!entryDeviceCard) return;
    const key = entryDeviceCard.dataset.appKey;
    setJsonValue(`${entryAutoId}.triggers.devices.condition`, THRESHOLD_MASTER[key].label);
    setJsonValue(`${entryAutoId}.triggers.devices.threshold`, THRESHOLD_MASTER[key].tempture);
    setJsonValue(`${entryAutoId}.entryTrigger`, "devices");
    setJsonValue("currentTriggerEvent","devices");
    window.location.href = "../select-room-temperature-status/";
  })
};

// トリガーカード／アクションカードで機器を選択のクリックイベント（リビングのエアコン／寝室のエアコンのどちら）
if (selectDeviceSection) {
  selectDeviceSection.addEventListener("click", (e) => {
    const deviceBtn = e.target.closest(".js-select-device-btn");
    if (!deviceBtn) return;

    const deviceId = deviceBtn.dataset.appDevice;
    const entryId = getJsonValue("entryId");
    const entryDeviceCard = getJsonValue("entryDeviceCard"); // trigger / action
    if (!entryId) return;

    /* -----------------------------
       トリガー（機器の状態）
    ----------------------------- */
    if (entryDeviceCard === "trigger") {
      setJsonValue(`${entryId}.triggers.devices.id`, deviceId);
      setJsonValue(`${entryId}.triggers.devices.name`, DEVICE_MASTER[deviceId].label);
      window.location.href = "../select-device-operation/";
      return;
    }

    /* -----------------------------
       アクション（機器操作）
    ----------------------------- */
    let actions = getJsonValue(`${entryId}.actions`) ?? [];
    if (actions.length >= 5) {
      alert("アクションは最大5つまでです");
      return;
    }

    const newAction = {
      actionId: createId(),
      type: "devices",
      id: deviceId
    };

    actions.push(newAction);
    setJsonValue(`${entryId}.actions`, actions);
    setJsonValue("editActionId", newAction.actionId);

    /* 機器設定画面へ */
    const url = ACTION_MASTER.devices[deviceId]?.url;
    if (url) window.location.href = url;
  });
};

// 「機器の状態を追加」のクリックイベント（trigger／actionの入口を登録）
if (addDeviceButton) {
  addDeviceButton.addEventListener("click", (e) => {
    const entryDeviceCard = e.target.closest(".entry-device-card");
    const key = entryDeviceCard.dataset.appKey;
    if (!entryDeviceCard) return;
      setJsonValue("entryDeviceCard", key);
      window.location.href = "../select-device/";
  })
};
 
// アクションカードのクリックイベント（画面遷移）
if (actionCardSection) {
  actionCardSection.addEventListener("click", (e) => {
  const card = e.target.closest(".js-action-card");
  if (!card) return;
  const url = card.dataset.actionUrl;
  const actionId = card.dataset.actionId;
  if (!url) return;
  // 編集対象保存
  setJsonValue("editActionId", actionId);
  // 遷移
  window.location.href = url;
  });
}

// トリガーカードの削除／画面遷移（ゴミ箱アイコン／ボタン本体）確認用モーダル表示なし
const deviceCardContent = document.querySelector(".devices-section");
if (deviceCardContent) {
  deviceCardContent.addEventListener("click", (e) => {
    /* 削除ボタン */
    const deleteBtn = e.target.closest(".delete-trigger-card-btn");
    if (deleteBtn) {
      e.preventDefault();
      e.stopPropagation();
      const card = deleteBtn.closest(".js-device-card");
      if (!card) return;
      const entryAutoId = card.dataset.entryId;
      deleteTriggerCard(entryAutoId);
      return;
    }
    /* カードクリック */
    const cardBtn = e.target.closest(".js-device-card");
    if (cardBtn) {
      window.location.href = "../select-device-operation/";
    }
  });
}

// アクションカードの削除／画面遷移（ゴミ箱アイコン／ボタン本体）
if (actionCardSection) {
  actionCardSection.addEventListener("click", (e) => {
    /* 削除ボタン */
    const deleteBtn = e.target.closest(".delete-action-card-btn");
    if (!deleteBtn) return;
    e.preventDefault();
    e.stopPropagation();
    const card = deleteBtn.closest(".js-action-card");
    if (!card) return;
    AppState.deleteActionId = card.dataset.actionId;
    showModal("deleteActionCardButton");
  });
}

// アクションカード削除用モーダルの削除ボタンをクリックしたとき関数を呼び出す
document.addEventListener("click", (e) => {
  const btn = e.target.closest("#confirmDeleteActionCardButton");
  if (!btn) return;

  const modalEl = document.getElementById("deleteActionCardButton");
  const modal = bootstrap.Modal.getInstance(modalEl);
  // アクションカードを削除する関数
  deleteActionCard();
  if (modal) modal.hide();
});

// アクションカードボタンを削除する（JSON書き換え⇒再読み込み）
function deleteActionCard() {
  const entryId = getJsonValue("entryId");
  const actionId = AppState.deleteActionId;
  if (!actionId) return;

  let actions = getJsonValue(`${entryId}.actions`) ?? [];
  actions = actions.filter(action => action.actionId !== actionId);
  setJsonValue(`${entryId}.actions`, actions);
  AppState.deleteActionId = null;
  renderAutomationEditing();
  updateCompleteButtonState();
}









// 提案オートメーション画面
const proposalAutomation = document.querySelector('[data-app-header-set="proposalAutomation"]');
if (proposalAutomation) {
  proposalAutomation.addEventListener("click", (e) => {
    // 提案オートメーション（temp-1〜temp-6、new）
    const editAutomationBtn = e.target.closest(".js-edit-automation-btn");
    if (editAutomationBtn) {
      const key = editAutomationBtn.dataset.appKey;
      setJsonValue("entryId", key);
      window.location.href = "../edit-automation/";
    }
  })
};

// オートメーション画面
const automation = document.querySelector('[data-app-header-set="automation"]');
if (automation) {
  automation.addEventListener("click", (e) => {
    // オートメーションを追加ボタン（提案オートメーションへ遷移）
    const addAutomationBtn = e.target.closest(".js-add-automation");
    if (addAutomationBtn) {
      const key = addAutomationBtn.dataset.appKey;
      setJsonValue("entryId", key);
      window.location.href = "../proposal-automation/";
    }
    // 登録済みオートメーション（auto-1, auto-2, auto-3）
    const editAutomationBtn = e.target.closest(".js-edit-automation-btn");
    if (editAutomationBtn) {
      const key = editAutomationBtn.dataset.appKey;
      setJsonValue("entryId", key);
      window.location.href = "../edit-automation/";
    }
  })
};

// トリガーイベントボタンのクリックイベント（スケジュール／位置情報／機器）
const editAutomation = document.querySelector('[data-app-header-set="editAutomation"]');
if (editAutomation) {
editAutomation.addEventListener("click", (e) => {

  const triggerEventBtn = e.target.closest(".js-trigger-event-btn");
  if (triggerEventBtn) {
    const key = triggerEventBtn.dataset.appKey;
    const entryAutoId = getJsonValue("entryId");
    setJsonValue(`${entryAutoId}.entryTrigger`, key);
    renderTriggerSection();
    return;
  }

  const dayBtn = e.target.closest(".day-of-the-week");
  if (dayBtn) {
    const entryAutoId = getJsonValue("entryId");
    const day = dayBtn.dataset.appScheduleDay;
    toggleScheduleDay(entryAutoId, day);
    return;
  }

  const locationConditionBtn = e.target.closest(".js-location-condition");
  if (locationConditionBtn) {
    const entryId = getJsonValue("entryId");
    const condition = locationConditionBtn.dataset.appLocationCondition;
    if (!condition) return;

    let locationTrigger = getJsonValue(`${entryId}.triggers.location`) ?? {};
    locationTrigger.event = condition;

    setJsonValue(`${entryId}.triggers.location`, locationTrigger);

    renderLocationCondition(entryId);
    return;
  }

});};

  // 受け取った曜日を配列⇒JSONに保存
function toggleScheduleDay(entryAutoId, day) {
  const path = `${entryAutoId}.triggers.schedule.days`;
  let days = getJsonValue(path) ?? [];

  if (days.includes(day)) {
    days = days.filter(d => d !== day);
  } else {
    days.push(day);
  }

  setJsonValue(path, days);
  renderSchedule(entryAutoId);
}

// 曜日をレンダリングする
function renderSchedule(entryAutoId) {
  renderScheduleDays(entryAutoId);
  renderScheduleDescription(entryAutoId);
}


/******************************************
 * クリックイベント（モーダル系）
 ******************************************/
// オートメーション名を変更
const automationNameSection = document.querySelector('.automation-name-section');
if (automationNameSection) {
  automationNameSection.addEventListener("click", (e) => {
    // オートメーションを追加ボタン（提案オートメーションへ遷移）
    changeAutomationNameBtn = e.target.closest(".change-automation-name-btn");
    if (changeAutomationNameBtn) {
      const entryAutoId = getJsonValue("entryId");
      const automationName = getJsonValue(`${entryAutoId}.name`);
      const modalEl = document.getElementById("automationNameModal");  // モーダル要素
      const modal = bootstrap.Modal.getOrCreateInstance(modalEl);  // モーダル生成
      const inputEl = document.getElementById("scheduleName"); // input要素
      inputEl.value = automationName;// 現在のオートメーション名を表示
      modal.show(); // モーダル表示

    }
  })
};

// オートメーション削除ボタンのクリックイベント（新規オートメーションのみ／モーダル表示）
const deleteAutomation = document.querySelector(".js-delete-automation");
if (deleteAutomation) {
  deleteAutomation.addEventListener("click", (e) => {
    // 提案オートメーション（temp-1〜temp-6、new）
    const editAutomationBtn = e.target.closest(".js-delete-automation-btn");
    if (editAutomationBtn) {
      showModal("deleteAutomationModal");
    }
  });
}












/******************************************
 * レンダリング（小画面）
 ******************************************/
// シーン設定画面のレンダリング
const renderSetupScene = () => {

  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");

  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);

  if (!action || action.type !== "scene") return;

  const sceneId = action.id;

  /* シーン名 */
  const sceneNameEl = document.getElementById("sceneName");
  if (sceneNameEl) {
    sceneNameEl.textContent = SCENE_MASTER[sceneId]?.label ?? "";
  }

  /* 全非表示 */
  document
    .querySelectorAll(".allOff,.sleep,.returnWinter")
    .forEach(el => el.classList.add("d-none"));

  /* 対象表示 */
  document
    .querySelectorAll(`.${sceneId}`)
    .forEach(el => el.classList.remove("d-none"));

};


// 機器を選択画面
function renderSelectDeviceScreen() {
  const entryDeviceCard = getJsonValue("entryDeviceCard");
  const eqBtn = document.querySelector(
    ".js-select-device-btn[data-app-device='eq']",
  );
  if (entryDeviceCard === "devices") eqBtn.style.display = "none";

  const targetSection = document.querySelector(".js-select-device-section");
  const btnRac1 = targetSection.querySelector(
    '.js-select-device-btn[data-app-device="rac-1"]',
  );
  const btnRac2 = targetSection.querySelector(
    '.js-select-device-btn[data-app-device="rac-2"]',
  );
}

// しきい値が所定値を…機器選択後、機器の名前を表示する
const renderRoomTempTriggerButtons = () => {
  // 機器名を表示
  const entryId = getJsonValue("entryId");
  const deviceNameEl = document.getElementById("deviceName");
  const deviceName = getJsonValue(`${entryId}.triggers.devices.name`);
  deviceNameEl.textContent = deviceName ?? "選択された機器の名前"; // ここは実際には選択された機器の名前を入れる
  const underBtn = document.querySelector(".js-threshold-btn[data-app-key='under']");
  const overBtn = document.querySelector(".js-threshold-btn[data-app-key='over']");

  // JSONから condition 取得
  const condition = getJsonValue(`${entryId}.triggers.devices.condition`);
  if (!condition) return;

  // condition → over / under に変換
  let current = "";
  if (condition.includes("超え")) {
    current = "over";
    overBtn.classList.add("active");
    overBtn.setAttribute("aria-pressed", "true");
  }
  if (condition.includes("下回")) {
    current = "under";
    underBtn.classList.add("active");
    underBtn.setAttribute("aria-pressed", "true");
  }

  // ボタン取得
  const buttons = document.querySelectorAll(".js-threshold-btn");
  buttons.forEach((btn) => {
    const onclick = btn.getAttribute("onclick") ?? "";
    // onclick から over / under 判定
    const isOver = onclick.includes("'over'");
    const isUnder = onclick.includes("'under'");

    let type = "";
    if (isOver) type = "over";
    if (isUnder) type = "under";

    // active 切替
    if (type === current) {
      btn.classList.add("active");
      btn.setAttribute("aria-pressed", "true");
    } else {
      btn.classList.remove("active");
      btn.setAttribute("aria-pressed", "false");
    }
  });
};

// 室温が所定値を超えたとき／下回ったとき 画面
const selectRoomTemperatureStatus = () => {
  const entryId = getJsonValue("entryId");

  // JSONから condition 取得
  const condition = getJsonValue(`${entryId}.triggers.devices.condition`);
  if (!condition) return;

  // condition → over / under に変換
  let current = "";
  if (condition.includes("超え")) {
    document.body.setAttribute("data-app-header-set", "selectRoomTemperatureStatusOver");
    document.getElementById("section-over").classList.remove("d-none");
    // initHeader(); // ← 追加
  }
  if (condition.includes("下回")) {
    document.body.setAttribute("data-app-header-set", "selectRoomTemperatureStatusUnder");
    document.getElementById("section-under").classList.remove("d-none");
    // initHeader(); // ← 追加
  }
};

/******************************************
 * レンダリング（オートメーション編集画面）
 ******************************************/
// オートメーション編集画面
const renderAutomationEditing = () => {
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);
  renderAutomationName(entryAutoId);                // オートメーション名
  createTriggerButton(entryAutoId, entryTrigger);
  renderTriggerSection(entryAutoId, entryTrigger);  // トリガーイベントセクション
  createActionButton(entryAutoId);
  // deleteBtnState(entryAutoId);
  // updateCompleteButtonState();  // ←追加
}

// トリガーイベントセクションを読み込む（親関数）
const renderTriggerSection = () => {
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);
  renderTriggerButtons(entryTrigger);      // トリガーイベントボタン
  renderTriggerDescription(entryTrigger);  // トリガーイベント条件（文章）
  renderScheduleDays(entryAutoId);         // 曜日（繰り返し）
  renderScheduleDescription(entryAutoId);  // 曜日説明文
  renderScheduleStartTime(entryAutoId);    // 時間
  renderLocationUsers(entryAutoId);        // 通知するユーザー（家電シェアユーザー）
  renderLocationCondition(entryAutoId);    // 位置条件（近づいたとき／離れたとき）
  renderTriggerEventSection(entryAutoId, entryTrigger); // トリガーイベントセクション
};

// オートメーション名を読み込む
const renderAutomationName = (entryAutoId) => {
  const el = document.getElementById("autoName");
  const automationName = getJsonValue(`${entryAutoId}.name`);
  if (!el) return;
  const name = automationName?.trim();
  if (name) {
    el.textContent = name;
  } else {
    el.textContent = "オートメーション名（未設定）";
  }
};

// トリガーイベントボタンの状態を読み込む
const renderTriggerButtons = (entryTrigger) => {
  const targetElements = document.querySelectorAll(".js-trigger-event-btn");
  targetElements.forEach((el) => {
    const key = el.dataset.appKey;
    if (key === entryTrigger) {
      el.classList.add("active");
      el.setAttribute("aria-pressed", "true");
    } else {
      el.classList.remove("active");
      el.setAttribute("aria-pressed", "false");
    }
  });
};

// トリガーイベント条件（文章）の表示制御
const renderTriggerDescription = (entryTrigger) => {
  const targetElement = document.querySelector(".trigger-section");
  targetElement.innerText = TRIGGER_EVENT_DESCRIPTION_MASTER[entryTrigger];
};

// 曜日を代入
const renderScheduleDays = (entryAutoId) => {
  const targetElements = document.querySelectorAll(".day-of-the-week");
  if (!targetElements.length) return;

  // schedule.days を安全に取得
  const days = getJsonValue(`${entryAutoId}.triggers.schedule.days`) ?? [];

  targetElements.forEach((el) => {
    const day = el.dataset.appScheduleDay;
    const isActive = days.includes(day);

    el.classList.toggle("active", isActive);
    el.setAttribute("aria-pressed", String(isActive));
  });
};

// 曜日説明文を代入
function renderScheduleDescription(entryAutoId) {
  const scheduleTrigger = getJsonValue(`${entryAutoId}.triggers.schedule`);
  if (!scheduleTrigger) return;

  const days = scheduleTrigger.days ?? [];
  const description = createScheduleDescription(days);

  const descriptionElement = document.getElementById("scheduleText");
  if (!descriptionElement) return;

  descriptionElement.textContent = description;
}

//　曜日説明文を作成
function createScheduleDescription(days) {
  const allDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const dayNames = {
    sun: "日",
    mon: "月",
    tue: "火",
    wed: "水",
    thu: "木",
    fri: "金",
    sat: "土",
  };

  if (!days || days.length === 0) {
    return "一度だけ実行します";
  }

  if (days.length === 7) {
    return "毎日実行します";
  }

  const selectedDayNames = days
    .sort((a, b) => allDays.indexOf(a) - allDays.indexOf(b))
    .map((day) => dayNames[day])
    .join("");

  return `毎週${selectedDayNames}曜日に実行します`;
}

// 時間を代入
const renderScheduleStartTime = (entryAutoId) => {
  const el = document.getElementById("autoStartTime");
  const automationTime = getJsonValue(`${entryAutoId}.triggers.schedule.time`);

  if (!el) return;
  const time = automationTime?.trim();
  if (time) {
    el.textContent = time;
  } else {
    el.textContent = "開始時間（未設定）";
  }
};

// トリガーイベントセクションの表示／非表示
const renderTriggerEventSection = (entryAutoId, entryTrigger) => {
  document
    .querySelectorAll(".schedule-section, .location-section, .devices-section")
    .forEach(el => el.style.display = "none");

  const threshold = getJsonValue(`${entryAutoId}.triggers.devices.threshold`);
  const addBtn = document.getElementById("addDeviceButton");
  const cardBtn = document.querySelector(".trigger-card-button");

  // devices以外
  if (!(entryTrigger === "devices")) {
    const key = TRIGGER_EVENT_SECTION_MASTER[entryTrigger];
    const target = document.querySelector(`.${key}`);
    if (target) target.style.display = "";
  }

  // devices
  if (entryTrigger === "devices") {
    if (!threshold) {
      addBtn.style.display = "block";
      cardBtn ? cardBtn.style.display = "none" : null;
    } else {
      addBtn.style.display = "none";
      cardBtn.style.display = "block";
    }
  }
};

// 通知するユーザー（家電シェアユーザー）のチェックボックスを選択する
const renderLocationUsers = (entryAutoId) => {
  // location-section 内の checkbox を取得
  const checkboxes = document.querySelectorAll('.location-section input[type="checkbox"]');
  if (!checkboxes.length) return;

  // location trigger を取得
  const locationTrigger = getJsonValue(`${entryAutoId}.triggers.location`);
  if (!locationTrigger) return;

  const selectedUsers = locationTrigger.users || [];
  checkboxes.forEach((checkbox) => {
    const userName = checkbox.value;
    // JSON に含まれていればチェックON
    checkbox.checked = selectedUsers.includes(userName);
  });
};

// 位置条件のイベントを代入（自宅に近づいたとき／自宅から離れたとき）
const renderLocationCondition = (entryAutoId) => {
  const selectedCondition = getJsonValue(`${entryAutoId}.triggers.location.event`);
  // UI更新用の関数
  function updateLocationConditionUI(conditionValue) {
    const targetElements = document.querySelectorAll(".js-location-condition");
    targetElements.forEach((el) => {
      const condition = el.dataset.appLocationCondition;
      if (condition === conditionValue) {
        el.setAttribute("aria-pressed", "true");
        el.classList.add("active");
      } else {
        el.setAttribute("aria-pressed", "false");
        el.classList.remove("active");
      }
    });
  }
  updateLocationConditionUI(selectedCondition);
}

// トリガーカードを作成
function createTriggerButton(entryAutoId) {
  const device = getJsonValue(`${entryAutoId}.triggers.devices`);
  if (!device?.threshold) return;

  const section = document.getElementById("devicesSection");
  const template = document.getElementById("deviceTemplate");
  const addBtn = document.getElementById("addDeviceButton");

  if (!section || !template || !addBtn) return;

  // 既存カード削除（再render対策）
  section.querySelectorAll(".trigger-card-button").forEach(el => el.remove());

  // templateからクローン生成
  const clone = template.content.firstElementChild.cloneNode(true);

  clone.classList.add("trigger-card-button");
  clone.classList.add("devices-section");

  addBtn.classList.remove("devices-section");

  /* ============================
     データセット追加
  ============================ */

  clone.dataset.deviceId = device.id;
  clone.dataset.entryId = entryAutoId;
  clone.dataset.triggerType = "devices";

  /* ============================
     表示内容
  ============================ */

  clone.querySelector(".name").textContent =
    device.name ?? "（未設定）";

  clone.querySelector(".description").textContent =
    `${device.condition} 温度${device.threshold}℃`;

  // カード挿入
  section.insertBefore(clone, addBtn);

  // ＋ボタン非表示
  addBtn.style.display = "none";

}

// アクションカードボタンを作成createActionButton
function createActionButton(entryAutoId) {
  const actions = getJsonValue(`${entryAutoId}.actions`) ?? [];
  if (actions.length > 5) {
    alert("アクションは最大5つまでです");
    return;
  }

  const area = document.getElementById("actionCardSection");
  const template = document.getElementById("actionTemplate");

  if (!area || !template) return;

  /* 既存カード削除 */
  area.querySelectorAll(".js-action-card").forEach(el => el.remove());

  actions.slice(0, 5).forEach((action, index) => {
    const fragment = template.content.cloneNode(true);
    const card = fragment.querySelector(".js-action-card");
    const icon = fragment.querySelector(".source");
    const name = fragment.querySelector(".name");
    const description = fragment.querySelector(".description");
    if (!card) return;

    /* dataset */
    card.dataset.actionId = action.actionId;
    card.dataset.actionType = action.type;
    card.dataset.actionIndex = index;

    let url = "";

    /* ==============================
       devices
    ============================== */
    if (action.type === "devices") {
      const device = ACTION_MASTER.devices[action.id];
      const master = DEVICE_MASTER[action.id];
      if (!device || !master) return;
      icon.src = device.icon;
      name.textContent = master.label;
      let desc = master[action.drive] ?? "";
      if (action.mode) desc += ` ${action.mode}`;
      if (action.temp) desc += ` ${action.temp}℃`;
      description.textContent = desc;
      url = device.url;
    }

    /* ==============================
       notify
    ============================== */
    if (action.type === "notify") {
      icon.src = ACTION_MASTER.notify.icon;
      name.textContent = "通知";
      description.textContent = action.message ?? "";
      url = ACTION_MASTER.notify.url;
    }

    /* ==============================
       scene
    ============================== */
    if (action.type === "scene") {
      const scene = SCENE_MASTER[action.id];
      if (!scene) return;
      icon.src = scene.icon;
      name.textContent = scene.label;
      description.textContent = "シーンを実行";
      url = scene.url;
    }
    card.dataset.actionUrl = url;
    area.appendChild(fragment);
  });
  updateCompleteButtonState();
}

// 完了ボタンの制御関数
function updateCompleteButtonState() {

  const entryId = getJsonValue("entryId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];

  const btn = document.getElementById("headerRightBtn");
  if (!btn) return;

  const isActive = actions.length > 0;

  btn.disabled = !isActive;
  btn.classList.toggle("disabled", !isActive);
  btn.classList.toggle("active", isActive);
}





// オートメーション画面でカードを生成する
function renderNewAutomationCard() {
  // 新規オートメーションカードを作成する領域
  const list = document.getElementById("newAutomationCard");
  if (!list) return;

  /* すでに生成済みなら終了 */
  if (list.querySelector('[data-app-key="new"]')) return;

  const newAuto = getJsonValue("new");
  if (!newAuto) return;
  if (newAuto.status !== true) return;


  const template = document.querySelector(".js-automation-template");
  if (!template) return;

  const clone = template.cloneNode(true);

  clone.style.display = "block";
  clone.classList.remove("js-automation-template");
  clone.classList.add("js-edit-automation-btn");
  clone.dataset.appKey = "new";

  /* ---------- オートメーション名 ---------- */

  const nameEl = clone.querySelector(".automationName");
  if (nameEl) {
    nameEl.textContent = newAuto.name ?? "新しいオートメーション";
  }

  /* ---------- トリガー ---------- */

  const triggerIcon = clone.querySelector(".triggerIcon");
  const triggerCondition = clone.querySelector(".triggerCondition");
  const trigger = newAuto.entryTrigger;

  if (trigger === "schedule") {
    if (triggerIcon) {
      triggerIcon.src = "../assets/img/icon-clock.svg";
    }
    const time = newAuto.triggers?.schedule?.time ?? "";
    const days = newAuto.triggers?.schedule?.days ?? [];
    const text = createScheduleDescription(days);
    if (triggerCondition) {
      triggerCondition.textContent = `${time} ${text}`;
    }
  }

  if (trigger === "devices") {
    if (triggerIcon) {
      triggerIcon.src = "../assets/img/icon_apps_40.svg";
    }
    const device = newAuto.triggers?.devices;
    if (triggerCondition && device) {
      triggerCondition.textContent =
        `${device.condition} 温度${device.threshold}℃`;
    }
  }

  if (trigger === "location") {
    if (triggerIcon) {
      triggerIcon.src = "../assets/img/icon_GPS_40.svg";
    }
    const event = newAuto.triggers?.location?.event;
    if (triggerCondition) {
      triggerCondition.textContent =
        event === "close"
          ? "自宅に近づいたとき"
          : "自宅から離れたとき";
    }
  }

  /* ---------- アクション ---------- */

  const actionIcon = clone.querySelector(".actionIcon");

  const action = newAuto.actions?.[0];

  if (action && actionIcon) {

    if (action.type === "devices") {
      actionIcon.src = DEVICE_MASTER[action.id]?.icon ?? "";
    }
    if (action.type === "notify") {
      actionIcon.src = ACTION_MASTER.notify.icon;
    }
    if (action.type === "scene") {
      actionIcon.src = SCENE_MASTER[action.id]?.icon ?? "";
    }
  }

  /* ---------- 挿入 ---------- */
  list.style.display = "block";
  list.appendChild(clone);
}

// トリガーカードを削除する（しきい値が…）
function deleteTriggerCard(entryAutoId) {
  setJsonValue(`${entryAutoId}.triggers.devices`, {});
  renderAutomationEditing();
}

// アクションカードの内容を編集画面に反映させる
function initDeviceEditor() {

  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);
  if (!action) return;

  // デフォルト値（必要に応じて変更してください）
  const defaults = { drive: "on", mode: "冷房", temp: 28 };

  // UI に渡す値を nullish coalescing で決定
  const drive = action.drive ?? defaults.drive;
  const mode = action.mode ?? defaults.mode;
  const temp = action.temp ?? defaults.temp;

  setDeviceName(action.id);
  setDriveButton(drive);
  setModeSelect(mode);
  setTempInput(temp);
}

function setDeviceName(deviceId) {
  const el = document.getElementById("deviceName");
  if (!el) return;
  const name = DEVICE_MASTER[deviceId]?.label ?? "（未設定）";
  el.textContent = name;
}

function setDriveButton(drive) {
  document.querySelectorAll(".js-drive").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.appDrive === drive);
  });
}

function setModeSelect(mode) {
  document.querySelectorAll(".js-mode").forEach((btn) => {
    const isActive = btn.dataset.appMode === mode;
    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", String(isActive));
  });
}

function setTempInput(temp) {
  const input = document.getElementById("racSettingTemperature");
  if (!input) return;
  input.textContent = `${temp ?? ""}℃`;
}
