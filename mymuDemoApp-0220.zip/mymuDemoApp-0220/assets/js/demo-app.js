/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/alert.txt").then((r) => r.text()),
      fetch("../../partials/header.txt").then((r) => r.text()),
      fetch("../../partials/footer.txt").then((r) => r.text()),
      fetch("../../partials/modal.txt").then((r) => r.text()),
      fetch("../../partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  // initModalDriveModeSelectButtons();
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  // 基本機能 画面
  // renderDriveModeSwitchBtnAndSettingPanelOperation();
}

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("appData", JSON.stringify(data));
  // console.log(data.automation.items["auto-1"].actions[0]);
};

/******************************************
 * JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）ヘッダー用
 ******************************************/
const setHeaderJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("headerSet", JSON.stringify(data));
  // console.log(data.automation.items["new"].triggers[0].days);
};


/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");

  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = "../schedule/";
      break;

    // アラート表示
    case "touch-airflow-back":
      alert(
        "風向を設定しました。やり直す場合は画像をダブルタップしてください。",
      );
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 * 対象：フッターのアイコン
 * アクション：JSON更新(currentPage)
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 * 対象：フッターのアイコン
 * アクション：アクティブページのフッターアイコンの表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * ユーティリティ：全画面
 * 対象：トグルスイッチ（button要素内にあるスイッチ）
 * アクション：クリック時の伝播を防ぐ
 ******************************************/
document.querySelectorAll(".form-check-input").forEach((toggle) => {
  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});

/******************************************
 * ユーティリティ：全画面
 * 対象：button要素、スイッチ要素
 * アクション：「デモアプリではこのボタンは操作できません。」を表示する
 ******************************************/
document.addEventListener("click", (e) => {
  const target = e.target.closest(".demo-toggle-alert");
  if (!target) return;

  // 現在の状態を保持（クリック後の状態）
  const currentChecked = target.checked;
  e.stopPropagation();

  alert("デモアプリではこのボタンは操作できません。");

  // 元の状態に戻す
  target.checked = !currentChecked;
});

/******************************************
 * マッピングオブジェクト
 ******************************************/
// 機器名、アイコンマスター
const DEVICE_MASTER = {
  "rac-1": {
    label: "リビングのエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
    on: "運転開始",
    off: "運転停止",
  },
  "rac-2": {
    label: "寝室のエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
    on: "運転開始",
    off: "運転停止",
  },
  "eq": {
    label: "給湯機",
    icon: "../assets/img/product_Icon_EQ_40pt.svg",
    settings: "../device-settings-eq/",
    on: "ふろ自動開始",
    off: "ふろ自動停止",
  },
};

// 製品カテゴリマスター
const CATEGORY_MASTER = {
  "rac-1": "rac",
  "rac-2": "rac",
  "eq": "eq",
};

// アクション マスター
const ACTION_MASTER = {
  devices: {
    "rac-1": {
      icon: "../assets/img/icon_AC_40pt.svg",
      url: "../device-settings-rac/",
    },
    "rac-2": {
      icon: "../assets/img/icon_AC_40pt.svg",
      url: "../device-settings-rac/",
    },
    "eq": {
      icon: "../assets/img/product_Icon_EQ_40pt.svg",
      url: "../device-settings-eq/",
    },
  },
  notify: {
    icon: "../assets/img/icon_Notifications_40.svg",
    url: "../select-notice/",
  },
};


// トリガーイベント条件
const TRIGGER_EVENT_DESCRIPTION_MASTER = {
  "schedule": "設定した時刻に指定されたアクションを実行します。繰り返し設定を行わない場合、１度だけ指定されたアクションを実行します。",
  "location": "選択された家電シェアユーザーのうちの1名以上が位置条件を満たした場合に、指定されたアクションを実行します。",
  "devices": "機器の運転状態を元に、指定されたアクションを実行します。トリガーイベントとして指定できる機器の運転状態は1つです。",
};

// トリガーイベントセクション表示／非表示
const TRIGGER_EVENT_SECTION_MASTER = {
  "schedule": "schedule-section",
  "location": "location-section",
  "devices": "devices-section",
}

/******************************************
 * オートメーション編集 画面
 ******************************************/
// オートメーション編集画面
const renderAutomationEditing = () => {
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);


  renderAutomationName(entryAutoId);                // オートメーション名
  createAutomationTriggerButton(entryAutoId, entryTrigger); 
  renderTriggerSection(entryAutoId, entryTrigger);  // トリガーイベントセクション
  createActionButton(entryAutoId);
  // render();
  // renderDeviceTriggerButton(entryAutoId);        // 機器の状態を追加で生成されるカードボタン
}

// オートメーション名を読み込む
const renderAutomationName = (entryAutoId) => {
  const el = document.getElementById("autoName");
  const automationName = getJsonValue(`${entryAutoId}.name`);

  if (!el) return;
  const name = automationName?.trim();
  if (name) {
    el.textContent = name;
  } else {
    el.textContent = "オートメーション名（未設定）";
  }
};

// トリガーイベントセクションを読み込む（親関数）
const renderTriggerSection = () => {
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);
  renderTriggerButtons(entryTrigger); // トリガーイベントボタン
  renderTriggerDescription(entryTrigger); // トリガーイベント条件（文章）
  renderScheduleDays(entryAutoId);         // 曜日（繰り返し）
  renderScheduleDescription(entryAutoId);  // 曜日説明文
  renderScheduleStartTime(entryAutoId);    // 時間
  // renderSchedule(entryAutoId)
  renderLocationUsers(entryAutoId);        // 通知するユーザー（家電シェアユーザー）
  renderLocationCondition(entryAutoId);    // 位置条件（近づいたとき／離れたとき）
  renderTriggerEventSection(entryAutoId, entryTrigger); // トリガーイベントセクション
};

document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-trigger-event");
  if (!btn) return;

  const key = btn.dataset.appKey;
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);
  setJsonValue(`${entryAutoId}.entryTrigger`, key);
  renderTriggerSection();
  // render(); // ←これだけ
});

// トリガーイベントボタンの状態を読み込む
const renderTriggerButtons = (entryTrigger) => {
  const targetElements = document.querySelectorAll(".js-trigger-event");
  targetElements.forEach((el) => {
    const key = el.dataset.appKey;
    if (key === entryTrigger) {
      el.classList.add("active");
      el.setAttribute("aria-pressed", "true");
    } else {
      el.classList.remove("active");
      el.setAttribute("aria-pressed", "false");
    }
  });
};

// トリガーイベントセクションの表示／非表示
const renderTriggerEventSection = (entryAutoId, entryTrigger) => {
  document
    .querySelectorAll(".schedule-section, .location-section, .devices-section")
    .forEach(el => el.style.display = "none");

  const threshold = getJsonValue(`${entryAutoId}.triggers.devices.threshold`);
  const template = document.querySelector(".deviceTemplate");
  const addBtn = document.getElementById("addDeviceButton");
  const cardBtn = document.querySelector(".trigger-card-button");

  if (!(entryTrigger === "devices")) {
    const key = TRIGGER_EVENT_SECTION_MASTER[entryTrigger];
    const target = document.querySelector(`.${key}`);
    if (target) target.style.display = "";
  }

if (entryTrigger === "devices") {
  if (!threshold) {
    addBtn.style.display = "block";
    cardBtn ? cardBtn.style.display = "none" : null;
  } else {
    addBtn.style.display = "none";
    cardBtn.style.display = "block";
  }
}
};

// トリガーイベント条件（文章）の表示制御
const renderTriggerDescription = (entryTrigger) => {
  const targetElement = document.querySelector(".trigger-section");
  targetElement.innerText = TRIGGER_EVENT_DESCRIPTION_MASTER[entryTrigger];
};

// トリガーイベントボタンのクリックイベント
// document.addEventListener("click", (e) => {
//   const btn = e.target.closest(".js-trigger-event");
//   if (!btn) return;

//   const key = btn.dataset.appKey;
//   const entryAutoId = getJsonValue("entryId");
//   setJsonValue(`${entryAutoId}.entryTrigger`, key);

//   const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);
//   renderTriggerSection(entryAutoId, entryTrigger);
// });

// 時間を代入
const renderScheduleStartTime = (entryAutoId) => {
  const el = document.getElementById("autoStartTime");
  const automationTime = getJsonValue(`${entryAutoId}.triggers.schedule.time`);

  if (!el) return;
  const time = automationTime?.trim();
  if (time) {
    el.textContent = time;
  } else {
    el.textContent = "開始時間（未設定）";
  }
};

// 曜日を代入
const renderScheduleDays = (entryAutoId) => {
  const targetElements = document.querySelectorAll(".day-of-the-week");
  if (!targetElements.length) return;

  // schedule.days を安全に取得
  const days = getJsonValue(`${entryAutoId}.triggers.schedule.days`) ?? [];

  targetElements.forEach((el) => {
    const day = el.dataset.appScheduleDay;
    const isActive = days.includes(day);

    el.classList.toggle("active", isActive);
    el.setAttribute("aria-pressed", String(isActive));
  });
};

  // 曜日説明文を代入
function renderScheduleDescription(entryAutoId) {
  const scheduleTrigger = getJsonValue(`${entryAutoId}.triggers.schedule`);
  if (!scheduleTrigger) return;

  const days = scheduleTrigger.days ?? [];
  const description = createScheduleDescription(days);

  const descriptionElement = document.getElementById("scheduleText");
  if (!descriptionElement) return;

  descriptionElement.textContent = description;
}

// 通知するユーザー（家電シェアユーザー）のチェックボックスを選択する
const renderLocationUsers = (entryAutoId) => {
  // location-section 内の checkbox を取得
  const checkboxes = document.querySelectorAll(
    '.location-section input[type="checkbox"]'
  );

  if (!checkboxes.length) return;

  // location trigger を取得
  const locationTrigger = getJsonValue(`${entryAutoId}.triggers.location`);
  if (!locationTrigger) return;

  const selectedUsers = locationTrigger.users || [];

  checkboxes.forEach((checkbox) => {
    const userName = checkbox.value;

    // JSON に含まれていればチェックON
    checkbox.checked = selectedUsers.includes(userName);
  });
};

// 位置条件のイベントを代入
const renderLocationCondition = (entryAutoId) => {

  const selectedCondition = getJsonValue(
    `${entryAutoId}.triggers.location.event`
  );

  // UI更新用の関数
  function updateLocationConditionUI(conditionValue) {

    const targetElements = document.querySelectorAll(".js-location-condition");

    targetElements.forEach((el) => {
      const condition = el.dataset.appLocationCondition;

      if (condition === conditionValue) {
        el.setAttribute("aria-pressed", "true");
        el.classList.add("active");
      } else {
        el.setAttribute("aria-pressed", "false");
        el.classList.remove("active");
      }
    });
  }
  updateLocationConditionUI(selectedCondition);
}
// 「機器の状態を追加」のあとで生成されるカードボタンを作成
function createAutomationTriggerButton(entryAutoId) {
  const device = getJsonValue(`${entryAutoId}.triggers.devices`);
  if (!device?.threshold) return;

  const section = document.getElementById("devicesSection");
  const template = document.getElementById("deviceTemplate");
  const addBtn = document.getElementById("addDeviceButton");

  if (!section || !template || !addBtn) return;

  // 既存カード削除（再render対策）
  section.querySelectorAll(".trigger-card-button")
      .forEach(el => el.remove());

  const clone = template.cloneNode(true);

  clone.removeAttribute("id");
  clone.style.display = "block";
  clone.classList.add("trigger-card-button");
  clone.classList.add("devices-section");
  addBtn.classList.remove("devices-section");

  // 🔽 ここでテキスト代入（統合）
  clone.querySelector(".name").textContent =
    device.name ?? "（未設定）";

  clone.querySelector(".description").textContent =
    `${device.condition} 温度${device.threshold}℃`;

  // 追加
  section.insertBefore(clone, addBtn);

  // ＋非表示
  addBtn.style.display = "none";
}

/******************************************
 * オートメーション編集 画面
 * アクションセクション内の処理
 ******************************************/
// イニシャライズ：アクション内のカードボタン（シーン／機器操作／通知 を追加）
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-trigger-section");
  if (!btn) return;
  const section = btn.dataset.appAction;

  if (section === "scene") {
    window.location.href = "../select-scene/";
  } else if (section === "devices") {
    window.location.href = "../select-device/";
  } else if (section === "notify") {
    window.location.href = "../select-notice/";
  }
});

/******************************************
 * オートメーション 画面
 ******************************************/
// エントリー用のオートメーションIDをJSONに保存、編集画面へ遷移する
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-automation-id");
  if (!btn) return;

  const key = btn.dataset.appKey;
  setJsonValue("entryId", key);
  window.location.href = "../edit-automation/";
});

/******************************************
 * オートメーション編集 画面
 * イニシャライズ
 ******************************************/
function createScheduleDescription(days) {
  const allDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const dayNames = {
    sun: "日",
    mon: "月",
    tue: "火",
    wed: "水",
    thu: "木",
    fri: "金",
    sat: "土",
  };

  if (!days || days.length === 0) {
    return "一度だけ実行します";
  }

  if (days.length === 7) {
    return "毎日実行します";
  }

  const selectedDayNames = days
    .sort((a, b) => allDays.indexOf(a) - allDays.indexOf(b))
    .map((day) => dayNames[day])
    .join("");

  return `毎週${selectedDayNames}曜日に実行します`;
}

//　クリックした曜日を渡す
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".day-of-the-week");
  if (!btn) return;

  const entryAutoId = getJsonValue("entryId");
  const day = btn.dataset.appScheduleDay;
  toggleScheduleDay(entryAutoId, day);
});

// 受け取った曜日を配列⇒JSONに保存
function toggleScheduleDay(entryAutoId, day) {
  const path = `${entryAutoId}.triggers.schedule.days`;

  let days = getJsonValue(path) ?? [];

  if (days.includes(day)) {
    days = days.filter(d => d !== day);
  } else {
    days.push(day);
  }

  setJsonValue(path, days);
  renderSchedule(entryAutoId);
}

// レンダリングする
function renderSchedule(entryAutoId) {
  renderScheduleDays(entryAutoId);
  renderScheduleDescription(entryAutoId);
}

// /******************************************
//  * イニシャライズ：オートメーション 画面
//  * 対象：＋ボタン
//  * アクション：新規オートメーション画面へ遷移する
//  ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-add-automation");
  if (!btn) return;
  window.location.href = "../proposal-automation/";
});



function createActionButton(entryAutoId) {

  const actions =
    getJsonValue(`${entryAutoId}.actions`) ?? [];

  if (!actions.length) return;


  const area =
    document.getElementById("actionCardArea");

  const template =
    document.getElementById("actionTemplate");

  if (!area || !template) return;


  // 既存カード削除
  area.querySelectorAll(".action-card")
      .forEach(el => el.remove());


  // 最大5件まで表示
  actions.slice(0, 5).forEach((action, index) => {

    const clone = template.cloneNode(true);

    clone.removeAttribute("id");
    clone.style.display = "block";
    clone.classList.add("action-card");


    /* ===== data属性 ===== */
    clone.dataset.actionType  = action.type ?? "";
    clone.dataset.actionId    = action.id ?? "";
    clone.dataset.actionIndex = index;


    const {
      type,
      id,
      drive,
      mode,
      temp,
      message
    } = action;


    let url = "";


    /* ===== devices ===== */
    if (type === "devices") {

      const device = ACTION_MASTER.devices[id];
      const master = DEVICE_MASTER[id];

      if (!device || !master) return;


      clone.querySelector(".source").src =
        device.icon;

      clone.querySelector(".name").textContent =
        master.label ?? "（未設定）";


      let desc = master[drive] ?? "";

      if (mode) desc += ` ${mode}`;
      if (temp) desc += ` ${temp}℃`;

      clone.querySelector(".description").textContent =
        desc;


      // ★ URL設定
      url = device.url;
    }


    /* ===== notify ===== */
    else if (type === "notify") {

      clone.querySelector(".source").src =
        ACTION_MASTER.notify.icon;

      clone.querySelector(".name").textContent =
        "通知";

      clone.querySelector(".description").textContent =
        message ?? "";


      // ★ URL設定
      url = ACTION_MASTER.notify.url;
    }


    /* ===== URL保存 ===== */
    clone.dataset.actionUrl = url;


    /* ===== append ===== */
    area.appendChild(clone);

  });

}

// アクションカードのクリックイベント
document.addEventListener("click", e => {

  const card = e.target.closest(".action-card");
  if (!card) return;

  const url   = card.dataset.actionUrl;
  const index = card.dataset.actionIndex;

  if (!url) return;


  // 編集対象保存
  setJsonValue("editActionIndex", index);

  // 遷移
  window.location.href = url;
});


// アクションカードの内容を編集画面に反映させる
function initDeviceEditor() {

  const entryId = getJsonValue("entryId");
  const index   = getJsonValue("editActionIndex");


  const action = getJsonValue(`${entryId}.actions.${index}`);
  if (!action) return;

  // 機器名を反映
  setDeviceName(action.id);

  // ON / OFF
  setDriveButton(action.drive);

  // モード
  setModeSelect(action.mode);

  // 温度
  setTempInput(action.temp);
}

function setDeviceName(deviceId) {

  const el = document.getElementById("deviceName");

  if (!el) return;

  const name = DEVICE_MASTER[deviceId]?.label ?? "（未設定）";
  el.textContent = name;
}

function setDriveButton(drive) {
  document.querySelectorAll(".js-drive").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.appDrive === drive);
  });
}

function setModeSelect(mode) {
  document.querySelectorAll(".js-mode").forEach((btn) => {
    const isActive = btn.dataset.appMode === mode;
    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", String(isActive));
  });
}

function setTempInput(temp) {
  const input = document.getElementById("racSettingTemperature");
  if (!input) return;
  input.textContent = `${temp ?? ""}℃`;
}

function initNotifyEditor() {

  const entryId = getJsonValue("entryId");
  const index   = getJsonValue("editActionIndex");

  const action =
    getJsonValue(`${entryId}.actions.${index}`);

  if (!action || action.type !== "notify") return;


  /* ===== 機器名 ===== */
  const deviceNameEl =
    document.getElementById("notifyDeviceName");

  if (deviceNameEl) {

    deviceNameEl.textContent =
      DEVICE_MASTER[action.id]?.label ?? "（未設定）";
  }


  /* ===== メッセージ ===== */
  const input =
    document.getElementById("notifyMessageInput");

  if (input) {

    input.value = action.message ?? "";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initDeviceEditor();   // 機器画面の場合
  initNotifyEditor(); // 通知画面の場合
});