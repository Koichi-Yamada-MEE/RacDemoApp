/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [header, date, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/header.txt").then(r => r.text()),
      fetch("../../partials/date.html").then(r => r.text()),
      fetch("../../partials/footer.txt").then(r => r.text()),
      fetch("../../partials/modal.html").then(r => r.text()),
      fetch("../../partials/drower-menu.txt").then(r => r.text()),
    ]);

    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-date").innerHTML = date;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();

  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  initModalDriveModeSelectButtons();
  // 基本機能 画面
  // driveModeSwitchBtnAndSettingPanelOperation();
}

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  sessionStorage.setItem("appData", JSON.stringify(data));
};

/******************************************
 * 無効ボタンをクリックしたときの処理
 ******************************************/
document.addEventListener("click", (e) => {
  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  const target = e.target.closest(".demo-disabled-button");
  if (target) {
    e.preventDefault(); // リンクの遷移を止める
    alert("デモアプリではこのボタンは操作できません。");
  }
});

/******************************************
 * イニシャライズ：モーダル
 * 対象：モーダル内の運転モード選択ボタン
 * アクション：JSON更新
 ******************************************/
const initModalDriveModeSelectButtons = () => {
  const modalDriveModeButtons = document.querySelectorAll(
    ".modal-drive-select-btn",
  );
  modalDriveModeButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentMode", btn.dataset.appMode);
      renderWindControlOverlayOnOff();
      driveModeSwitchBtnAndSettingPanelOperation();
    });
  });
};

/******************************************
 * モーダル表示
 ******************************************/
const showModal = (modalId) => {
  const modalEl = document.getElementById(modalId);
  if (!modalEl) return;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();
};

/******************************************
 * ヘッダーのアイテムを設定する
 ******************************************/
window.addEventListener("load", () => {
  setTimeout(initHeader, 100);
});

function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getJsonValue(`headerSet.${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas('#appOffcanvas');
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }
  // 右側のテキストボタン表示

  headerDomRight.innerText = headerSetJsonRight.text || "";
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById('headerRightBtn');
      const target = getJsonValue('headerSet.electricityBillCheck.right.target');
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示
    case "alert":
      alert('デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください');
      break;

    // アラート表示
    case "touch-airflow-back":
      alert('風向を設定しました。やり直す場合は画像をダブルタップしてください。');
      break;
  }
}

/******************************************
 * レンダリング：基本画面
 * 対象：操作パネル（運転モード選択ボタン／ラベル／アイコン／設定表示（温度／湿度・送風））
 * アクション：操作パネルの更新
 ******************************************/
const driveModeSwitchBtnAndSettingPanelOperation = () => {
  let currentMode = getJsonValue("currentMode");
  const switchBtn = document.getElementById("driveModeSwitchBtn");
  const switchBtnLabel = document.getElementById("currentModeLabel");
  const switchBtnIcon = document.getElementById("currentModeIcon");
  const switchBtnTempDisplay = document.getElementById("tempDisplay");
  // クラスをリセット
  let initialStyle = "btn rounded-pill d-flex justify-content-center align-items-center gap-2 mt-3 app-drive-btn"
  document.getElementById("driveModeSwitchBtn").className = initialStyle;
  // クラス、ラベル、アイコン、設定表示を更新
  switchBtn.classList.add(getJsonValue(`driveModeSelectBtn.${currentMode}.style`));
  switchBtnLabel.innerText = getJsonValue(`driveModeSelectBtn.${currentMode}.label`);
  switchBtnIcon.src = getJsonValue(`driveModeSelectBtn.${currentMode}.icon`);
  switchBtnTempDisplay.className = getJsonValue(`driveModeSelectBtn.${currentMode}.settingDisplay`);
};

window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    const footerButtons = document.querySelectorAll(".footer-button");
    footerButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        setJsonValue("currentPage", btn.dataset.appPage);
        driveModeSwitchBtnAndSettingPanelOperation();
      });
    });
  }, 100);
});

/******************************************
 * フッターアイコン初期表示
 * アイコンをクリックするとページが切り替わるため、初期表示のみで対応
 ******************************************/
window.addEventListener("load", () => {
  setTimeout(() => {
    // 0. フッターが存在しない画面の処理
    const footerElement = document.getElementsByClassName("content-footer")[0];
    if (footerElement.className.includes("d-none")) {
      return;
    }

    // 1. リセット
    const currentPage = getJsonValue("currentPage");
    const footerButtons = document.querySelectorAll(".footer-button");
    footerButtons.forEach((btn) => {
      btn.classList.remove("active");
    });

    // 2. 初期表示
    footerButtons.forEach((btn) => {
      const page = btn.dataset.appPage;
      if (page === currentPage) {
        btn.classList.add("active");
      }
    });

    // 3. JSON更新
    footerButtons.forEach((btn) => {
      footerButtons.forEach(btn => {
        btn.addEventListener('click', () => {
          setJsonValue("currentPage", btn.dataset.appPage);
        });
      });
    });
  }, 100);
});

/******************************************
 * BS5 モーダルフォーカス解除
 ******************************************/
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});

/******************************************
 * トグルスイッチ関連
 ******************************************/

// JSONの値を取得⇒ ラベル表示更新
const renderToggleSwitchLabel = () => {
  getJsonValue("isThermalImageManagement")
    ? syncThermalImageManagement(true)
    : syncThermalImageManagement(false);
};

// DOM処理
const syncThermalImageManagement = (value) => {
  document.querySelectorAll(".js-toggle-switch").forEach(toggle => {
    // トグルスイッチの状態を更新
    toggle.checked = value;
    // ラベル表示を更新
    if (toggle.nextElementSibling) {
      toggle.nextElementSibling.innerText = value ? "ON" : "OFF";
    }
    // カードのリンクを更新
    const element = document.querySelector(".stretched-link-none");
    if (element) element.style.pointerEvents = value ? "auto" : "none";
  });
};

// 熱画像の表示⇔非表示の切り替え関数
const renderThermalImage = (value) => {
  const thermalImageElement = document.querySelector(".js-img");
  thermalImageElement.style.visibility = value ? "visible" : "hidden";
}

// その他機能画面を表示した時、タッチ気流トグルスイッチの状態を更新（AI自動以外はOFF）
// const renderTouchAirflowToggle = () => {
//   const isAiAuto = getJsonValue("currentMode").includes("ai-auto");
//   const btn = document.getElementById("toggleTouchAirflow");
//   if (isAiAuto) {
//     btn.checked = true;
//     btn.nextElementSibling.innerText = "ON";
//   } else {
//     btn.checked = false;
//     btn.nextElementSibling.innerText = "OFF";
//   }
// };

document.addEventListener("change", (event) => {
  // 変更された要素のIDを確認
  if (event.target && event.target.id === "toggleTouchAirflow") {
    const isAiAuto = getJsonValue("currentMode").includes("ai-auto");
    if (!isAiAuto) {
      event.target.checked = false; // 元に戻す
      event.target.nextElementSibling.innerText = "OFF";
      showModal("touchAirflowToggleModal");
    }
  }
});

/******************************************
 * レンダリング：基本画面
 * 対象：運転する⇔停止する ボタン
 * アクション：ボタンの表示更新
 ******************************************/
const renderDriveOnOffButton = () => {
  const btn = document.getElementById("btnRunStop");
  if (!btn) return;
  const isRunning = getJsonValue("modalDrive.isRunning");
  // 運転中の場合
  if (isRunning) {
    btn.style.backgroundColor = "white";
    btn.style.color = "var(--app-color-cooling)";
    btn.innerText = "停止する";
    // 停止中の場合
  } else {
    btn.style.backgroundColor = "var(--app-color-cooling)";
    btn.style.color = "white";
    btn.innerText = "運転する";
  }
};

/******************************************
 * レンダリング：基本画面
 * 対象：熱画像ホルダー
 * アクション：表示/非表示
 ******************************************/
const renderThermalImageOnOff = () => {
  const isThermalImageManagement = getJsonValue("isThermalImageManagement");
  const thermalImageElement = document.getElementById("thermalImageContainer");
  isThermalImageManagement ? thermalImageElement.style.visibility = "visible" : thermalImageElement.style.visibility = "hidden";
};

/******************************************
 * レンダリング：基本画面
 * 対象：風速上下風向左右風向ホルダー
 * アクション：オーバーレイ表示/非表示
 ******************************************/
const renderWindControlOverlayOnOff = () => {
  const overlay = document.querySelector(".wind-overlay");
  const mode = getJsonValue("currentMode");
  mode.includes("ai-auto")
    ? overlay.style.display = "block"
    : overlay.style.display = "none";
};

/******************************************
 * ハンドリング：基本画面
 * 対象：運転する⇔停止する ボタン
 * アクション：モーダル表示
 ******************************************/
document.addEventListener("click", (e) => {
  const trigger = e.target.closest(".js-drive-trigger");
  if (!trigger) return;

  const isRunning = getJsonValue("modalDrive.isRunning");
  const modal = document.getElementById("modalRacStartStop");
  if (!modal) return;

  const messageEl = modal.querySelector("#modalRacStartStopMessage");
  const okBtn = modal.querySelector(".js-modal-drive");

  if (!messageEl || !okBtn) return;

  if (isRunning) {
    messageEl.textContent = trigger.dataset.messageRun;
    okBtn.dataset.appDrive = "runToStop";
  } else {
    messageEl.textContent = trigger.dataset.messageStop;
    okBtn.dataset.appDrive = "stopToRun";
  }

  showModal("modalRacStartStop");
});


/******************************************
 * ハンドリング：基本画面
 * 対象：運転する⇔停止する モーダルボタン
 * アクション：クリック後のJSON更新
 ******************************************/

document.addEventListener("pointerup", (e) => {
  const btn = e.target.closest(".js-modal-drive");
  if (!btn) return;

  btn.dataset.appDrive === "stopToRun"
    ? handleRacStart()
    : handleRacStop();

  const modalEl = btn.closest(".modal");
  bootstrap.Modal.getInstance(modalEl).hide();

  renderDriveOnOffButton();
});

const handleRacStart = () => {
  setJsonValue("modalDrive.isRunning", true);
}

const handleRacStop = () => {
  setJsonValue("modalDrive.isRunning", false);
};

/******************************************
 * レンダリング：その他機能画面
 ******************************************/
// タッチ気流トグルスイッチ
const renderTouchAirflowToggle = () => {
  const value = getJsonValue("isTouchAirflow")
  const btn = document.getElementById("toggleTouchAirflow");
  if (value) {
    btn.checked = true;
    btn.nextElementSibling.innerText = "ON";
  } else {
    btn.checked = false;
    btn.nextElementSibling.innerText = "OFF";
  }
};

/******************************************
 * レンダリング：熱画像管理画面
 * 熱画像トグルスイッチ
 ******************************************/
const renderThermalImageManagementToggle = () => {
  const value = getJsonValue("isThermalImageManagement")
  const btn = document.getElementById("thermalImageManagement");
  if (value) {
    btn.checked = true;
  } else {
    btn.checked = false;
  }
};

/******************************************
 * ハンドリング：その他機能画面
 * 対象：タッチ気流トグルスイッチ
 * OFF → ON 熱画像管理がONでないとONにできない
 * ON → OFF そのままOFFにできる
 ******************************************/
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("toggleTouchAirflow");
  if (!btn) return;
  btn.addEventListener("change", (e) => {
    if (e.target.checked) {
      // OFF → ONにスイッチされた場合
      const value = getJsonValue("isThermalImageManagement");
      // 熱画像トグルスイッチがOFFの場合、モーダル表示してONにできないようにする
      if (!value) {
        showModal("touchAirflowToggleModal");
        e.target.checked = false; // トグルをOFFに戻す
        return;
      }
      // 熱画像トグルスイッチがONの場合、ONにできる
      setJsonValue("isTouchAirflow", true);
      renderTouchAirflowToggle();
    } else {
      // ON → OFFにスイッチされた場合
      setJsonValue("isTouchAirflow", false);
      renderTouchAirflowToggle();
    }
  });
});

/******************************************
 * ハンドリング：熱画像管理画面
 * 対象：熱画像トグルスイッチ
 * OFF → ON そのままONにできる
 * ON → OFF タッチ気流トグルスイッチ（その他機能）のJSONをfalseにして、そのままOFFにする
 ******************************************/
document.addEventListener("DOMContentLoaded", () => {
  const buttons = document.querySelectorAll('[data-app-key]');
  if (!buttons) return;

  buttons.forEach((btn) => {
    const appKey = btn.dataset.appKey;
    if (appKey === "thermalImageManagement") {
      btn.addEventListener("change", (e) => {
        // 熱画像トグルスイッチ　OFF → ON でJSON更新
        if (e.target.checked) {
          setJsonValue("isThermalImageManagement", true);
          // 熱画像トグルスイッチ　ON → OFF でJSON更新
        } else {
          setJsonValue("isThermalImageManagement", false);
          setJsonValue("isTouchAirflow", false); // タッチ気流を強制OFF
        }
      });
    }
  });
});



// document.addEventListener("DOMContentLoaded", () => {
//   const btn = document.getElementById("thermalImageManagement");
//   // ターゲット要素が存在しない場合は処理を中止
//   if (!btn) return;
//   // イベントリスナーを追加
//   btn.addEventListener("change", (e) => {
//     // 熱画像トグルスイッチ　OFF → ON でJSON更新
//     if (e.target.checked) {
//       setJsonValue("isThermalImageManagement", true);
//     // 熱画像トグルスイッチ　ON → OFF でJSON更新
//     } else {
//       setJsonValue("isThermalImageManagement", false);
//       setJsonValue("isTouchAirflow", false); // タッチ気流を強制OFF
//     }
//   });
// });


/******************************************
 * 「停止中」表示
 ******************************************/
// 「停止中」を非表示
const elementsDisplayDefault = () => {
  const setValueDisplay = document.getElementById("setValueDisplay");
  const airControl = document.getElementById("airControl");
  const statusStopped = document.getElementById("statusStopped");
  // 各要素の表示・非表示を制御
  setValueDisplay.classList.remove("d-none");
  airControl.classList.remove("d-none");
  statusStopped.classList.add("d-none");
};

// 「停止中」を表示
const elementsDisplayNone = () => {
  const setValueDisplay = document.getElementById("setValueDisplay");
  const airControl = document.getElementById("airControl");
  const statusStopped = document.getElementById("statusStopped");
  // 各要素の表示・非表示を制御
  setValueDisplay.classList.add("d-none");
  airControl.classList.add("d-none");
  statusStopped.classList.remove("d-none");
};

const renderStatusStoppedEl = () => {
  const isRunning = getJsonValue("modalDrive.isRunning");
  if (isRunning) {
    elementsDisplayDefault();
  } else {
    elementsDisplayNone();
  }
};

/******************************************
 * スケジュール表示処理
 ******************************************/
// 曜日表示用マップ
const DAY_LABEL_MAP = {
  sun: "日",
  mon: "月",
  tue: "火",
  wed: "水",
  thu: "木",
  fri: "金",
  sat: "土",
};

// スケジュール表示テキスト取得関数（スケジュール 画面用）
function getScheduleText() {
  const dayOfTheWeek = getJsonValue("schedule[0].dayOfTheWeek");
  const activeDays = Object.entries(dayOfTheWeek)
    .filter(([, value]) => value === true)
    .map(([key]) => key);

  // 何も選択されていない
  if (activeDays.length === 0) {
    return "一度だけ実行します";
  }

  // 全て選択
  if (activeDays.length === 7) {
    return "毎日実行します";
  }

  // 一部選択
  const labelText = activeDays
    .map(day => DAY_LABEL_MAP[day])
    .join("、");

  return `毎週${labelText}曜日に実行します`;
}

// スケジュール表示テキスト取得関数（スケジュール編集 画面用）
function getScheduleTextShort() {
  const dayOfTheWeek = getJsonValue("schedule[0].dayOfTheWeek");
  const activeDays = Object.entries(dayOfTheWeek)
    .filter(([, value]) => value === true)
    .map(([key]) => key);

  // 何も選択されていない
  if (activeDays.length === 0) {
    return null;
  }

  // 全て選択
  if (activeDays.length === 7) {
    return "毎日";
  }

  // 一部選択
  const labelText = activeDays
    .map(day => DAY_LABEL_MAP[day])
    .join("");

  return `${labelText}`;
}


// 表示アップデート 関数
function renderDayOfWeekToggle() {
  const dayOfTheWeek = getJsonValue("schedule[0].dayOfTheWeek");

  document.querySelectorAll(".day-of-the-week").forEach(button => {
    const dayKey = button.dataset.appScheduleDay; // sun, mon...

    if (dayOfTheWeek[dayKey]) {
      button.classList.add("active");
      button.setAttribute("aria-pressed", "true");
    } else {
      button.classList.remove("active");
      button.setAttribute("aria-pressed", "false");
    }
  });

  updateScheduleText();
}

// トグルスイッチのクリックイベントをバインド 関数（JSON → トグル + 文言）
function bindDayOfWeekEvents() {
  document.querySelectorAll(".day-of-the-week").forEach(button => {
    button.addEventListener("click", () => {
      const dayKey = button.dataset.appScheduleDay;
      const isActive = button.classList.contains("active");

      const path = `schedule[0].dayOfTheWeek.${dayKey}`;
      setJsonValue(path, isActive);

      updateScheduleText();
    });
  });
}

// 文言更新のみ 関数
function updateScheduleText() {
  const textEl = document.getElementById("scheduleText");
  // スケジュール 画面用
  if (textEl) {
    textEl.innerText = getScheduleText();
  }
  // スケジュール編集 画面用
  setJsonValue("schedule[0].dayOfTheWeekLabel", getScheduleTextShort());
}


document.addEventListener('DOMContentLoaded', () => {
  const offcanvasLinkHandler = () => {
    const link = document.getElementById("transition-link");
    const myOffcanvasElement = document.getElementById("appOffcanvas");
  };

  offcanvasLinkHandler();
});