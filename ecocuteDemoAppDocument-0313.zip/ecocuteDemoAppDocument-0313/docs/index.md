---  
date: 2025-08-19  
update: 2025-09-02  
title: "給湯機デモアプリ仕様書"  
auther: "MEE 京駐和事 山田 幸一"
---

<div class="edit-date" markdown>
:material-file-document-edit-outline:&nbsp;{{date}}<span class="space-1"></span>
:material-file-document-refresh-outline:&nbsp;{{update}}<span class="space-1"></span>
:octicons-person-24:&nbsp;{{auther}}
</div>

## 概要
### アプリ名
給湯機デモアプリ

### バージョン
Ver. 1.0 

### 依頼元
MELCO 京都 SB業・SB業（担当：中森 裕子 様）

### アプリ概要説明
本デモアプリは、起動ページにアクセスすることでセッションストレージにJSONが保存され、以降のページ遷移はJSONを読み取り／書き込みしながら画面の状態が制御されます。また、遷移できる画面は限定的で、遷移されない画面へリンクするボタンをタップした場合にはアラート「デモアプリではこのボタンは操作できません。」が表示されます。

### おもな機能
* JSON読み取り／書き込みによる各コンポーネント制御
* ページ遷移しても各コンポーネントの状態保持
* 起動ページ以外のページへアクセスした時のリダイレクト処理
* 画面遷移しない箇所をタップした時のアラート表示

### 公開URL
以下のURLにアクセスすると起動ページからトップページ（給湯機 タンク）へリダイレクトされ使用可能になります。  
https://www.mitsubishielectric.co.jp/home/mymu/demo/eq/

!!! warning

    本デモアプリを開始するには、必ず上記URLにアクセスしてください。上記URLにアクセスすると給湯機 タンク画面にリダイレクトされ使用可能な状態になります。セッション切れや、途中画面からスタートすると、アラートが表示され上記URLに戻る仕様になっています。

## 動作環境
### 対応デバイス
* 一般的なPC／スマートフォン／タブレット  
iPhone SE（横幅750px）の画面を基準レイアウトとしています。

### 対応OS（iOS／Android／Windows）
* 各デバイスの最新OS（2025年8月時点）
* macOSは未検証

### 実機検証した端末名
* Apple iPhone 13（iOS 18.6.2/1170×2532）
* Google Pixel 8a（Android 10/1080×2400）
* Sony Xperia 5 IV（Android 14/1080×2520）
* Samsung Galaxy A21 SC-42A（Android 10/720×1560）
* Sony Xperia XZ1 Compact SO-02K（Android 8/720×1280）
* LG it LGV36（Android 9/720×1280）

!!! note

    横幅750px未満の低解像度端末による検証は、ソ運 様にて実施

## 画面遷移図
本デモアプリは以下の構成で遷移します。  
※ クリックすると拡大され、マウス操作で全体を移動できます。

![タンク画面のJSONプロパティ](./assets/img/screen-flows.png){ align=left }

## JSON
起動時のプロパティ構成は以下のとおりです。

### JSON仕様

``` javascript
const ecoCuteDemoApp = {
  jsonName: "EcocuteDemoApp",
  version: "1.0.1",
  baseUrl: "./assets/img/",
  footerSrcOfSettings: null,
  tank: {
    tankOperationMode: "00",
    tankStatus: "none",
    tankMantanWakimashiBtnSrc: "btn-tank-mantan-wakimashi_on.png",
    tankMantanWakimashiPopup_on: "none",
    tankMantanWakimashiPopup_off: "none",
    tankWakiageBtnSrc: "btn-tank-wakiage_on.png",
    tankWakiagePopup_on: "none",
    tankWakiagePopup_off: "none",
  },
  bath: {
    bathOperationMode: "000",
    bathAutoBtnSrc: "btn-bath-auto_on.png",
    bathReheatBtnSrc: "btn-bath-reheat_on.png",
    bathKirariyuBtnSrc: "btn-bath-kirariyu_on.png",
    bathAutoPopup_on: "none",
    bathAutoPopup_off: "none",
    bathReheatPopup_on: "none",
    bathReheatPopup_off: "none",
    bathKirariyuPopup_on: "none",
    bathKirariyuPopup_off: "none",
    bathStatusImage: "bath-img-none.png",
    bathAutoStatus: "none",
    bathReheatStatus: "none",
    bathKirariyuStatus: "none",
  },
  settings: {
    headerNav01: "d-block",
    headerNav02: "d-none",
    headerNav03: "d-none",
  },
};
```

### JSONプロパティ名と値
{{ read_excel('assets/tables/json.xlsx') }}


### 給湯機画面

=== "タンク"

    ![タンク画面のJSONプロパティ](./assets/img/tank.png){ align=left }

=== "おふろ"

    ![タンク画面のJSONプロパティ](./assets/img/bath.png){ align=left }

=== "蛇口・シャワー"

    ![タンク画面のJSONプロパティ](./assets/img/shower.png){ align=left }


### 使用湯量画面・ヘルプ画面

=== "昨日・今日"

    ![使用湯量画面（昨日・今日）](./assets/img/amount-of-hot-water-1.png){ align=left }

=== "過去2週間"

    ![使用湯量画面（過去2週間）](./assets/img/amount-of-hot-water-2.png){ align=left }

=== "ヘルプ"

    ![ヘルプ画面](./assets/img/help.png){ align=left }


### ハンバーガーメニュー・太陽光発電との連携

=== "メニュー"

    ![メニュー画面](./assets/img/memu.png){ align=left }

=== "連携オフ"

    ![太陽光発電 連携オフ画面](./assets/img/sunlight-settings-off.png){ align=left }

=== "連携オン"

    ![太陽光発電 連携オン画面](./assets/img/sunlight-settings-on.png){ align=left }


### ポップアップ（タンク）

=== "満タンわき増し(オン)"

    ![満タンわき増し(オン)](./assets/img/dlg-tank-mantan-wakimashi_on.png)

=== "満タンわき増し(オフ)"

    ![満タンわき増し(オフ)](./assets/img/dlg-tank-mantan-wakimashi_off.png)

=== "わき上げ(オン)"

    ![わき上げ(オン)](./assets/img/dlg-tank-wakiage_on.png)

=== "わき上げ(オフ)"

    ![わき上げ(オフ)](./assets/img/dlg-tank-wakiage_off.png)


### ポップアップ（おふろ）

=== "ふろ自動(オン)"

    ![ふろ自動(オン)](./assets/img/dlg-bath-auto_on.png)

=== "ふろ自動(オフ)"

    ![ふろ自動(オフ)](./assets/img/dlg-bath-auto_off.png)

=== "追いだき(オン)"

    ![追いだき(オン)](./assets/img/dlg-bath-reheat_on.png)

=== "追いだき(オフ)"

    ![追いだき(オフ)](./assets/img/dlg-bath-reheat_off.png)

=== "キラリユ(オン)"

    ![キラリユ(オン)](./assets/img/dlg-bath-kirariyu_on.png)

=== "キラリユ(オフ)"

    ![キラリユ(オフ)](./assets/img/dlg-bath-kirariyu_off.png)


### ポップアップ（設定画面）

=== "設定完了（オン）"

    ![設定完了（オン）](./assets/img/dlg-settings_on.png)

=== "設定完了（オフ）"

    ![設定完了（オフ）](./assets/img/dlg-settings_off.png)


## エラー内容
以下のエラーが発生した場合、アラートが表示されます。起動ページに戻って、やり直してください。

{{ read_excel('assets/tables/error.xlsx') }}

## 改定履歴
* 2025年09月02日 初版発行  
