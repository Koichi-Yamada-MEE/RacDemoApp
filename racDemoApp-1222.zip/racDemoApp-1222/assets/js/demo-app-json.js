const initialAppData = {
  "currentPage": "basic", // 表示画面
  "currentMode": "cooling", // 運転モード（cooling, dehumidifying, heating, perflation, ai-auto-cooling, ai-auto-heating）
  "currentHeaderSet": "", // 
  // 運転モード選択ボタン状態, 温度・湿度・除湿表示
  "driveModeSelectBtn": {
    "cooling": {
      "label": "冷房",
      "icon": "../assets/img/home-icon-btn-cooling.svg",
      "style": "btn-cooling",
      "settingDisplay": "text-cooling"
    },
    "dehumidifying": {
      "label": "除湿",
      "icon": "../assets/img/home-icon-btn-dehumidification.svg",
      "style": "btn-dehumidifying",
      "settingDisplay": "text-dehumidifying"
    },
    "heating": {
      "label": "暖房",
      "icon": "../assets/img/home-icon-btn-heating.svg",
      "style": "btn-heating",
      "settingDisplay": "text-heating"
    },
    "perflation": {
      "label": "送風",
      "icon": "../assets/img/home-icon-btn-perflation.svg",
      "style": "btn-perflation",
      "settingDisplay": "text-perflation"
    },
    "ai-auto-cooling": {
      "label": "A.I.自動(冷房)",
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
      "settingDisplay": "text-ai-auto"
    },
    "ai-auto-heating": {
      "label": "A.I.自動(暖房)",
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
      "settingDisplay": "text-ai-auto"
    }
  },
  // ヘッダーセット
  headerSet: {
    headerSet01: ",リビング,",
    headerSet02: ",スケジュール,完了",
    headerSet03: ",タッチ気流（？）,決定",
    headerSet04: ",換気アシスト設定（？）,完了",
    headerSet05: ",窓位置設定,決定",
    headerSet06: ",熱画像管理,",
    headerSet07: ",電気代チェック,設定",
    headerSet08: ",電気代単価設定,編集",
    headerSet09: ",電気代単価設定,完了",
    headerSet10: ",電気代チェック,",
    headerSet11: ",目標電気代設定,",
    headerSet12: ",運転履歴,",
    headerSet13: ",メンテナンス,",
    headerSet14: ",エアコン製品情報,",
    headerSet15: ",製品情報の登録,",
    headerSet16: ",オプション機能設定（！）,",
    headerSet17: ",機器情報,",
    headerSet18: ",お知らせ,",
    headerSet19: ",チュートリアル,",
    headerSet20: ",アプリ情報,",
  },
  // フッターアイコンパス（拡張子なし）
  footerIconStatus: {
    mymu: "../assets/img/icon-footer-mymu",
    basic: "../assets/img/icon-footer-basic",
    schedule: "../assets/img/icon-footer-schedule",
    other: "../assets/img/icon-footer-other",
  },
  // スケジュール設定
  schedule: [
    {
      id: 1,
      name: "朝の運転",
      startTime: "07:00",
      dayOfTheWeek: {
        mon: true,
        tue: true,
        wed: true,
        thu: true,
        fri: true,
        sat: false,
        sun: false,
      },
      drive: true,
      mode: "cooling",
      setValue: 24,
    },
  ],
  // 運転／停止ボタン
  modalDrive: {
    // true ⇔ false
    isRunning: true,
    label: "停止",
  },
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
