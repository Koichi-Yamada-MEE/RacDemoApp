/******************************************
 * テンプレートファイル読み込み
 ******************************************/
Promise.all([
  fetch("../../partials/header.html").then((r) => r.text()),
  fetch("../../partials/date.html").then((r) => r.text()),
  fetch("../../partials/footer.txt").then((r) => r.text()),
  fetch("../../partials/modal.html").then((r) => r.text()),
  fetch("../../partials/drower-menu.html").then((r) => r.text()),
])
  .then(([headerHtml, dateHtml, footerHtml, modalHtml, drawerHtml]) => {
    document.querySelector(".content-header").innerHTML = headerHtml;
    document.querySelector(".content-date").innerHTML = dateHtml;
    document.querySelector(".content-footer").innerHTML = footerHtml;
    document.querySelector(".content-modal").innerHTML = modalHtml;
    document.querySelector(".content-drawer").innerHTML = drawerHtml;
  })
  .catch((err) => {
    console.error("Failed to load partials:", err);
  });

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  sessionStorage.setItem("appData", JSON.stringify(data));
};

/******************************************
 * ヘッダーのアイテムを設定する
 ******************************************/

// 初期化
// const headerSetNum = getJsonValue("currentHeaderSet");
// console.log("headerSetNum:", headerSetNum);
// const headerSetUp = (headerSetNum) => {

// SVGアイコンボタン
// document.getElementById("headerLeftBtn").innerHTML = getJsonValue(`headerSet.${headerSetNum}.left.icon`);
// タイトル
// document.getElementById("headerTitle").textContent = getJsonValue(`headerSet.${headerSetNum}.title`);
// テキストボタン
// document.getElementById("headerRightBtn").textContent = getJsonValue(`headerSet.${headerSetNum}.right.text`);
// };


window.addEventListener("load", () => {
  setTimeout(() => {
    const headerSet = {
      headerSet01: {
        left: {
          type: "drawer", // back | drawer
        },
        title: "スケジュール",
        right: {
          text: "完了",
          action: "back", // back | edit | modal など
          visible: true,
        },
      },
    };
    // ==============================
    // DOM取得
    // ==============================
    const headerDom = {
      leftBtn: document.getElementById("headerLeftBtn"),
      title: document.getElementById("headerTitle"),
      rightBtn: document.getElementById("headerRightBtn"),
    };

    // ==============================
    // headerSetキー取得（自動）
    // ==============================
    const currentHeaderSet = document.body.dataset.appHeaderSet;
    if (!currentHeaderSet) {
      console.warn("data-app-header-set が指定されていません");
    }

    const headerConfig = getJsonValue(`headerSet.${currentHeaderSet}`);
    if (!headerConfig) {
      console.warn(`headerSet.${currentHeaderSet} が見つかりません`);
    }


    // ==============================
    // タイトル反映
    // ==============================
    headerDom.title.innerHTML = headerConfig.title;

    // ==============================
    // 左ボタン描画
    // ==============================
    function renderLeftButton(type) {
      if (type === "back") {
        headerDom.leftBtn.innerHTML = `<i class="bi bi-chevron-left"></i>`;
        headerDom.leftBtn.style.display = "block";
        return;
      }

      if (type === "drawer") {
        headerDom.leftBtn.innerHTML = `<i class="bi bi-list"></i>`;
        headerDom.leftBtn.style.display = "block";
        return;
      }

      headerDom.leftBtn.style.display = "none";
    }

    renderLeftButton(headerConfig.left.type);

    // ==============================
    // 右ボタン描画
    // ==============================
    if (headerConfig.right.visible && headerConfig.right.text !== "") {
      headerDom.rightBtn.textContent = headerConfig.right.text;
      headerDom.rightBtn.style.display = "block";
    } else {
      headerDom.rightBtn.style.display = "none";
    }

    // ==============================
    // 左ボタン処理
    // ==============================
    headerDom.leftBtn.addEventListener("click", () => {
      const type = headerConfig.left.type;

      if (type === "back") {
        history.back();
        return;
      }

      if (type === "drawer") {
        console.log("ドロワーを開く");
        return;
      }
    });

    // ==============================
    // 右ボタン処理
    // ==============================
    headerDom.rightBtn.addEventListener("click", () => {
      const action = headerConfig.right.action;

      if (action === "back") {
        history.back();
        return;
      }

      if (action === "edit") {
        console.log("編集モードに切り替え");
        return;
      }
    });
  }, 100);
});



// アクションを設定
function handleHeaderRightAction(action) {
  if (action === "back") {
    history.back();
  }
}

// ヘッダー右ボタンの表示/非表示とアクション設定
function renderHeaderRight(right) {
  const btn = headerDom.rightBtn;

  // 非表示
  if (!right.visible || !right.text) {
    btn.classList.add("d-none");
    return;
  }

  // 表示
  btn.textContent = right.text;
  btn.classList.remove("d-none");

  // 既存イベントを消す
  btn.replaceWith(btn.cloneNode(true));
  headerDom.rightBtn = document.getElementById("headerRightBtn");

  // action があれば実行
  if (right.action) {
    headerDom.rightBtn.addEventListener("click", () => {
      handleHeaderRightAction(right.action);
    });
  }
}












































/******************************************
 * 運転モード選択ボタン, 操作パネル表示処理
 ******************************************/
const driveModeSwitchBtnAndSettingPanelOperation = () => {
  let currentMode = getJsonValue("currentMode");
  document.getElementById("driveModeSwitchBtn").classList.add(getJsonValue(`driveModeSelectBtn.${currentMode}.style`));
  document.getElementById("currentModeLabel").innerText = getJsonValue(`driveModeSelectBtn.${currentMode}.label`);
  document.getElementById("currentModeIcon").src = getJsonValue(`driveModeSelectBtn.${currentMode}.icon`);
  document.getElementById("temp-display").className = getJsonValue(`driveModeSelectBtn.${currentMode}.settingDisplay`);
};

window.addEventListener("load", () => {
  setTimeout(() => {
    const footerButtons = document.querySelectorAll(".footer-button");
    footerButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        setJsonValue("currentPage", btn.dataset.appPage);
      });
    });
  }, 100);
});

/******************************************
 * フッターアイコン初期表示
 * アイコンをクリックするとページが切り替わるため、初期表示のみで対応
 ******************************************/
window.addEventListener("load", () => {
  setTimeout(() => {
    // 0. フッターが存在しない画面の処理
    const footerElement = document.getElementsByClassName("content-footer")[0];
    if (footerElement.className.includes("d-none")) {
      return;
    }

    // 1. リセット
    const currentPage = getJsonValue("currentPage");
    const footerButtons = document.querySelectorAll(".footer-button");
    footerButtons.forEach((btn) => {
      btn.classList.remove("active");
    });

    // 2. 初期表示
    footerButtons.forEach((btn) => {
      const page = btn.dataset.appPage;
      if (page === currentPage) {
        btn.classList.add("active");
      }
    });

    // 3. JSON更新
    footerButtons.forEach((btn) => {
      footerButtons.forEach(btn => {
        btn.addEventListener('click', () => {
          setJsonValue("currentPage", btn.dataset.appPage);
        });
      });
    });
  }, 100);
});

/******************************************
 * BS5 モーダルフォーカス解除
 ******************************************/
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});
