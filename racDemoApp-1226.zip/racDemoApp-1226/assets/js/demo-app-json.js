const initialAppData = {
  "currentPage": "basic", // 表示画面
  "currentMode": "cooling", // 運転モード（cooling, dehumidifying, heating, perflation, ai-auto-cooling, ai-auto-heating）
  "currentHeaderSet": "headerSet01", // 
  // 運転モード選択ボタン状態, 温度・湿度・除湿表示
  "driveModeSelectBtn": {
    "cooling": {
      "label": "冷房",
      "icon": "../assets/img/home-icon-btn-cooling.svg",
      "style": "btn-cooling",
      "settingDisplay": "text-cooling"
    },
    "dehumidifying": {
      "label": "除湿",
      "icon": "../assets/img/home-icon-btn-dehumidification.svg",
      "style": "btn-dehumidifying",
      "settingDisplay": "text-dehumidifying"
    },
    "heating": {
      "label": "暖房",
      "icon": "../assets/img/home-icon-btn-heating.svg",
      "style": "btn-heating",
      "settingDisplay": "text-heating"
    },
    "perflation": {
      "label": "送風",
      "icon": "../assets/img/home-icon-btn-perflation.svg",
      "style": "btn-perflation",
      "settingDisplay": "text-perflation"
    },
    "ai-auto-cooling": {
      "label": "A.I.自動(冷房)",
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
      "settingDisplay": "text-ai-auto"
    },
    "ai-auto-heating": {
      "label": "A.I.自動(暖房)",
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
      "settingDisplay": "text-ai-auto"
    }
  },
  // ヘッダーセット
  headerSet: {
    "headerSet01": {
      "left": {
        "type": "drawer",
      },
      "title": 'リビング',
      "right": {
        "visible": false
      },
    },
    "headerSet02": {
      "left": {
        "type": "back",
      },
      "title": 'スケジュール',
      "right": {
        "text": "完了",
        "visible": true
      }
    },
    "headerSet03": {
      "left": {
        "type": "back",
      },
      "title": 'タッチ気流<i class="bi bi-question-circle-fill ms-1 text-secondary"></i>',
      "right": {
        "text": "保存",
        "action": "../save/",
        "target": '',
        "visible": true
      },
    },
    "headerSet04": {
      "left": {
        "type": "back",
      },
      "title": '換気アシスト設定<i class="bi bi-question-circle-fill ms-1 text-secondary"></i>',
      "right": {
        "text": "完了",
        "action": "../save/",
        "target": '',
        "visible": true
      }
    },
    "headerSet05": {
      "left": {
        "type": "back",
      },
      "title": '窓位置設定',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": true
      }
    },
    "headerSet06": {
      "left": {
        "type": "back",
      },
      "title": '熱画像管理',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": true
      }
    },
    "headerSet07": {
      "left": {
        "type": "back",
      },
      "title": '電気代チェック',
      "right": {
        "text": "設定",
        "action": "",
        "target": '',
        "visible": true
      }
    },
    "headerSet08": {
      "left": {
        "type": "back",
      },
      "title": '電気代単価設定',
      "right": {
        "text": "編集",
        "action": "",
        "target": '',
        "visible": true
      }
    },
    "headerSet09": {
      "left": {
        "type": "back",
      },
      "title": '電気代単価設定',
      "right": {
        "text": "完了",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet10": {
      "left": {
        "type": "back",
      },
      "title": '電気代チェック',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet11": {
      "left": {
        "type": "back",
      },
      "title": '目標電気代設定',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet12": {
      "left": {
        "type": "back",
      },
      "title": '運転履歴',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet13": {
      "left": {
        "type": "back",
      },
      "title": 'メンテナンス',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet14": {
      "left": {
        "type": "back",
      },
      "title": 'エアコン製品情報',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet15": {
      "left": {
        "type": "back",
      },
      "title": '製品情報の登録',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet16": {
      "left": {
        "type": "back",
      },
      "title": 'オプション機能設定<i class="bi bi-exclamation-circle ms-1"></i>',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet17": {
      "left": {
        "type": "back",
      },
      "title": '機器情報',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet18": {
      "left": {
        "type": "back",
      },
      "title": 'お知らせ',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet19": {
      "left": {
        "type": "back",
      },
      "title": 'チュートリアル',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
    "headerSet20": {
      "left": {
        "type": "back",
      },
      "title": 'アプリ情報',
      "right": {
        "text": "",
        "action": "",
        "target": '',
        "visible": false
      }
    },
  },

  // スケジュール設定
  schedule: [
    {
      id: 1,
      name: "朝の運転",
      startTime: "07:00",
      dayOfTheWeek: {
        mon: true,
        tue: true,
        wed: true,
        thu: true,
        fri: true,
        sat: false,
        sun: false,
      },
      drive: true,
      mode: "cooling",
      setValue: 24,
    },
  ],
  // 運転／停止ボタン
  modalDrive: {
    // true ⇔ false
    isRunning: true,
    label: "停止",
  },
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
