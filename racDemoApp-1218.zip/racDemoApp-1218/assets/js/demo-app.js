/******************************************
 * テンプレートファイル読み込み
 ******************************************/
Promise.all([
  fetch("../../partials/header.html").then((r) => r.text()),
  fetch("../../partials/date.html").then((r) => r.text()),
  fetch("../../partials/footer.html").then((r) => r.text()),
  fetch("../../partials/modal.html").then((r) => r.text()),
  fetch("../../partials/drower-menu.html").then((r) => r.text()),
])
  .then(([headerHtml, dateHtml, footerHtml, modalHtml, drawerHtml]) => {
    document.querySelector(".content-header").innerHTML = headerHtml;
    document.querySelector(".content-date").innerHTML = dateHtml;
    document.querySelector(".content-footer").innerHTML = footerHtml;
    document.querySelector(".content-modal").innerHTML = modalHtml;
    document.querySelector(".content-drawer").innerHTML = drawerHtml;
  })
  .catch((err) => {
    console.error("Failed to load partials:", err);
  });

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  sessionStorage.setItem("appData", JSON.stringify(data));
};

/******************************************
 * フッターアイコン初期表示
 * アイコンをクリックするとページが切り替わるため、初期表示のみで対応
 ******************************************/
window.addEventListener("load", () => {
  setTimeout(() => {
    // 1. 初期表示
    document.getElementById("footer-mymu").src = getJsonValue("footerIconStatus.mymu");
    document.getElementById("footer-basic").src = getJsonValue("footerIconStatus.basic");
    document.getElementById("footer-schedule").src = getJsonValue("footerIconStatus.schedule");
    document.getElementById("footer-other").src = getJsonValue("footerIconStatus.other");
    document.getElementById(`footer-${getJsonValue("currentPage")}-txt`).classList.add("active");

    document.querySelectorAll('.footer-button').forEach(btn => {
      btn.addEventListener('click', () => {
      // 2. リセット
      setJsonValue('footerIconStatus.mymu', '../assets/img/icon-footer-mymu.svg');
      setJsonValue('footerIconStatus.basic', '../assets/img/icon-footer-basic.svg');
      setJsonValue('footerIconStatus.schedule', '../assets/img/icon-footer-schedule.svg');
      setJsonValue('footerIconStatus.other', '../assets/img/icon-footer-other.svg');

      // 3. JSON更新
      setJsonValue(`footerIconStatus.${btn.dataset.appPage}`, `../assets/img/icon-footer-${btn.dataset.appPage}-active.svg`);
      setJsonValue('currentPage', `${btn.dataset.appPage}`);
      // 4. 表示更新
      document.getElementById(`footer-${btn.dataset.appPage}`).src = getJsonValue(`footerIconStatus.${btn.dataset.appPage}`);
      });
    });
  }, 100);
});


/******************************************
 * BS5 モーダルフォーカス解除
 ******************************************/
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});
