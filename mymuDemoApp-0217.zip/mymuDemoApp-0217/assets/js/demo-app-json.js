const initiAppData = {
  // 登録済み-1
  currentTriggerEvent: "schedule", // (schedule | location | statusOfDevice)
  entryId: "auto-1", // オートメーションID（新規作成時は"new"）
  isAutoMationSetDone: false, // オートメーション機能　有効/無効　(true　|　false)
  "auto-1": {
    status: true,
    entryTrigger: "schedule",
    name: "冬の帰宅", // オートメーション名
    triggers: {
      schedule: {
        time: "18:00",
        days: ["mon", "tue", "wed", "thu", "fri"],
      },
    },
    actions: [
      {
        type: "devices",
        id: "rac-1",
        drive: "on",
        mode: "暖房",
        temp: 20,
      },
      {
        type: "devices",
        id: "eq",
        name: "給湯機",
        drive: "on",
      },
    ],
  },

  // 登録済み-2
  "auto-2": {
    status: true,
    entryTrigger: "schedule",
    name: "夏の帰宅", // オートメーション名
    triggers: {
      schedule: {
        time: "19:00",
        days: ["mon", "wed", "fri"],
      },
    },
    actions: [
      {
        type: "devices",
        id: "rac-1",
        drive: "on",
        mode: "冷房",
        temp: 27,
      },
    ],
  },

  // 登録済み-3
  "auto-3": {
    status: true,
    entryTrigger: "devices",
    name: "高温おしらせ", // オートメーション名
    triggers: {
      devices: {
        id: "rac-2",
        condition: "室温がしきい値を超えたとき",
        threshold: 28,
      },
    },
    actions: [
      {
        type: "notify",
        id: "rac-2",
        message: "室温",
      },
    ],
  },

  // 提案-1
  "temp-1": {
    status: true,
    entryTrigger: "devices",
    name: "高温のおしらせ", // オートメーション名
    triggers: {
      devices: {
        id: "rac-2",
        name: "寝室のエアコン",
        condition: "室温がしきい値を超えたとき",
        threshold: "28.0",
      },
    },
    actions: [
      {
        type: "notify",
        id: "rac-2",
        message: "室温",
      },
    ],
  },
  // 提案-2
  "temp-2": {
    status: true,
    entryTrigger: "devices",
    name: "低温のおしらせ", // オートメーション名
    triggers: {
      devices: {
        id: "rac-2",
        condition: "室温がしきい値を下回ったとき",
        threshold: "15.0",
      },
    },
    actions: [
      {
        type: "notify",
        id: "rac-1",
        message: "室温",
      },
    ],
  },

  // 提案-3
  "temp-3": {
    status: true,
    entryTrigger: "location",
    name: "おかえりON", // オートメーション名
    triggers: {
      location: {
        users: ["お父さん"], //
        event: "close", // 自宅に近づいたとき/離れたとき
      },
    },
    actions: [
      {
        type: "devices",
        id: "rac-2",
        drive: "on",
        mode: "冷房",
        temp: "27.0",
        threshold: "28.0",
      },
    ],
  },

  // 提案-4
  "temp-4": {
    status: true,
    entryTrigger: "location",
    name: "おかえりOFF", // オートメーション名
    triggers: {
      location: {
        users: ["お父さん", "お母さん", "たかし", "あいこ"], //
        event: "away", // 自宅に近づいたとき/離れたとき
      },
    },
    actions: [
      {
        type: "devices",
        id: "rac-1",
        drive: "off",
      },
    ],
  },

  // 提案-5
  "temp-5": {
    status: true,
    entryTrigger: "schedule",
    name: "エアコン入タイマー", // オートメーション名
    triggers: {
      schedule: {
        time: "17:00",
        days: [],
      },
    },
    actions: [
      {
        type: "devices",
        id: "rac-1",
        drive: "on",
        mode: "暖房",
        temp: "20.0",
      },
    ],
  },

  // 提案-6
  "temp-6": {
    status: true,
    entryTrigger: "schedule",
    name: "エアコン切タイマー", // オートメーション名
    triggers: {
      schedule: {
        time: "09:00",
        days: [],
      },
    },
    actions: [
      {
        type: "devices",
        id: "rac-1",
        drive: "off",
      },
    ],
  },

  // 新規
  // new: {
  //   status: true,
  //   entryTrigger: "schedule",
  //   name: "オートメーションサンプル", // オートメーション名
  //   trigger: {
  //     type: "schedule", // schedule | location | devices
  //     time: "18:00",
  //     days: ["月", "火", "水"],
  //   },
  //   actions: [
  //     { type: "devices", id: "rac-1" },
  //     { type: "devices", id: "eq" },
  //   ],
  // },

  // 新規
  "new": {
    status: true,
    entryTrigger: "schedule",
    name: "新規オートメーション", // オートメーション名
    triggers: {
      schedule: {
        time: "",
        days: [],
      },
      location: {
        users: [], //
        event: "", // 自宅に近づいたとき/離れたとき
      },
      devices: [],
    },
    actions: [],
  }
};







const headerSet = {
  home: {
    left: {
      type: "drawer",
    },
    title: "MyMU",
    right: {
      text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>',
      visible: true,
    },
  },
  newAutomation: {
    left: {
      type: "back",
    },
    title: "新規オートメーション",
    right: {
      visible: false,
    },
  },
  deviceSettingsAc: {
    left: {
      type: "back",
    },
    title: "操作設定",
    right: {
      text: "完了",
      visible: true,
    },
  },
  deviceSettingsEq: {
    left: {
      type: "back",
    },
    title: "操作設定",
    right: {
      text: "完了",
      visible: true,
    },
  },
  applianceSelection: {
    left: {
      type: "back",
    },
    title: "機器を選択",
    right: {
      visible: false,
    },
  },
  customAutomation: {
    left: {
      type: "back",
    },
    title: "新規オートメーション",
    right: {
      visible: false,
    },
  },
  selectScene: {
    left: {
      type: "back",
    },
    title: "シーンを選択",
    right: {
      visible: false,
    },
  },
  noticeSettings: {
    left: {
      type: "back",
    },
    title: "通知設定",
    right: {
      text: "完了",
      visible: true,
    },
  },
  editAutomation: {
    left: {
      type: "back",
    },
    title: "オートメーション編集",
    right: {
      text: "完了",
      visible: true,
    },
  },
  selectDeviceOperation: {
    left: {
      type: "back",
    },
    title: "機器の状態を選択",
    right: {
      visible: false,
    },
  },
  setupScene: {
    left: {
      type: "back",
    },
    title: "シーン設定",
    right: {
      text: "完了",
      visible: true,
    },
  },
  selectRoomTemperatureStatusOver: {
    left: {
      type: "back",
    },
    title: "室温が所定値を超えたとき",
    right: {
      visible: false,
    },
  },
  selectRoomTemperatureStatusUnder: {
    left: {
      type: "back",
    },
    title: "室温が所定値を下回ったとき",
    right: {
      visible: false,
    },
  },
  homeLocationSettings: {
    left: {
      type: "back",
    },
    title: "自宅位置設定",
    right: {
      text: "完了",
      visible: true,
    },
  },
  selectScene: {
    left: {
      type: "back",
    },
    title: "シーンを選択",
    right: {
      text: "完了",
      visible: true,
    },
  },
  selectDevice: {
    left: {
      type: "back",
    },
    title: "機器を選択",
    right: {
      text: "完了",
      visible: true,
    },
  },
  selectNotice: {
    left: {
      type: "back",
    },
    title: "通知設定を選択",
    right: {
      text: "完了",
      visible: true,
    },
  },
  notificationSettings: {
    left: {
      type: "back",
    },
    title: "通知設定を選択",
    right: {
      text: "完了",
      visible: true,
    },
  },
  // 
}

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initiAppData));
    sessionStorage.setItem("cloneData", JSON.stringify(initiAppData));
    sessionStorage.setItem("headerSet", JSON.stringify(headerSet));

    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}
storeJsonData();
