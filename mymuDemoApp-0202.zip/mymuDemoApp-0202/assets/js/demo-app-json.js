const initialAppData = {
  currentPage: "home", // (home | automation | mymuPlus | notice)
  costumAutomation: {
    triggerEvent: "schedule", // (schedule | locationInfo | statusOfDevice)
  },
  // ヘッダーセット
  headerSet: {
    home: {
      left: {
        type: "drawer",
      },
      title: "MyMU",
      right: {
        text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>',
        visible: true,
      },
    },
    newAutomation: {
      left: {
        type: "back",
      },
      title: "新規オートメーション",
      right: {
        visible: false,
      },
    },
    deviceSettingsAc: {
      left: {
        type: "back",
      },
      title: "操作設定",
      right: {
        text: "完了",
        visible: true,
      },
    },
    applianceSelection: {
      left: {
        type: "back",
      },
      title: "機器を選択",
      right: {
        visible: false,
      },
    },
    customAutomation: {
      left: {
        type: "back",
      },
      title: "新規オートメーション",
      right: {
        visible: false,
      },
    },

  },
  // スケジュール設定
  schedule: [
    {
      id: 3,
      name: "スケジュール",
      startTime: "07:00",
      dayOfTheWeek: {
        sun: true,
        mon: true,
        tue: false,
        wed: false,
        thu: false,
        fri: false,
        sat: false,
      },
      dayOfTheWeekLabel: "日月",
      isDrive: false,
      mode: "冷房",
      setValue: "24.0",
    },
  ],
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
