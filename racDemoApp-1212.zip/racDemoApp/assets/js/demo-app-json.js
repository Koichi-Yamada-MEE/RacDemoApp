const initialAppData = {
  // 表示画面
  currentPage: "basic",
  // 運転モード切替ボタン状態
  currentMode: "冷房",
  currentModeColor: "#0872ED",
  currentModeIcon: "../assets/img/home-icon-btn-cooling.svg",
  currentModeStyle: "btn-cooling",
  setTemptureStyle: "color: var(--app-color-cooling)",

  // フッターアイコン画像パス
  footerIconPaths: {
    mymu: "../assets/img/icon-footer-mymu.svg",
    basic: "../assets/img/icon-footer-basic-active.svg",
    schedule: "../assets/img/icon-footer-schedule.svg",
    other: "../assets/img/icon-footer-other.svg",
  },
  // 運転／停止ボタン
  modalDrive: {
    // true ⇔ false
    isRunning: true,
    label: "停止",
  },
  // 運転モードボタン
  buttons: [
    {
      id: "cooling",
      label: "冷房",
      icon: "../assets/img/home-icon-btn-cooling.svg",
      color: "#0872ED",
      style: "btn-cooling",
    },
    {
      id: "dehumidify",
      label: "除湿",
      icon: "../assets/img/home-icon-btn-dehumidification.svg",
      color: "#008738",
      style: "btn-dehumidifying",
    },
    {
      id: "heating",
      label: "暖房",
      icon: "../assets/img/home-icon-btn-heating.svg",
      color: "#D64100",
      style: "btn-heating",
    },
    {
      id: "fan",
      label: "送風",
      icon: "../assets/img/home-icon-btn-perflation.svg",
      color: "#757575",
      style: "btn-perflation",
    },
    {
      id: "ai-auto-cooling",
      label: "A.I.自動(冷房)",
      icon: "../assets/img/home-icon-btn-ai-auto.svg",
      color: "#D63771",
      style: "btn-ai-auto",
    },
    {
      id: "ai-auto-heating",
      label: "A.I.自動(暖房)",
      icon: "../assets/img/home-icon-btn-ai-auto.svg",
      color: "#D63771",
      style: "btn-ai-auto",
    },
  ],
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
