const initialAppData = {
  currentPage: "mymu", // (mymu | automation | mymuPlus | notice)
  currentTriggerEvent: "schedule", // (schedule | location | statusOfDevice)
  automation: {
    selectedId: null,
    id1: {
      isSelected: false,
      status: true, // トグルの状態
      name: "冬の帰宅",
      triggerEvent: {
        schedule: {
          isSelected: false,
          startTime: "19:00",
          dayOfTheWeek: {
            sun: true,
            mon: true,
            tue: true,
            wed: true,
            thu: true,
            fri: true,
            sat: true,
          },
        },
        location: {
          isSelected: true,
          user: {
            name: "",
            condition: "", // (close | away)
          },
        },
        product: {
          isSelected: false,
          name: "", // (rac | eq)
          drive: "", // (on | off)
        },
      },
      action: {
        scene: "",
        product: "",
        notification: "",
      }
    },
  },
};

