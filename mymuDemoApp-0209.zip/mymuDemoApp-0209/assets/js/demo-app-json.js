const initialAppData = {
  currentPage: "mymu", // (mymu | automation | mymuPlus | notice)
  currentTriggerEvent: "schedule", // (schedule | location | statusOfDevice)
  automation: {
    selectedId: "auto-1",
    items: {
      "auto-1": {
        status: true,
        name: "冬の帰宅",
        triggers: [
          {
            type: "schedule",
            startTime: "18:00",
            days: ["mon", "tue", "wed", "thu", "fri"]
          }
        ],
        actions: [
          {
            type: "product", // (scenes | products | notifications)
            productId: "rac",
            name: "リビングエアコン",
            drive: "on",
            mode: "heating",
            temperature: "20.0"
          },
          {
            type: "product", // (scenes | products | notifications)
            productId: "eq",
            name: "給湯機",
            drive: "on",
          }
        ]
      },

      "auto-2": {
        status: true,
        name: "夏の帰宅",
        triggers: [
          {
            type: "schedule",
            startTime: "19:00",
            days: ["mon", "wed", "fri"]
          }
        ],
        actions: [
          {
            type: "product", // (scenes | products | notifications)
            productId: "rac",
            name: "リビングのエアコン",
            drive: "on",
            mode: "cooling",
            temperature: "27.0"
          }
        ]
      },

      "auto-3": {
        status: true,
        name: "高温おしらせ",
        triggers: [
          {
            type: "product",
            productId: "rac",
            condition: "temperatureAbove",
            threshold: 28
          }
        ],
        actions: [
          {
            type: "product",
            productId: "rac",
            name: "リビングのエアコン",
            drive: "on",
            mode: "cooling",
            temperature: "27.0"
          },
          {
            type: "notification",
            name: "リビングのエアコン",
            target: "mother",
            message: "室温"
          }
        ]
      }
    }
  },
  // ヘッダーセット
  headerSet: {
    home: {
      left: {
        type: "drawer",
      },
      title: "MyMU",
      right: {
        text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>',
        visible: true,
      },
    },
    newAutomation: {
      left: {
        type: "back",
      },
      title: "新規オートメーション",
      right: {
        visible: false,
      },
    },
    deviceSettingsAc: {
      left: {
        type: "back",
      },
      title: "操作設定",
      right: {
        text: "完了",
        visible: true,
      },
    },
    deviceSettingsEq: {
      left: {
        type: "back",
      },
      title: "操作設定",
      right: {
        text: "完了",
        visible: true,
      },
    },
    applianceSelection: {
      left: {
        type: "back",
      },
      title: "機器を選択",
      right: {
        visible: false,
      },
    },
    customAutomation: {
      left: {
        type: "back",
      },
      title: "新規オートメーション",
      right: {
        visible: false,
      },
    },
    selectScene: {
      left: {
        type: "back",
      },
      title: "シーンを選択",
      right: {
        visible: false,
      },
    },
    noticeSettings: {
      left: {
        type: "back",
      },
      title: "通知設定",
      right: {
        text: "完了",
        visible: true,
      },
    },

    editAutomation: {
      left: {
        type: "back",
      },
      title: "オートメーション編集",
      right: {
        text: "完了",
        visible: true,
      },
    },
  },
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
