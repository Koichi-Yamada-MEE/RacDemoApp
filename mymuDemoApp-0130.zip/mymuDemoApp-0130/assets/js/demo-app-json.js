const initialAppData = {
  // ヘッダーセット
  headerSet: {
    home: {
      left: {
        type: "drawer",
      },
      title: "MyMU",
      right: {
        text: "完了",
        visible: true,
      },
    },
  },
  // スケジュール設定
  schedule: [
    {
      id: 3,
      name: "スケジュール",
      startTime: "07:00",
      dayOfTheWeek: {
        sun: true,
        mon: true,
        tue: false,
        wed: false,
        thu: false,
        fri: false,
        sat: false,
      },
      dayOfTheWeekLabel: "日月",
      isDrive: false,
      mode: "冷房",
      setValue: "24.0",
    },
  ],
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
